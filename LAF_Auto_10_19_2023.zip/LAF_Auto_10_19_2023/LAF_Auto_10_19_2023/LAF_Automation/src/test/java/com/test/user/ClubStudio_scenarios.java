
	package com.test.user;
	
	import java.io.File;
	import java.io.IOException;
	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.List;
	import java.util.Map;
	import org.testng.ITestContext;
	import org.testng.annotations.AfterTest;
	import org.testng.annotations.BeforeSuite;
	import org.apache.commons.lang3.ObjectUtils.Null;
	import org.apache.poi.hssf.record.PageBreakRecord.Break;
	import org.testng.*;
	import org.testng.annotations.DataProvider;
	import org.testng.annotations.Test;
	import com.BasePackage.Base_Class;
	import com.Utility.Log;
	import com.aventstack.extentreports.MediaEntityBuilder;
	import com.aventstack.extentreports.Status;
	import com.extentReports.ExtentManager;
	import com.extentReports.ExtentTestManager;
	import com.google.common.base.Throwables;
	import com.listeners.TestListener;
	
	public class ClubStudio_scenarios extends Base_Class  {
	
		Base_Class Base_Class;
		com.pages.Home Home;
		com.pages.Joinnow joinnow;
		Log log;
		TestListener TestListener;
		com.Utility.ScreenShot screenShot;
		com.pages.Employment Employment;
		com.pages.FreePass FreePass;
		com.pages.CareerOpportunity CareerOpportunity;
		com.pages.ClubStudio ClubStudio;
		
		
		@BeforeSuite
		public void reference() {
			Base_Class = new Base_Class();
			log = new Log();
			TestListener = new TestListener();
			screenShot = new com.Utility.ScreenShot(null);
			Home = new com.pages.Home();
			joinnow = new com.pages.Joinnow();
			Employment = new com.pages.Employment();
			FreePass = new com.pages.FreePass();
			ClubStudio = new com.pages.ClubStudio();
			CareerOpportunity = new com.pages.CareerOpportunity();
		}
		
		@Test(dataProvider = "TestData")
		public void RUNALL(Map<Object, Object> testdata, ITestContext context) throws Throwable {
	
			try {
	
				if (testdata.get("Run").toString().equalsIgnoreCase("Yes")) {
					String fileName;
					ExtentTestManager.startTest(testdata.get("TestScenario").toString());
					ExtentTestManager.getTest().log(Status.PASS, "*** Test Suite " + testdata.get("TestScenario").toString() + " running Starting ***");
					Log.info("*** Running test method " + testdata.get("TestScenario").toString() + "...");
					ExtentTestManager.getTest().log(Status.PASS, "*** Running test method " + testdata.get("TestScenario").toString() + "...");
				
					String Change_brand_name=testdata.get("Change_brand_name").toString();
					if(testdata.get("TextMessage").toString().trim().equalsIgnoreCase("Change_Brand".trim())) {
						
						Base_Class.setup_Change_brand();
						if(!Change_brand_name.isBlank() && !Change_brand_name.isEmpty()) Base_Class.Change_Brand(Change_brand_name);
						
					else {
						
						throw new Exception("please provide brand name to change the brand");
					
						}
						
					driver.quit();
						
					}
					
					else {
						Base_Class.setup();
					}
	
					
//					Base_Class.setup();
					ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered into Application URL ");
	
	
					String Dropdown_values=testdata.get("Dropdown_values").toString();
	
					String Country =testdata.get("Country").toString();
					String Ratesoramenities =testdata.get("Rates/amenities").toString();
					String Club_name =testdata.get("Club_name").toString();
					
					String Add_amenities =testdata.get("Add_amenities").toString();
					String Included_amenities =testdata.get("Included_amenities").toString();
				
					String Amount_details =testdata.get("Amount_details").toString();
					String rates_details =testdata.get("Rates_details").toString();
					String plan_rates =testdata.get("Plan_rates").toString();
					
					
					
					
					String Text_input =testdata.get("Text_input").toString();
		
					
					String Number_of_Persons1 =testdata.get("Number_of_Persons1").toString();
					String Initiation_Fee =testdata.get("Initiation_Fee").toString();
					String Billing_Frequency =testdata.get("Billing_Frequency").toString();				
					String Initial_Term =testdata.get("Initial_Term").toString();
					String Prepayment =testdata.get("Prepayment").toString();
					String First_Month_Dues =testdata.get("First_Month_Dues").toString();
					String Last_Month_Dues =testdata.get("Last_Month_Dues").toString();
					String Total_initial_Payment =testdata.get("Total_initial_Payment").toString();	
					String Annual_Fee_Per_Person =testdata.get("Annual_Fee_Per_Person").toString();
					
					String Everemployed_rdobtn =testdata.get("Everemployed_rdobtn").toString();
					String Date_to_begin =testdata.get("Date_to_begin").toString();
					String Languages =testdata.get("Languages").toString();
					String Work_time =testdata.get("Work_time").toString();
					String Url =testdata.get("Url").toString();
					String additional_input =testdata.get("additional_input").toString();
					String input_data =testdata.get("input_data").toString();
					String input_data1 =testdata.get("input_data1").toString();
					String input_data2 =testdata.get("input_data2").toString();
					String input_data3 =testdata.get("input_data3").toString();
					String input_data4 =testdata.get("input_data4").toString();
					String input_data5 =testdata.get("input_data5").toString();
					String input_data6 =testdata.get("input_data6").toString();
					String IP_Address =testdata.get("IP_Address").toString();
					
					String File_name =testdata.get("File_name").toString();
					
					String Job_short_des =testdata.get("Job_short_des").toString();
					String Job_long_des =testdata.get("Job_long_des").toString();
					String F_Name =testdata.get("F_Name").toString();
					String L_Name =testdata.get("L_Name").toString();
					String Full_name =testdata.get("Full_name").toString();
					String Phone =testdata.get("Member_Phone").toString();
					String Email =testdata.get("Email").toString();
					String Address =testdata.get("Member_address").toString();
	//				job_short_des
					String City =testdata.get("Member_City").toString();
					
					String E_EducationLeve_Dropdown = testdata.get("E_EducationLeve_Dropdown").toString();
	
					String Aerobics_Instructor_Exp_DD = testdata.get("Aerobics_Instructor_Exp_DD").toString();
					String Time_period_DD = testdata.get("Time_period_DD").toString();
					String Club_Employer_DD = testdata.get("Club_Employer_DD").toString();
					String Class_per_week = testdata.get("Class_per_week").toString();
					
					String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
					String PriorEmploymentWhyResigned_ip = testdata.get("PriorEmploymentWhyResigned_ip").toString();
					String EmploymentWhyLeaveCurrent_ip = testdata.get("EmploymentWhyLeaveCurrent_ip").toString();
					String EmploymentWhyReapply_ip = testdata.get("EmploymentWhyReapply_ip").toString();
					String EmploymentWhatLike_ip = testdata.get("EmploymentWhatLike_ip").toString();
					String EmploymentWhatDislike_ip = testdata.get("EmploymentWhatDislike_ip").toString();
					
					String EmploymentSuccess_ip = testdata.get("EmploymentSuccess_ip").toString();
					String EmploymentWhyResignInFuture_ip = testdata.get("EmploymentWhyResignInFuture_ip").toString();
					String Gender_dd = testdata.get("Gender_dd").toString();
					String RaceEthnicity_dd = testdata.get("RaceEthnicity_dd").toString();
	//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
	//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
	//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
	//				
					String Personal_Training_ExperienceDPValues = testdata.get("Personal_Training_ExperienceDPValues").toString();
					String Certification_IssuedByDPValues = testdata.get("Certification_IssuedByDPValues").toString();
					String Hold_cert_GT_AC_ratio_button = testdata.get("Hold_cert_GT_AC_ratio_button").toString();
					String Certified_In_DD = testdata.get("Certified_In_DD").toString();
					String Certificate_No = testdata.get("Certificate_No").toString();
					String Emp_gap = testdata.get("Emp_gap").toString();
					String Employer_name = testdata.get("Employer_name").toString();
					String Supervisor_name = testdata.get("Supervisor_name").toString();
					String From_date = testdata.get("From_date").toString();
					String To_date = testdata.get("To_date").toString();
					String Job_title = testdata.get("Job_title").toString();
					String Leaving_Reason = testdata.get("Leaving_Reason").toString();
					String Emp_details = testdata.get("Emp_details").toString();
					String Can_contact_radio_button = testdata.get("Can_contact_radio_button").toString();
					
					
					String Club_phone =testdata.get("Club_phone").toString();
					String Club_zip =testdata.get("Club_zip").toString();
					String Club_Address =testdata.get("Club_Address").toString();
					String Club_city =testdata.get("Club_city").toString();
	//				
					String State =testdata.get("State").toString();
					String Zipcode =testdata.get("Member_Zipcode").toString();
					String Radius_travel_to_work =testdata.get("Radius_travel_to_work").toString();
					String How_hear_abt_us =testdata.get("How_hear_abt_us").toString();
					String Radiobtn18YearsOld =testdata.get("Radiobtn18YearsOld").toString();
					String Payment_type =testdata.get("Payment_type").toString();
					String Card_number  =testdata.get("Card_number").toString();
					
					String Ex_month =testdata.get("Ex_month").toString();
					String Ex_year  =testdata.get("Ex_year").toString();
					
					String Routing_number  =testdata.get("Routing_number").toString();
					String Account_number =testdata.get("Account_number").toString();
					String Card_name =testdata.get("Card_name").toString();
					String Checkbox_class_formats =testdata.get("Checkbox_class_formats").toString();

					String No_Prev_emp_chk_box =testdata.get("No_Prev_emp_chk_box").toString();
				
					String Considered_for_chkbx =testdata.get("Considered_for_chkbx").toString();
						
					
					
							
					switch (testdata.get("TextMessage").toString()) {
					
	
						//Careers - Test server 3 - Front page - Irshad
						
					case "Validate_Jobs_section":
						
						context.setAttribute("fileName", "Validate_Jobs_section");
						ClubStudio.Validate_Jobs_section(testdata.get("TextMessage").toString());
						context.setAttribute("fileName", "Validate_Jobs_section");
						driver.quit();
						break;
						
						
					case "Validate_All_jobs_in_careers":
						
						context.setAttribute("fileName", "Validate_All_jobs_in_careers");
						ClubStudio.Validate_All_jobs_in_careers(testdata.get("TextMessage").toString(), Text_input);
						context.setAttribute("fileName", "Validate_All_jobs_in_careers");
						driver.quit();
						break;
						
					case "Validate_Job_details":
						
						context.setAttribute("fileName", "Validate_Job_details");
						ClubStudio.Validate_Job_details(testdata.get("TextMessage").toString(), Text_input);
						context.setAttribute("fileName", "Validate_Job_details");
						driver.quit();
						break;
						
					case "Validate_Job_des":
						
						context.setAttribute("fileName", "Validate_Job_des");
						ClubStudio.Validate_Job_des(testdata.get("TextMessage").toString(), Text_input, input_data);
						context.setAttribute("fileName", "Validate_Job_des");
						driver.quit();
						break;
						
					case "Validate_Job_moreinfopopup":
						
						context.setAttribute("fileName", "Validate_Job_moreinfopopup");
						ClubStudio.Validate_Job_moreinfopopup(testdata.get("TextMessage").toString(), Text_input);
						context.setAttribute("fileName", "Validate_Job_moreinfopopup");
						driver.quit();
						break;
						
					case "Validate_Job_apply_btn":
						
						context.setAttribute("fileName", "Validate_Job_apply_btn");
						ClubStudio.Validate_Job_apply_btn(testdata.get("TextMessage").toString(), Text_input);
						context.setAttribute("fileName", "Validate_Job_apply_btn");
						driver.quit();
						break;
						
					case "Validate_popup_window":
						
						context.setAttribute("fileName", "Validate_popup_window");
						ClubStudio.Validate_popup_window(testdata.get("TextMessage").toString(), Text_input);
						context.setAttribute("fileName", "Validate_popup_window");
						driver.quit();
						break;
						
						
					case "Validate_window_allfields":
						
						context.setAttribute("fileName", "Validate_window_allfields");
						ClubStudio.Validate_window_allfields(testdata.get("TextMessage").toString(), Text_input, input_data);
						context.setAttribute("fileName", "Validate_window_allfields");
						driver.quit();
						break;
						
						
						
					case "Validate_emp_para":
						
						context.setAttribute("fileName", "Validate_emp_para");
						ClubStudio.Validate_emp_para(testdata.get("TextMessage").toString(), Text_input, additional_input);
						context.setAttribute("fileName", "Validate_emp_para");
						driver.quit();
						break;
						
						
					case "Validate_App_info_text":
						
						context.setAttribute("fileName", "Validate_App_info_text");
						ClubStudio.Validate_App_info_text(testdata.get("TextMessage").toString(), Text_input, additional_input);
						context.setAttribute("fileName", "Validate_App_info_text");
						driver.quit();
						break;
						
						
					case "Validate_all_ip_fields_in_emp_page":
						
						context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page");
						ClubStudio.Validate_all_ip_fields_in_emp_page(testdata.get("TextMessage").toString(), Text_input);
						context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page");
						driver.quit();
						break;
						
						
					case "Validate_Howdidyouhearaboutus_dd":
						
						context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd");
						ClubStudio.Validate_Howdidyouhearaboutus_dd(testdata.get("TextMessage").toString(), Text_input, Dropdown_values);
						context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd");
						driver.quit();
						break;
						
					case "Validate_Radiobtn18YearsOld_options":
						
						context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options");
						ClubStudio.Validate_Radiobtn18YearsOld_options(testdata.get("TextMessage").toString(), Text_input);
						context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options");
						driver.quit();
						break;
						
						
					case "Validate_US_format_text":
						
						context.setAttribute("fileName", "Validate_US_format_text");
						ClubStudio.Validate_US_format_text(testdata.get("TextMessage").toString(), Text_input, additional_input);
						context.setAttribute("fileName", "Validate_US_format_text");
						driver.quit();
						break;
						
						
					case "Validate_Miles_text":
						
						context.setAttribute("fileName", "Validate_Miles_text");
						ClubStudio.Validate_Miles_text(testdata.get("TextMessage").toString(), Text_input, additional_input);
						context.setAttribute("fileName", "Validate_Miles_text");
						driver.quit();
						break;
						
					case "Validate_phone_errorlabel":
						
						context.setAttribute("fileName", "Validate_phone_errorlabel");
						ClubStudio.Validate_phone_errorlabel(testdata.get("TextMessage").toString(), Text_input, additional_input);
						context.setAttribute("fileName", "Validate_phone_errorlabel");
						driver.quit();
						break;
						
						
					case "Validate_Next_step_button_in_l1":
						
						context.setAttribute("fileName", "Validate_Next_step_button_in_l1");
						ClubStudio.Validate_Next_step_button_in_l1(testdata.get("TextMessage").toString(), Text_input);
						context.setAttribute("fileName", "Validate_Next_step_button_in_l1");
						driver.quit();
						break;
						
						
					case "Validate_input_in_all_fields":
						
					context.setAttribute("fileName", "Validate_input_in_all_fields");
					ClubStudio.Validate_input_in_all_fields(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode  );
					context.setAttribute("fileName", "Validate_input_in_all_fields");
					driver.quit();break;
						
					
					case "Validate_List18YrsOld_No_popupalrt":
						
						context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt");
						ClubStudio.Validate_List18YrsOld_No_popupalrt(testdata.get("TextMessage").toString(), Text_input, Radiobtn18YearsOld);
						context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt");
						driver.quit();
						break;
						
						
						
					case "Validate_Next_step_l1":
						
					context.setAttribute("fileName", "Validate_Next_step_l1");
					ClubStudio.Validate_Next_step_l1(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
					context.setAttribute("fileName", "Validate_Next_step_l1");
					driver.quit();break;
						
						
					
					case "Validate_education_level_dd":
						
					context.setAttribute("fileName", "Validate_education_level_dd");
					ClubStudio.Validate_education_level_dd(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
					context.setAttribute("fileName", "Validate_education_level_dd");
					driver.quit();break;
					
						
					
					case "Validate_edu_level_dd_allvalues":
						
					context.setAttribute("fileName", "Validate_edu_level_dd_allvalues");
					ClubStudio.Validate_edu_level_dd_allvalues(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_edu_level_dd_allvalues");
					driver.quit();break;
					
					
					
					case "Validate_previous_next_step_buttons_l2":
						
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2");
					ClubStudio.Validate_previous_next_step_buttons_l2(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2");
					driver.quit();break;
					
					
					case "Validate_previous_step_button_l2":
						
					context.setAttribute("fileName", "Validate_previous_step_button_l2");
					ClubStudio.Validate_previous_step_button_l2(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
					context.setAttribute("fileName", "Validate_previous_step_button_l2");
					driver.quit();break;
					
					
					case "Validate_Next_step_button_l2":
						
					context.setAttribute("fileName", "Validate_Next_step_button_l2");
					ClubStudio.Validate_Next_step_button_l2(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown  );
					context.setAttribute("fileName", "Validate_Next_step_button_l2");
					driver.quit();break;
					

					case "Validate_Exp_info_text_in_l3":
						
					context.setAttribute("fileName", "Validate_Exp_info_text_in_l3");
					ClubStudio.Validate_Exp_info_text_in_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
					context.setAttribute("fileName", "Validate_Exp_info_text_in_l3");
					driver.quit();break;
					
					
					case "Validate_sales_mngnt_exp_text_in_l3":
						
					context.setAttribute("fileName", "Validate_sales_mngnt_exp_text_in_l3");
					ClubStudio.Validate_sales_mngnt_exp_text_in_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
					context.setAttribute("fileName", "Validate_sales_mngnt_exp_text_in_l3");
					driver.quit();break;
					
					case "Validate_Equipment_Techn_exp_heading_l3":
						
					context.setAttribute("fileName", "Validate_Equipment_Techn_exp_heading_l3");
					ClubStudio.Validate_Equipment_Techn_exp_heading_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
					context.setAttribute("fileName", "Validate_Equipment_Techn_exp_heading_l3");
					driver.quit();break;
					
					case "Validate_all_dropdowns_in_l3":
						
					context.setAttribute("fileName", "Validate_all_dropdowns_in_l3");
					ClubStudio.Validate_all_dropdowns_in_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown  );
					context.setAttribute("fileName", "Validate_all_dropdowns_in_l3");
					driver.quit();break;
					
					case "Validate_all_options_FSE_dd_l3":
						
					context.setAttribute("fileName", "Validate_all_options_FSE_dd_l3");
					ClubStudio.Validate_all_options_FSE_dd_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
					context.setAttribute("fileName", "Validate_all_options_FSE_dd_l3");
					driver.quit();break;
					
					
					case "Validate_all_options_PTSE_dd_l3":
						
					context.setAttribute("fileName", "Validate_all_options_PTSE_dd_l3");
					ClubStudio.Validate_all_options_PTSE_dd_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
					context.setAttribute("fileName", "Validate_all_options_PTSE_dd_l3");
					driver.quit();break;
					
					case "Validate_all_options_ME_dd_l3":
						
					context.setAttribute("fileName", "Validate_all_options_ME_dd_l3");
					ClubStudio.Validate_all_options_ME_dd_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
					context.setAttribute("fileName", "Validate_all_options_ME_dd_l3");
					driver.quit();break;
					
					case "Validate_all_options_BE_dd_l3":
						
					context.setAttribute("fileName", "Validate_all_options_BE_dd_l3");
					ClubStudio.Validate_all_options_BE_dd_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
					context.setAttribute("fileName", "Validate_all_options_BE_dd_l3");
					driver.quit();break;
					
					case "Validate_all_options_YE_dd_l3":
						
					context.setAttribute("fileName", "Validate_all_options_YE_dd_l3");
					ClubStudio.Validate_all_options_YE_dd_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
					context.setAttribute("fileName", "Validate_all_options_YE_dd_l3");
					driver.quit();break;
					
					case "Validate_selecting_all_dds_in_l3":
						
					context.setAttribute("fileName", "Validate_selecting_all_dds_in_l3");
					ClubStudio.Validate_selecting_all_dds_in_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
					context.setAttribute("fileName", "Validate_selecting_all_dds_in_l3");
					driver.quit();break;
					
					
					case "Validate_Skills_section_l3":
						
					context.setAttribute("fileName", "Validate_Skills_section_l3");
					ClubStudio.Validate_Skills_section_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data, input_data1 );
					context.setAttribute("fileName", "Validate_Skills_section_l3");
					driver.quit();break;
					
					case "Validate_select_Skills_l3":
						
					context.setAttribute("fileName", "Validate_select_Skills_l3");
					ClubStudio.Validate_select_Skills_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data );
					context.setAttribute("fileName", "Validate_select_Skills_l3");
					driver.quit();break;
					

					case "Validate_Skills_2_section_l3":
						
					context.setAttribute("fileName", "Validate_Skills_2_section_l3");
					ClubStudio.Validate_Skills_2_section_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data, input_data1 );
					context.setAttribute("fileName", "Validate_Skills_2_section_l3");
					driver.quit();break;
					
					case "Validate_select_Skills_2_l3":
						
					context.setAttribute("fileName", "Validate_select_Skills_2_l3");
					ClubStudio.Validate_select_Skills_2_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data );
					context.setAttribute("fileName", "Validate_select_Skills_2_l3");
					driver.quit();break;

					
					case "Validate_Next_step_in_l3":
						
					context.setAttribute("fileName", "Validate_Next_step_in_l3");
					ClubStudio.Validate_Next_step_in_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
					context.setAttribute("fileName", "Validate_Next_step_in_l3");
					driver.quit();break;
					
					
					case "Validate_Prev_next_btns_l3":
						
					context.setAttribute("fileName", "Validate_Prev_next_btns_l3");
					ClubStudio.Validate_Prev_next_btns_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_Prev_next_btns_l3");
					driver.quit();break;
					
					
					case "Validate_Prev_step_in_l3":
						
					context.setAttribute("fileName", "Validate_Prev_step_in_l3");
					ClubStudio.Validate_Prev_step_in_l3(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_Prev_step_in_l3");
					driver.quit();break;
					
					
					
					case "Validate_EmpHis_PreEmp_texts_in_l4":
						
					context.setAttribute("fileName", "Validate_EmpHis_PreEmp_texts_in_l4");
					ClubStudio.Validate_EmpHis_PreEmp_texts_in_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
					context.setAttribute("fileName", "Validate_EmpHis_PreEmp_texts_in_l4");
					driver.quit();break;
					
					
					case "Validate_rdobtns_of_EmpHis_in_l4":
						
					context.setAttribute("fileName", "Validate_rdobtns_of_EmpHis_in_l4");
					ClubStudio.Validate_rdobtns_of_EmpHis_in_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
					context.setAttribute("fileName", "Validate_rdobtns_of_EmpHis_in_l4");
					driver.quit();break;
					
					case "Validate_upload_res_chkbx_in_l4":
						
					context.setAttribute("fileName", "Validate_upload_res_chkbx_in_l4");
					ClubStudio.Validate_upload_res_chkbx_in_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
					context.setAttribute("fileName", "Validate_upload_res_chkbx_in_l4");
					driver.quit();break;
					
					
					
					case "Validate_upload_res_section_in_l4":
						
					context.setAttribute("fileName", "Validate_upload_res_section_in_l4");
					ClubStudio.Validate_upload_res_section_in_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, input_data2);
					context.setAttribute("fileName", "Validate_upload_res_section_in_l4");
					driver.quit();break;
					
					
					case "Validate_upload_res_file_l4":
						
					context.setAttribute("fileName", "Validate_upload_res_section_in_l4");
					ClubStudio.Validate_upload_res_file_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, input_data2, File_name);
					context.setAttribute("fileName", "Validate_upload_res_file_l4");
					driver.quit();break;
					
					
					
					case "Validate_cur_prev_emp_texts_in_l4":
						
					context.setAttribute("fileName", "Validate_cur_prev_emp_texts_in_l4");
					ClubStudio.Validate_cur_prev_emp_texts_in_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1,input_data2 );
					context.setAttribute("fileName", "Validate_cur_prev_emp_texts_in_l4");
					driver.quit();break;
					
					
					case "Validate_all_ip_fields_in_l4":
						
					context.setAttribute("fileName", "Validate_all_ip_fields_in_l4");
					ClubStudio.Validate_all_ip_fields_in_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
					context.setAttribute("fileName", "Validate_all_ip_fields_in_l4");
					driver.quit();break;
					
					
					case "Validate_input_inallfields_in_l4":
						
					context.setAttribute("fileName", "Validate_input_inallfields_in_l4");
					ClubStudio.Validate_input_inallfields_in_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button );
					context.setAttribute("fileName", "Validate_input_inallfields_in_l4");
					driver.quit();break;
					
					
					case "Validate_prev_next_step_btns_in_l4":
						
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4");
					ClubStudio.Validate_prev_next_step_btns_in_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4");
					driver.quit();break;
					
					
					case "Validate_AddEmployer_2_btn_in_l4":
						
					context.setAttribute("fileName", "Validate_AddEmployer_2_btn_in_l4");
					ClubStudio.Validate_AddEmployer_2_btn_in_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
					context.setAttribute("fileName", "Validate_AddEmployer_2_btn_in_l4");
					driver.quit();break;
					
					
					case "Validate_Next_btn_in_l4":
						
					context.setAttribute("fileName", "Validate_Next_btn_in_l4");
					ClubStudio.Validate_Next_btn_in_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name);
					context.setAttribute("fileName", "Validate_Next_btn_in_l4");
					driver.quit();break;
					
					case "Validate_No_Prev_Emp_RdoBtn_in_l4":
						
					context.setAttribute("fileName", "Validate_No_Prev_Emp_RdoBtn_in_l4");
					ClubStudio.Validate_No_Prev_Emp_RdoBtn_in_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
					context.setAttribute("fileName", "Validate_No_Prev_Emp_RdoBtn_in_l4");
					driver.quit();break;
					
					case "Validate_prev_step_btn_in_l4":
						
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l4");
					ClubStudio.Validate_prev_step_btn_in_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l4");
					driver.quit();break;
				
					
					case "Validate_all_ip_fieldsofAddemplr2_in_l4":
						
					context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr2_in_l4");
					ClubStudio.Validate_all_ip_fieldsofAddemplr2_in_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
					context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr2_in_l4");
					driver.quit();break;
					
					
					case "Validate_all_ip_fieldsofAddemplr3_in_l4":
						
					context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr3_in_l4");
					ClubStudio.Validate_all_ip_fieldsofAddemplr3_in_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
					context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr3_in_l4");
					driver.quit();break;
					
					
					case "Validate_removebtn2_by_ipingempr2_in_l4":
						
					context.setAttribute("fileName", "Validate_removebtn2_by_ipingempr2_in_l4");
					ClubStudio.Validate_removebtn2_by_ipingempr2_in_l4(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button );
					context.setAttribute("fileName", "Validate_removebtn2_by_ipingempr2_in_l4");
					driver.quit();break;
					
					
					case "Validate_Ind_langs_text_l5":
						
					context.setAttribute("fileName", "Validate_Ind_langs_text_l5");
					ClubStudio.Validate_Ind_langs_text_l5(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, input_data2);
					context.setAttribute("fileName", "Validate_Ind_langs_text_l5");
					driver.quit();break;
					
					
					case "Validate_all_langs_in_l5":
						
					context.setAttribute("fileName", "Validate_all_langs_in_l5");
					ClubStudio.Validate_all_langs_in_l5(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
					context.setAttribute("fileName", "Validate_all_langs_in_l5");
					driver.quit();break;
					
					
					
					case "Validate_bydefault_Eng_lang_sltd_in_l5":
						
					context.setAttribute("fileName", "Validate_bydefault_Eng_lang_sltd_in_l5");
					ClubStudio.Validate_bydefault_Eng_lang_sltd_in_l5(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
					context.setAttribute("fileName", "Validate_bydefault_Eng_lang_sltd_in_l5");
					driver.quit();break;
					
					
					case "Validate_slt_desired_langs_in_l5":
						
					context.setAttribute("fileName", "Validate_slt_desired_langs_in_l5");
					ClubStudio.Validate_slt_desired_langs_in_l5(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
					context.setAttribute("fileName", "Validate_slt_desired_langs_in_l5");
					driver.quit();break;
					

					case "Validate_prev_next_step_btns_in_l5":
						
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5");
					ClubStudio.Validate_prev_next_step_btns_in_l5(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name);
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5");
					driver.quit();break;
					
					
					case "Validate_prev_step_btn_in_l5":
						
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l5");
					ClubStudio.Validate_prev_step_btn_in_l5(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name);
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l5");
					driver.quit();break;
					
					
					case "Validate_Next_step_btn_in_l5":
						
					context.setAttribute("fileName", "Validate_Next_step_btn_in_l5");
					ClubStudio.Validate_Next_step_btn_in_l5(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
					context.setAttribute("fileName", "Validate_Next_step_btn_in_l5");
					driver.quit();break;
					
					
					case "Validate_text_COqualify_in_l6":
						
					context.setAttribute("fileName", "Validate_text_COqualify_in_l6");
					ClubStudio.Validate_text_COqualify_in_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data3);
					context.setAttribute("fileName", "Validate_text_COqualify_in_l6");
					driver.quit();break;	
					
					
					case "Validate_all_fields_in_l6":
						
					context.setAttribute("fileName", "Validate_all_fields_in_l6");
					ClubStudio.Validate_all_fields_in_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Considered_for_chkbx);
					context.setAttribute("fileName", "Validate_all_fields_in_l6");
					driver.quit();break;
					
					
					case "Validate_slt_Worktime_l6":
						
					context.setAttribute("fileName", "Validate_slt_Worktime_l6");
					ClubStudio.Validate_slt_Worktime_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time);
					context.setAttribute("fileName", "Validate_slt_Worktime_l6");
					driver.quit();break;
					
					
					case "Validate_slt_considerfor_chkbxs_l6":
						
					context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6");
					ClubStudio.Validate_slt_considerfor_chkbxs_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx);
					context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6");
					driver.quit();break;
					
					
					case "Validate_deslt_considerfor_chkbxs_l6":
						
					context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6");
					ClubStudio.Validate_deslt_considerfor_chkbxs_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx);
					context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6");
					driver.quit();break;
					
					
					
					case "Validate_COs_asperCFchkbxsltn_l6":
						
					context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6");
					ClubStudio.Validate_COs_asperCFchkbxsltn_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx);
					context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6");
					driver.quit();break;
					
					
					case "Validate_COs_asperCFchkbxdesltn_l6":
						
					context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6");
					ClubStudio.Validate_COs_asperCFchkbxdesltn_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx , input_data4);
					context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6");
					driver.quit();break;
					
					
					
					case "Validate_defaultvalueofCO_l6":
						
					context.setAttribute("fileName", "Validate_defaultvalueofCO_l6");
					ClubStudio.Validate_defaultvalueofCO_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Considered_for_chkbx);
					context.setAttribute("fileName", "Validate_defaultvalueofCO_l6");
					driver.quit();break;
					
					
					case "Validate_ip_date_to_begin_l6":
						
					context.setAttribute("fileName", "Validate_ip_date_to_begin_l6");
					ClubStudio.Validate_ip_date_to_begin_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Date_to_begin );
					context.setAttribute("fileName", "Validate_ip_date_to_begin_l6");
					driver.quit();break;
					
					
					case "Validate_empdwithus_no_rdobtn_l6":
						
					context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6");
					ClubStudio.Validate_empdwithus_no_rdobtn_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
					context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6");
					driver.quit();break;
					
					case "Validate_basedonsltns_text_l6":
						
					context.setAttribute("fileName", "Validate_basedonsltns_text_l6");
					ClubStudio.Validate_basedonsltns_text_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
					context.setAttribute("fileName", "Validate_basedonsltns_text_l6");
					driver.quit();break;
					
					
					case "Validate_Club_locations_l6":
						
					context.setAttribute("fileName", "Validate_Club_locations_l6");
					ClubStudio.Validate_Club_locations_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
					context.setAttribute("fileName", "Validate_Club_locations_l6");
					driver.quit();break;
					
					
					case "Validate_Rehire_Questionnaire_sec_l6":
						
					context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l6");
					ClubStudio.Validate_Rehire_Questionnaire_sec_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
					context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l6");
					driver.quit();break;
					
					
					
					case "Validate_Resigned_dd_allvalues_l6":
						
					context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6");
					ClubStudio.Validate_Resigned_dd_allvalues_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, EmploymentHowResigned_dd );
					context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6");
					driver.quit();break;
					
					
					
					case "Validate_ip_in_RQ_sec_l6":
						
					context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6");
					ClubStudio.Validate_ip_in_RQ_sec_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
					context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6");
					driver.quit();break;
					
					case "Validate_prev_next_step_btns_l6":
						
					context.setAttribute("fileName", "Validate_prev_next_step_btns_l6");
					ClubStudio.Validate_prev_next_step_btns_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages );
					context.setAttribute("fileName", "Validate_prev_next_step_btns_l6");
					driver.quit();break;
					
					
					case "Validate_prev_step_btn_in_l6":
						
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l6");
					ClubStudio.Validate_prev_step_btn_in_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages );
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l6");
					driver.quit();break;
					
					case "Validate_next_btn_byipallfields_l6":
						
					context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6");
					ClubStudio.Validate_next_btn_byipallfields_l6(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
					context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6");
					driver.quit();break;
					
					
					
					case "Validate_paras_in_l7":
						
					context.setAttribute("fileName", "Validate_paras_in_l7");
					ClubStudio.Validate_paras_in_l7(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, input_data2 );
					context.setAttribute("fileName", "Validate_paras_in_l7");
					driver.quit();break;
					
					
					
					case "Validate_rdobtns_in_l7":
						
					context.setAttribute("fileName", "Validate_rdobtns_in_l7");
					ClubStudio.Validate_rdobtns_in_l7(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
					context.setAttribute("fileName", "Validate_rdobtns_in_l7");
					driver.quit();break;
					
					
					case "Validate_all_form_sec_in_l7":
						
					context.setAttribute("fileName", "Validate_all_form_sec_in_l7");
					ClubStudio.Validate_all_form_sec_in_l7(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
					context.setAttribute("fileName", "Validate_all_form_sec_in_l7");
					driver.quit();break;
					
					
					
					case "Validate_all_options_of_Gender_dd_in_l7":
						
					context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7");
					ClubStudio.Validate_all_options_of_Gender_dd_in_l7(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd );
					context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7");
					driver.quit();break;
					
					
					case "Validate_all_options_of_RaceEthnicity_dd_in_l7":
						
					context.setAttribute("fileName", "Validate_all_options_of_RaceEthnicity_dd_in_l7");
					ClubStudio.Validate_all_options_of_RaceEthnicity_dd_in_l7(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, RaceEthnicity_dd );
					context.setAttribute("fileName", "Validate_all_options_of_RaceEthnicity_dd_in_l7");
					driver.quit();break;
					
					
					case "Validate_EOE_details_paras_in_l7":
						
					context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7");
					ClubStudio.Validate_EOE_details_paras_in_l7(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, input_data2 );
					context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7");
					driver.quit();break;
					
					
					
					case "Validate_No_rdobtnof_form_sec_in_l7":
						
					context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7");
					ClubStudio.Validate_No_rdobtnof_form_sec_in_l7(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
					context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7");
					driver.quit();break;
					
					
					case "Validate_prev_next_step_btns_in_l7":
						
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7");
					ClubStudio.Validate_prev_next_step_btns_in_l7(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7");
					driver.quit();break;
					
					case "Validate_prev_step_btn_in_l7":
						
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l7");
					ClubStudio.Validate_prev_step_btn_in_l7(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l7");
					driver.quit();break;
					
					
					case "Validate_Next_step_btn_in_l7":
						
					context.setAttribute("fileName", "Validate_Next_step_btn_in_l7");
					ClubStudio.Validate_Next_step_btn_in_l7(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
					context.setAttribute("fileName", "Validate_Next_step_btn_in_l7");
					driver.quit();break;
					
					
					case "Validate_Nav_to_l8":
						
					context.setAttribute("fileName", "Validate_Nav_to_l8");
					ClubStudio.Validate_Nav_to_l8(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
					context.setAttribute("fileName", "Validate_Nav_to_l8");
					driver.quit();break;
					
					
					case "Validate_AS_paras_in_l8":
						
					context.setAttribute("fileName", "Validate_AS_paras_in_l8");
					ClubStudio.Validate_AS_paras_in_l8(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
					context.setAttribute("fileName", "Validate_AS_paras_in_l8");
					driver.quit();break;
					
					
					case "Validate_ackmnt_in_l8":
						
					context.setAttribute("fileName", "Validate_ackmnt_in_l8");
					ClubStudio.Validate_ackmnt_in_l8(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
					context.setAttribute("fileName", "Validate_ackmnt_in_l8");
					driver.quit();break;
					
					
					
					case "Validate_ip_in_Signedbyname_in_l8":
						
					context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8");
					ClubStudio.Validate_ip_in_Signedbyname_in_l8(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
					context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8");
					driver.quit();break;
					
					
					case "Validate_prev_next_step_btns_in_l8":
						
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8");
					ClubStudio.Validate_prev_next_step_btns_in_l8(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8");
					driver.quit();break;
					
					
					case "Validate_prev_step_btn_in_l8":
						
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l8");
					ClubStudio.Validate_prev_step_btn_in_l8(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l8");
					driver.quit();break;
					
					
					
					case "Validate_Next_btn_in_l8":
						
					context.setAttribute("fileName", "Validate_Next_btn_in_l8");
					ClubStudio.Validate_Next_btn_in_l8(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
					context.setAttribute("fileName", "Validate_Next_btn_in_l8");
					driver.quit();break;
					
					
					
					case "Validate_heading_in_l9":
						
					context.setAttribute("fileName", "Validate_heading_in_l9");
					ClubStudio.Validate_heading_in_l9(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
					context.setAttribute("fileName", "Validate_heading_in_l9");
					driver.quit();break;
					
					
					case "Validate_Rules_procedures_in_l9":
						
					context.setAttribute("fileName", "Validate_Rules_procedures_in_l9");
					ClubStudio.Validate_Rules_procedures_in_l9(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
					context.setAttribute("fileName", "Validate_Rules_procedures_in_l9");
					driver.quit();break;
					
					
					
					case "Validate_ip_in_prtname_dateandipadd_in_l9":
						
					context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9");
					ClubStudio.Validate_ip_in_prtname_dateandipadd_in_l9(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, IP_Address );
					context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9");
					driver.quit();break;
					
					
					
					case "Validate_Robert_Bryant_Sign_in_l9":
						
					context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9");
					ClubStudio.Validate_Robert_Bryant_Sign_in_l9(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
					context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9");
					driver.quit();break;
					
					
					
					case "Validate_Iagree_textandbtn_in_l9":
						
					context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9");
					ClubStudio.Validate_Iagree_textandbtn_in_l9(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
					context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9");
					driver.quit();break;
					
					case "Validate_Prev_step_btn_in_l9":
						
					context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9");
					ClubStudio.Validate_Prev_step_btn_in_l9(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
					context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9");
					driver.quit();break;
					
					
					case "Validate_Iagreebtn_and_succ_submsn_in_l9":
						
					context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9");
					ClubStudio.Validate_Iagreebtn_and_succ_submsn_in_l9(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
					context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9");
					driver.quit();break;
					
					case "Validate_Success_msg_in_final_page":
						
					context.setAttribute("fileName", "Validate_Success_msg_in_final_page");
					ClubStudio.Validate_Success_msg_in_final_page(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
					context.setAttribute("fileName", "Validate_Success_msg_in_final_page");
					driver.quit();break;
					
					
					case "Validate_prtbtn_in_print_emp_app_page":
						
					context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page");
					ClubStudio.Validate_prtbtn_in_print_emp_app_page(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
					context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page");
					driver.quit();break;
					
					
					
					case "Validate_Rules_link_in_l9":
						
					context.setAttribute("fileName", "Validate_Rules_link_in_l9");
					ClubStudio.Validate_Rules_link_in_l9(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
					context.setAttribute("fileName", "Validate_Rules_link_in_l9");
					driver.quit();break;
					
					
					
					case "Validate_emp_para_RI":
						
						context.setAttribute("fileName", "Validate_emp_para_RI");
						ClubStudio.Validate_emp_para_RI(testdata.get("TextMessage").toString(), Text_input, additional_input);
						context.setAttribute("fileName", "Validate_emp_para_RI");
						driver.quit();
						break;
					
						

					case "Validate_App_info_text_RI":
						
						context.setAttribute("fileName", "Validate_App_info_text_RI");
						ClubStudio.Validate_App_info_text_RI(testdata.get("TextMessage").toString(), Text_input, additional_input);
						context.setAttribute("fileName", "Validate_App_info_text_RI");
						driver.quit();
						break;
						
						
					case "Validate_all_ip_fields_in_emp_page_RI":
						
						context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page_RI");
						ClubStudio.Validate_all_ip_fields_in_emp_page_RI(testdata.get("TextMessage").toString(), Text_input);
						context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page_RI");
						driver.quit();
						break;
						
						
					case "Validate_Howdidyouhearaboutus_dd_RI":
						
						context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd_RI");
						ClubStudio.Validate_Howdidyouhearaboutus_dd_RI(testdata.get("TextMessage").toString(), Text_input, Dropdown_values);
						context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd_RI");
						driver.quit();
						break;
						
					case "Validate_Radiobtn18YearsOld_options_RI":
						
						context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_RI");
						ClubStudio.Validate_Radiobtn18YearsOld_options_RI(testdata.get("TextMessage").toString(), Text_input);
						context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_RI");
						driver.quit();
						break;
						
						
					case "Validate_US_format_text_RI":
						
						context.setAttribute("fileName", "Validate_US_format_text_RI");
						ClubStudio.Validate_US_format_text_RI(testdata.get("TextMessage").toString(), Text_input, additional_input);
						context.setAttribute("fileName", "Validate_US_format_text_RI");
						driver.quit();
						break;
						
						
					case "Validate_Miles_text_RI":
						
						context.setAttribute("fileName", "Validate_Miles_text_RI");
						ClubStudio.Validate_Miles_text_RI(testdata.get("TextMessage").toString(), Text_input, additional_input);
						context.setAttribute("fileName", "Validate_Miles_text_RI");
						driver.quit();
						break;
						
					case "Validate_phone_errorlabel_RI":
						
						context.setAttribute("fileName", "Validate_phone_errorlabel_RI");
						ClubStudio.Validate_phone_errorlabel_RI(testdata.get("TextMessage").toString(), Text_input, additional_input);
						context.setAttribute("fileName", "Validate_phone_errorlabel_RI");
						driver.quit();
						break;
						
						
					case "Validate_Next_step_button_in_l1_RI":
						
						context.setAttribute("fileName", "Validate_Next_step_button_in_l1_RI");
						ClubStudio.Validate_Next_step_button_in_l1_RI(testdata.get("TextMessage").toString(), Text_input);
						context.setAttribute("fileName", "Validate_Next_step_button_in_l1_RI");
						driver.quit();
						break;
						
						
						
					case "Validate_input_in_all_fields_RI":
						
					context.setAttribute("fileName", "Validate_input_in_all_fields_RI");
					ClubStudio.Validate_input_in_all_fields_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode  );
					context.setAttribute("fileName", "Validate_input_in_all_fields_RI");
					driver.quit();break;
						
					
					
					case "Validate_List18YrsOld_No_popupalrt_RI":
						
						context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt_RI");
						ClubStudio.Validate_List18YrsOld_No_popupalrt_RI(testdata.get("TextMessage").toString(), Text_input, Radiobtn18YearsOld);
						context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt_RI");
						driver.quit();
						break;
						
						
						
					case "Validate_Next_step_l1_RI":
						
					context.setAttribute("fileName", "Validate_Next_step_l1_RI");
					ClubStudio.Validate_Next_step_l1_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
					context.setAttribute("fileName", "Validate_Next_step_l1_RI");
					driver.quit();break;
						
					
					case "Validate_education_level_dd_RI":
						
					context.setAttribute("fileName", "Validate_education_level_dd_RI");
					ClubStudio.Validate_education_level_dd_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
					context.setAttribute("fileName", "Validate_education_level_dd_RI");
					driver.quit();break;
					
						
					
					case "Validate_edu_level_dd_allvalues_RI":
						
					context.setAttribute("fileName", "Validate_edu_level_dd_allvalues_RI");
					ClubStudio.Validate_edu_level_dd_allvalues_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_edu_level_dd_allvalues_RI");
					driver.quit();break;
					
					
					
					case "Validate_previous_next_step_buttons_l2_RI":
						
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2_RI");
					ClubStudio.Validate_previous_next_step_buttons_l2_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2_RI");
					driver.quit();break;
					
					
					case "Validate_previous_step_button_l2_RI":
						
					context.setAttribute("fileName", "Validate_previous_step_button_l2_RI");
					ClubStudio.Validate_previous_step_button_l2_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
					context.setAttribute("fileName", "Validate_previous_step_button_l2_RI");
					driver.quit();break;
					
					
					case "Validate_Next_step_button_l2_RI":
						
					context.setAttribute("fileName", "Validate_Next_step_button_l2_RI");
					ClubStudio.Validate_Next_step_button_l2_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown  );
					context.setAttribute("fileName", "Validate_Next_step_button_l2_RI");
					driver.quit();break;
					
					case "Validate_Exp_info_text_in_l3_RI":
						
					context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_RI");
					ClubStudio.Validate_Exp_info_text_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
					context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_RI");
					driver.quit();break;
					
					case "Validate_GP_AI_text_in_l3_RI":
						
					context.setAttribute("fileName", "Validate_GP_AI_text_in_l3_RI");
					ClubStudio.Validate_GP_AI_text_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
					context.setAttribute("fileName", "Validate_GP_AI_text_in_l3_RI");
					driver.quit();break;
					
					
					case "Validate_GP_AI_exp_dd_in_l3_RI":
						
					context.setAttribute("fileName", "Validate_GP_AI_exp_dd_in_l3_RI");
					ClubStudio.Validate_GP_AI_exp_dd_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown  );
					context.setAttribute("fileName", "Validate_GP_AI_exp_dd_in_l3_RI");
					driver.quit();break;
					
					
					case "Validate_GP_AI_exp_dd_all_values_in_l3_RI":
						
					context.setAttribute("fileName", "Validate_GP_AI_exp_dd_all_values_in_l3_RI");
					ClubStudio.Validate_GP_AI_exp_dd_all_values_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
					context.setAttribute("fileName", "Validate_GP_AI_exp_dd_all_values_in_l3_RI");
					driver.quit();break;
					
					
					case "Validate_Hold_a_Cert_rdo_btns_in_l3_RI":
						
					context.setAttribute("fileName", "Validate_Hold_a_Cert_rdo_btns_in_l3_RI");
					ClubStudio.Validate_Hold_a_Cert_rdo_btns_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_Hold_a_Cert_rdo_btns_in_l3_RI");
					driver.quit();break;
					
					case "Validate_GF_A_CertfnInfo_link_RI":
						
					context.setAttribute("fileName", "Validate_GF_A_CertfnInfo_link_RI");
					ClubStudio.Validate_GF_A_CertfnInfo_link_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_GF_A_CertfnInfo_link_RI");
					driver.quit();break;
					
					
					case "Validate_prev_next_step_btns_in_l3_RI":
						
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l3_RI");
					ClubStudio.Validate_prev_next_step_btns_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l3_RI");
					driver.quit();break;
					
					
					case "Validate_previous_step_btn_in_l3_RI":
						
					context.setAttribute("fileName", "Validate_previous_step_btn_in_l3_RI");
					ClubStudio.Validate_previous_step_btn_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_previous_step_btn_in_l3_RI");
					driver.quit();break;
					
					
					case "Validate_next_step_btn_in_l3_RI":
						
						context.setAttribute("fileName", "Validate_next_step_btn_in_l3_RI");
						ClubStudio.Validate_next_step_btn_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
						context.setAttribute("fileName", "Validate_next_step_btn_in_l3_RI");
						driver.quit();break;

						
					case "Validate_exp_details_texts_in_l3_RI":
						
					context.setAttribute("fileName", "Validate_exp_details_texts_in_l3_RI");
					ClubStudio.Validate_exp_details_texts_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD, input_data);
					context.setAttribute("fileName", "Validate_exp_details_texts_in_l3_RI");
					driver.quit();break;
							
						
					case "Validate_add_employer_btn_in_l3_RI":
						
						context.setAttribute("fileName", "Validate_add_employer_btn_in_l3_RI");
						ClubStudio.Validate_add_employer_btn_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD);
						context.setAttribute("fileName", "Validate_add_employer_btn_in_l3_RI");
						driver.quit();break;
					
					
					case "Validate_TP_CE_CW_elements_in_l3_RI":
						
						context.setAttribute("fileName", "Validate_TP_CE_CW_elements_in_l3_RI");
						ClubStudio.Validate_TP_CE_CW_elements_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD);
						context.setAttribute("fileName", "Validate_TP_CE_CW_elements_in_l3_RI");
						driver.quit();break;
						
						
						case "Validate_AE_sec2_allelements_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_AE_sec2_allelements_in_l3_RI");
							ClubStudio.Validate_AE_sec2_allelements_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,input_data,Checkbox_class_formats);
							context.setAttribute("fileName", "Validate_AE_sec2_allelements_in_l3_RI");
							driver.quit();break;
					
						case "Validate_AE_sec3_allelements_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_AE_sec3_allelements_in_l3_RI");
							ClubStudio.Validate_AE_sec3_allelements_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,input_data,Checkbox_class_formats);
							context.setAttribute("fileName", "Validate_AE_sec3_allelements_in_l3_RI");
							driver.quit();break;
						
							
						case "Validate_alert_nomorethan3_Emprs_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_alert_nomorethan3_Emprs_in_l3_RI");
							ClubStudio.Validate_alert_nomorethan3_Emprs_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,input_data,Checkbox_class_formats);
							context.setAttribute("fileName", "Validate_alert_nomorethan3_Emprs_in_l3_RI");
							driver.quit();break;
			

						case "Validate_class_formats_chkbxs_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_class_formats_chkbxs_in_l3_RI");
							ClubStudio.Validate_class_formats_chkbxs_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,input_data,Checkbox_class_formats);
							context.setAttribute("fileName", "Validate_class_formats_chkbxs_in_l3_RI");
							driver.quit();break;
							
						
						case "Validate_Timeperiod_dd_all_options_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_Timeperiod_dd_all_options_in_l3_RI");
							ClubStudio.Validate_Timeperiod_dd_all_options_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,Time_period_DD);
							context.setAttribute("fileName", "Validate_Timeperiod_dd_all_options_in_l3_RI");
							driver.quit();break;
							
						
						case "Validate_Club_emplr_dd_all_options_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_Club_emplr_dd_all_options_in_l3_RI");
							ClubStudio.Validate_Club_emplr_dd_all_options_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,Club_Employer_DD);
							context.setAttribute("fileName", "Validate_Club_emplr_dd_all_options_in_l3_RI");
							driver.quit();break;	
							
							
						case "Validate_cpw_ip_value_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_cpw_ip_value_in_l3_RI");
							ClubStudio.Validate_cpw_ip_value_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,Class_per_week);
							context.setAttribute("fileName", "Validate_cpw_ip_value_in_l3_RI");
							driver.quit();break;
							
						
							
						case "Validate_slt_classformats_chkbxs_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_slt_classformats_chkbxs_in_l3_RI");
							ClubStudio.Validate_slt_classformats_chkbxs_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,Checkbox_class_formats);
							context.setAttribute("fileName", "Validate_slt_classformats_chkbxs_in_l3_RI");
							driver.quit();break;
							
							
						case "Validate_Aerobic_cert_texts_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_Aerobic_cert_texts_in_l3_RI");
							ClubStudio.Validate_Aerobic_cert_texts_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, input_data );
							context.setAttribute("fileName", "Validate_Aerobic_cert_texts_in_l3_RI");
							driver.quit();break;
					
							
						case "Validate_Add_cert_btn_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_Add_cert_btn_in_l3_RI");
							ClubStudio.Validate_Add_cert_btn_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
							context.setAttribute("fileName", "Validate_Add_cert_btn_in_l3_RI");
							driver.quit();break;
							
						case "Validate_Aerobic_cert_all_fields_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_Aerobic_cert_all_fields_in_l3_RI");
							ClubStudio.Validate_Aerobic_cert_all_fields_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
							context.setAttribute("fileName", "Validate_Aerobic_cert_all_fields_in_l3_RI");
							driver.quit();break;
					
							
						case "Validate_Choosefile_and_cert_format_txt_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_Choosefile_and_cert_format_txt_in_l3_RI");
							ClubStudio.Validate_Choosefile_and_cert_format_txt_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, input_data );
							context.setAttribute("fileName", "Validate_Choosefile_and_cert_format_txt_in_l3_RI");
							driver.quit();break;
							
							
						case "Validate_add_emplr_remove_img_btn_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_add_emplr_remove_img_btn_in_l3_RI");
							ClubStudio.Validate_add_emplr_remove_img_btn_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,input_data );
							context.setAttribute("fileName", "Validate_add_emplr_remove_img_btn_in_l3_RI");
							driver.quit();break;
							
							
						case "Validate_Aero_cert_remove_img_btn_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_Aero_cert_remove_img_btn_in_l3_RI");
							ClubStudio.Validate_Aero_cert_remove_img_btn_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, input_data );
							context.setAttribute("fileName", "Validate_Aero_cert_remove_img_btn_in_l3_RI");
							driver.quit();break;
							
							
						case "Validate_upload_cert_file_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_upload_cert_file_in_l3_RI");
							ClubStudio.Validate_upload_cert_file_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, input_data, File_name );
							context.setAttribute("fileName", "Validate_upload_cert_file_in_l3_RI");
							driver.quit();break;
							
						case "Validate_CertifiedIn_dd_all_values_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_CertifiedIn_dd_all_values_in_l3_RI");
							ClubStudio.Validate_CertifiedIn_dd_all_values_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, Certified_In_DD );
							context.setAttribute("fileName", "Validate_CertifiedIn_dd_all_values_in_l3_RI");
							driver.quit();break;
							
							
						case "Validate_CertifiedIn_select_desiredvalue_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_CertifiedIn_select_desiredvalue_in_l3_RI");
							ClubStudio.Validate_CertifiedIn_select_desiredvalue_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, Certified_In_DD );
							context.setAttribute("fileName", "Validate_CertifiedIn_select_desiredvalue_in_l3_RI");
							driver.quit();break;
							
						case "Validate_IssuedBy_DD_enabled_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_IssuedBy_DD_enabled_in_l3_RI");
							ClubStudio.Validate_IssuedBy_DD_enabled_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, Certified_In_DD );
							context.setAttribute("fileName", "Validate_IssuedBy_DD_enabled_in_l3_RI");
							driver.quit();break;
							
						case "Validate_IssuedBy_DD_disabled_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_IssuedBy_DD_disabled_in_l3_RI");
							ClubStudio.Validate_IssuedBy_DD_disabled_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, Certified_In_DD );
							context.setAttribute("fileName", "Validate_IssuedBy_DD_disabled_in_l3_RI");
							driver.quit();break;
							
							
						case "Validate_IssuedBy_dd_all_values_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_IssuedBy_dd_all_values_in_l3_RI");
							ClubStudio.Validate_IssuedBy_dd_all_values_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, Certified_In_DD,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "Validate_IssuedBy_dd_all_values_in_l3_RI");
							driver.quit();break;
							
							
						case "Validate_Input_in_Cert_no_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_Input_in_Cert_no_in_l3_RI");
							ClubStudio.Validate_Input_in_Cert_no_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button,  Certificate_No);
							context.setAttribute("fileName", "Validate_Input_in_Cert_no_in_l3_RI");
							driver.quit();break;
							
						case "Validate_filling_all_fields_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_filling_all_fields_in_l3_RI");
							ClubStudio.Validate_filling_all_fields_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
							context.setAttribute("fileName", "Validate_filling_all_fields_in_l3_RI");
							driver.quit();break;
							
							
						case "Validate_Aero_cert2_all_fields_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_Aero_cert2_all_fields_in_l3_RI");
							ClubStudio.Validate_Aero_cert2_all_fields_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
							context.setAttribute("fileName", "Validate_Aero_cert2_all_fields_in_l3_RI");
							driver.quit();break;
							
						case "Validate_Aero_cert3_all_fields_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_Aero_cert3_all_fields_in_l3_RI");
							ClubStudio.Validate_Aero_cert3_all_fields_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
							context.setAttribute("fileName", "Validate_Aero_cert3_all_fields_in_l3_RI");
							driver.quit();break;
							
						case "Validate_Aero_cert4_all_fields_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_Aero_cert4_all_fields_in_l3_RI");
							ClubStudio.Validate_Aero_cert4_all_fields_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
							context.setAttribute("fileName", "Validate_Aero_cert4_all_fields_in_l3_RI");
							driver.quit();break;
							
						case "Validate_alert_nomorethan_4_cert_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_alert_nomorethan_4_cert_in_l3_RI");
							ClubStudio.Validate_alert_nomorethan_4_cert_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
							context.setAttribute("fileName", "Validate_alert_nomorethan_4_cert_in_l3_RI");
							driver.quit();break;
							
							
						case "Validate_removebtn_by_ip_in_cert_sec_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_removebtn_by_ip_in_cert_sec_in_l3_RI");
							ClubStudio.Validate_removebtn_by_ip_in_cert_sec_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name, input_data  );
							context.setAttribute("fileName", "Validate_removebtn_by_ip_in_cert_sec_in_l3_RI");
							driver.quit();break;
							
							
							
							
						case "Validate_removebtn_by_ip_addemployer_in_l3_RI":
							
							context.setAttribute("fileName", "Validate_removebtn_by_ip_addemployer_in_l3_RI");
							ClubStudio.Validate_removebtn_by_ip_addemployer_in_l3_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats  );
							context.setAttribute("fileName", "Validate_removebtn_by_ip_addemployer_in_l3_RI");
							driver.quit();break;
							
							
						case "Validate_emp_his_pre_emp_texts_in_l4_RI":
							
							context.setAttribute("fileName", "Validate_emp_his_pre_emp_texts_in_l4_RI");
							ClubStudio.Validate_emp_his_pre_emp_texts_in_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
							context.setAttribute("fileName", "Validate_emp_his_pre_emp_texts_in_l4_RI");
							driver.quit();break;
							
						case "Validate_radio_btns_of_emp_his_in_l4_RI":
							
							context.setAttribute("fileName", "Validate_radio_btns_of_emp_his_in_l4_RI");
							ClubStudio.Validate_radio_btns_of_emp_his_in_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
							context.setAttribute("fileName", "Validate_radio_btns_of_emp_his_in_l4_RI");
							driver.quit();break;
							
							
						case "Validate_upload_resume_chkbx_in_l4_RI":
							
							context.setAttribute("fileName", "Validate_upload_resume_chkbx_in_l4_RI");
							ClubStudio.Validate_upload_resume_chkbx_in_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
							context.setAttribute("fileName", "Validate_upload_resume_chkbx_in_l4_RI");
							driver.quit();break;
							
							
							
						case "Validate_upload_resume_sec_in_l4_RI":
							
							context.setAttribute("fileName", "Validate_upload_resume_sec_in_l4_RI");
							ClubStudio.Validate_upload_resume_sec_in_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name, input_data );
							context.setAttribute("fileName", "Validate_upload_resume_sec_in_l4_RI");
							driver.quit();break;
							
							
							
						case "Validate_upload_resumefile_l4_RI":
							
							context.setAttribute("fileName", "Validate_upload_resumefile_l4_RI");
							ClubStudio.Validate_upload_resumefile_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name, input_data );
							context.setAttribute("fileName", "Validate_upload_resumefile_l4_RI");
							driver.quit();break;
							
							
							
						case "Validate_current_previous_emp_texts_in_l4_RI":
							
							context.setAttribute("fileName", "Validate_current_previous_emp_texts_in_l4_RI");
							ClubStudio.Validate_current_previous_emp_texts_in_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name, input_data );
							context.setAttribute("fileName", "Validate_current_previous_emp_texts_in_l4_RI");
							driver.quit();break;
							
							
						case "Validate_all_input_fields_in_l4_RI":
							
							context.setAttribute("fileName", "Validate_all_input_fields_in_l4_RI");
							ClubStudio.Validate_all_input_fields_in_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
							context.setAttribute("fileName", "Validate_all_input_fields_in_l4_RI");
							driver.quit();break;
							
							
							
						case "Validate_ip_inallfields_in_l4_RI":
							
							context.setAttribute("fileName", "Validate_ip_inallfields_in_l4_RI");
							ClubStudio.Validate_ip_inallfields_in_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button);
							context.setAttribute("fileName", "Validate_ip_inallfields_in_l4_RI");
							driver.quit();break;
							
							
							
						case "Validate_prev_next_step_btns_in_l4_RI":
							
							context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4_RI");
							ClubStudio.Validate_prev_next_step_btns_in_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
							context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4_RI");
							driver.quit();break;
							
							
							
						case "Validate_add_emply_2_btn_in_l4_RI":
							
							context.setAttribute("fileName", "Validate_add_emply_2_btn_in_l4_RI");
							ClubStudio.Validate_add_emply_2_btn_in_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
							context.setAttribute("fileName", "Validate_add_emply_2_btn_in_l4_RI");
							driver.quit();break;
							
							
						case "Validate_Next_btn_in_l4_RI":
							
							context.setAttribute("fileName", "Validate_Next_btn_in_l4_RI");
							ClubStudio.Validate_Next_btn_in_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
							context.setAttribute("fileName", "Validate_Next_btn_in_l4_RI");
							driver.quit();break;
						
							
						case "Validate_No_Previous_Emp_RdoBtn_in_l4_RI":
							
							context.setAttribute("fileName", "Validate_No_Previous_Emp_RdoBtn_in_l4_RI");
							ClubStudio.Validate_No_Previous_Emp_RdoBtn_in_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
							context.setAttribute("fileName", "Validate_No_Previous_Emp_RdoBtn_in_l4_RI");
							driver.quit();break;
							
							
						case "Validate_prev_step_btn_in_l4_RI":
							
							context.setAttribute("fileName", "Validate_prev_step_btn_in_l4_RI");
							ClubStudio.Validate_prev_step_btn_in_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
							context.setAttribute("fileName", "Validate_prev_step_btn_in_l4_RI");
							driver.quit();break;
							
							
						case "Validate_all_ip_fieldsof_Addemplr2_in_l4_RI":
							
							context.setAttribute("fileName", "Validate_all_ip_fieldsof_Addemplr2_in_l4_RI");
							ClubStudio.Validate_all_ip_fieldsof_Addemplr2_in_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
							context.setAttribute("fileName", "Validate_all_ip_fieldsof_Addemplr2_in_l4_RI");
							driver.quit();break;
							
							
						case "Validate_all_ip_fieldsof_Addemplr3_in_l4_RI":
							
							context.setAttribute("fileName", "Validate_all_ip_fieldsof_Addemplr3_in_l4_RI");
							ClubStudio.Validate_all_ip_fieldsof_Addemplr3_in_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
							context.setAttribute("fileName", "Validate_all_ip_fieldsof_Addemplr3_in_l4_RI");
							driver.quit();break;
							
							
						case "Validate_removebtn2_by_ip_in_empr2_in_l4_RI":
							
							context.setAttribute("fileName", "Validate_removebtn2_by_ip_in_empr2_in_l4_RI");
							ClubStudio.Validate_removebtn2_by_ip_in_empr2_in_l4_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button);
							context.setAttribute("fileName", "Validate_removebtn2_by_ip_in_empr2_in_l4_RI");
							driver.quit();break;
							
							
							
						case "Validate_Indicate_languages_text_l5_RI":
							
							context.setAttribute("fileName", "Validate_Indicate_languages_text_l5_RI");
							ClubStudio.Validate_Indicate_languages_text_l5_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, input_data);
							context.setAttribute("fileName", "Validate_Indicate_languages_text_l5_RI");
							driver.quit();break;
							
						case "Validate_all_languages_in_l5_RI":
							
							context.setAttribute("fileName", "Validate_all_languages_in_l5_RI");
							ClubStudio.Validate_all_languages_in_l5_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
							context.setAttribute("fileName", "Validate_all_languages_in_l5_RI");
							driver.quit();break;
							
							
						case "Validate_bydefault_Eng_lang_isselected_in_l5_RI":
							
							context.setAttribute("fileName", "Validate_bydefault_Eng_lang_isselected_in_l5_RI");
							ClubStudio.Validate_bydefault_Eng_lang_isselected_in_l5_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
							context.setAttribute("fileName", "Validate_bydefault_Eng_lang_isselected_in_l5_RI");
							driver.quit();break;
							
						case "Validate_select_desired_langs_in_l5_RI":
							
							context.setAttribute("fileName", "Validate_select_desired_langs_in_l5_RI");
							ClubStudio.Validate_select_desired_langs_in_l5_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
							context.setAttribute("fileName", "Validate_select_desired_langs_in_l5_RI");
							driver.quit();break;
							
						case "Validate_prev_next_step_btns_in_l5_RI":
							
							context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5_RI");
							ClubStudio.Validate_prev_next_step_btns_in_l5_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
							context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5_RI");
							driver.quit();break;
							
						case "Validate_prev_step_btn_in_l5_RI":
							
							context.setAttribute("fileName", "Validate_prev_step_btn_in_l5_RI");
							ClubStudio.Validate_prev_step_btn_in_l5_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
							context.setAttribute("fileName", "Validate_prev_step_btn_in_l5_RI");
							driver.quit();break;
							
						case "Validate_Next_step_btn_in_l5_RI":
							
							context.setAttribute("fileName", "Validate_Next_step_btn_in_l5_RI");
							ClubStudio.Validate_Next_step_btn_in_l5_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
							context.setAttribute("fileName", "Validate_Next_step_btn_in_l5_RI");
							driver.quit();break;
							
					
						
						case "Validate_text_COqualify_in_l6_RI":
							
							context.setAttribute("fileName", "Validate_text_COqualify_in_l6_RI");
							ClubStudio.Validate_text_COqualify_in_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, input_data);
							context.setAttribute("fileName", "Validate_text_COqualify_in_l6_RI");
							driver.quit();break;
							
							
						case "Validate_all_fields_in_l6_RI":
							
							context.setAttribute("fileName", "Validate_all_fields_in_l6_RI");
							ClubStudio.Validate_all_fields_in_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Considered_for_chkbx);
							context.setAttribute("fileName", "Validate_all_fields_in_l6_RI");
							driver.quit();break;
							
							
							
						case "Validate_slt_Worktime_l6_RI":
							
							context.setAttribute("fileName", "Validate_slt_Worktime_l6_RI");
							ClubStudio.Validate_slt_Worktime_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Work_time);
							context.setAttribute("fileName", "Validate_slt_Worktime_l6_RI");
							driver.quit();break;
							
							
							
						case "Validate_slt_considerfor_chkbxs_l6_RI":
							
							context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6_RI");
							ClubStudio.Validate_slt_considerfor_chkbxs_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx);
							context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6_RI");
							driver.quit();break;
						
							
						case "Validate_deslt_considerfor_chkbxs_l6_RI":
							
							context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6_RI");
							ClubStudio.Validate_deslt_considerfor_chkbxs_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx);
							context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6_RI");
							driver.quit();break;
							
							
						case "Validate_COs_asperCFchkbxsltn_l6_RI":
							
							context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6_RI");
							ClubStudio.Validate_COs_asperCFchkbxsltn_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx);
							context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6_RI");
							driver.quit();break;
							
							
						case "Validate_COs_asperCFchkbxdesltn_l6_RI":
							
							context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6_RI");
							ClubStudio.Validate_COs_asperCFchkbxdesltn_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx, input_data);
							context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6_RI");
							driver.quit();break;
							
							
						case "Validate_defaultvalueofCO_l6_RI":
							
							context.setAttribute("fileName", "Validate_defaultvalueofCO_l6_RI");
							ClubStudio.Validate_defaultvalueofCO_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Considered_for_chkbx);
							context.setAttribute("fileName", "Validate_defaultvalueofCO_l6_RI");
							driver.quit();break;
							
							
						case "Validate_ip_date_to_begin_l6_RI":
							
							context.setAttribute("fileName", "Validate_ip_date_to_begin_l6_RI");
							ClubStudio.Validate_ip_date_to_begin_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Date_to_begin);
							context.setAttribute("fileName", "Validate_ip_date_to_begin_l6_RI");
							driver.quit();break;
							
							
						case "Validate_empdwithus_no_rdobtn_l6_RI":
							
							context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6_RI");
							ClubStudio.Validate_empdwithus_no_rdobtn_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, input_data);
							context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6_RI");
							driver.quit();break;
							
							
						case "Validate_basedonsltns_text_l6_RI":
							
							context.setAttribute("fileName", "Validate_basedonsltns_text_l6_RI");
							ClubStudio.Validate_basedonsltns_text_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, input_data);
							context.setAttribute("fileName", "Validate_basedonsltns_text_l6_RI");
							driver.quit();break;
							
							
						case "Validate_Club_locations_l6_RI":
							
							context.setAttribute("fileName", "Validate_Club_locations_l6_RI");
							ClubStudio.Validate_Club_locations_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, input_data);
							context.setAttribute("fileName", "Validate_Club_locations_l6_RI");
							driver.quit();break;
							
						case "Validate_Rehire_Questionnaire_sec_l6_RI":
							
							context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l6_RI");
							ClubStudio.Validate_Rehire_Questionnaire_sec_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, input_data);
							context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l6_RI");
							driver.quit();break;
							
							
						case "Validate_Resigned_dd_allvalues_l6_RI":
							
							context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6_RI");
							ClubStudio.Validate_Resigned_dd_allvalues_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, EmploymentHowResigned_dd);
							context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6_RI");
							driver.quit();break;
							
							
							
						case "Validate_ip_in_RQ_sec_l6_RI":
							
							context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6_RI");
							ClubStudio.Validate_ip_in_RQ_sec_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages , EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
							context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6_RI");
							driver.quit();break;
						
							
							
						case "Validate_prev_next_step_btns_l6_RI":
							
							context.setAttribute("fileName", "Validate_prev_next_step_btns_l6_RI");
							ClubStudio.Validate_prev_next_step_btns_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
							context.setAttribute("fileName", "Validate_prev_next_step_btns_l6_RI");
							driver.quit();break;
							
							
						case "Validate_prev_step_btn_in_l6_RI":
							
							context.setAttribute("fileName", "Validate_prev_step_btn_in_l6_RI");
							ClubStudio.Validate_prev_step_btn_in_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
							context.setAttribute("fileName", "Validate_prev_step_btn_in_l6_RI");
							driver.quit();break;
							
						case "Validate_next_btn_byipallfields_l6_RI":
							
							context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6_RI");
							ClubStudio.Validate_next_btn_byipallfields_l6_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
							context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6_RI");
							driver.quit();break;
							
							
							
						case "Validate_paras_in_l7_RI":
							
							context.setAttribute("fileName", "Validate_paras_in_l7_RI");
							ClubStudio.Validate_paras_in_l7_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, input_data);
							context.setAttribute("fileName", "Validate_paras_in_l7_RI");
							driver.quit();break;
							
							
							
						case "Validate_rdobtns_in_l7_RI":
							
							context.setAttribute("fileName", "Validate_rdobtns_in_l7_RI");
							ClubStudio.Validate_rdobtns_in_l7_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
							context.setAttribute("fileName", "Validate_rdobtns_in_l7_RI");
							driver.quit();break;
							
							
							
						case "Validate_all_form_sec_in_l7_RI":
							
							context.setAttribute("fileName", "Validate_all_form_sec_in_l7_RI");
							ClubStudio.Validate_all_form_sec_in_l7_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
							context.setAttribute("fileName", "Validate_all_form_sec_in_l7_RI");
							driver.quit();break;
							
							
							
						case "Validate_all_options_of_Gender_dd_in_l7_RI":
							
							context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_RI");
							ClubStudio.Validate_all_options_of_Gender_dd_in_l7_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,Gender_dd);
							context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_RI");
							driver.quit();break;
							
							
							
						case "Validate_all_options_of_RE_dd_in_l7_RI":
							
							context.setAttribute("fileName", "Validate_all_options_of_RE_dd_in_l7_RI");
							ClubStudio.Validate_all_options_of_RE_dd_in_l7_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,RaceEthnicity_dd);
							context.setAttribute("fileName", "Validate_all_options_of_RE_dd_in_l7_RI");
							driver.quit();break;
							
							
						case "Validate_EOE_details_paras_in_l7_RI":
							
							context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7_RI");
							ClubStudio.Validate_EOE_details_paras_in_l7_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,input_data);
							context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7_RI");
							driver.quit();break;
							
							
							
						case "Validate_No_rdobtnof_form_sec_in_l7_RI":
							
							context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7_RI");
							ClubStudio.Validate_No_rdobtnof_form_sec_in_l7_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
							context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7_RI");
							driver.quit();break;
							
							
						case "Validate_prev_next_step_btns_in_l7_RI":
							
							context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7_RI");
							ClubStudio.Validate_prev_next_step_btns_in_l7_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
							context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7_RI");
							driver.quit();break;
							
							
						case "Validate_prev_step_btn_in_l7_RI":
							
							context.setAttribute("fileName", "Validate_prev_step_btn_in_l7_RI");
							ClubStudio.Validate_prev_step_btn_in_l7_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
							context.setAttribute("fileName", "Validate_prev_step_btn_in_l7_RI");
							driver.quit();break;
							
							
						case "Validate_Next_step_btn_in_l7_RI":
							
							context.setAttribute("fileName", "Validate_Next_step_btn_in_l7_RI");
							ClubStudio.Validate_Next_step_btn_in_l7_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
							context.setAttribute("fileName", "Validate_Next_step_btn_in_l7_RI");
							driver.quit();break;
							
							
						case "Validate_Nav_to_l8_RI":
							
							context.setAttribute("fileName", "Validate_Nav_to_l8_RI");
							ClubStudio.Validate_Nav_to_l8_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
							context.setAttribute("fileName", "Validate_Nav_to_l8_RI");
							driver.quit();break;
						
							
							
						case "Validate_AS_paras_in_l8_RI":
							
							context.setAttribute("fileName", "Validate_AS_paras_in_l8_RI");
							ClubStudio.Validate_AS_paras_in_l8_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
							context.setAttribute("fileName", "Validate_AS_paras_in_l8_RI");
							driver.quit();break;
							
							
						case "Validate_ackmnt_in_l8_RI":
							
							context.setAttribute("fileName", "Validate_ackmnt_in_l8_RI");
							ClubStudio.Validate_ackmnt_in_l8_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
							context.setAttribute("fileName", "Validate_ackmnt_in_l8_RI");
							driver.quit();break;
							
							
						case "Validate_ip_in_Signedbyname_in_l8_RI":
							
							context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_RI");
							ClubStudio.Validate_ip_in_Signedbyname_in_l8_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
							context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_RI");
							driver.quit();break;
							
							
						case "Validate_prev_next_step_btns_in_l8_RI":
							
							context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8_RI");
							ClubStudio.Validate_prev_next_step_btns_in_l8_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
							context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8_RI");
							driver.quit();break;
							
							
						case "Validate_prev_step_btn_in_l8_RI":
							
							context.setAttribute("fileName", "Validate_prev_step_btn_in_l8_RI");
							ClubStudio.Validate_prev_step_btn_in_l8_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
							context.setAttribute("fileName", "Validate_prev_step_btn_in_l8_RI");
							driver.quit();break;
							
							
						case "Validate_Next_btn_in_l8_RI":
							
							context.setAttribute("fileName", "Validate_Next_btn_in_l8_RI");
							ClubStudio.Validate_Next_btn_in_l8_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
							context.setAttribute("fileName", "Validate_Next_btn_in_l8_RI");
							driver.quit();break;
							
							
						case "Validate_heading_in_l9_RI":
							
							context.setAttribute("fileName", "Validate_heading_in_l9_RI");
							ClubStudio.Validate_heading_in_l9_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
							context.setAttribute("fileName", "Validate_heading_in_l9_RI");
							driver.quit();break;
							
							
						case "Validate_Rules_procedures_in_l9_RI":
							
							context.setAttribute("fileName", "Validate_Rules_procedures_in_l9_RI");
							ClubStudio.Validate_Rules_procedures_in_l9_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
							context.setAttribute("fileName", "Validate_Rules_procedures_in_l9_RI");
							driver.quit();break;
							
							
						case "Validate_ip_in_prtname_dateandipadd_in_l9_RI":
							
							context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9_RI");
							ClubStudio.Validate_ip_in_prtname_dateandipadd_in_l9_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, IP_Address);
							context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9_RI");
							driver.quit();break;
							
							
							
							
						case "Validate_Robert_Bryant_Sign_in_l9_RI":
							
							context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_RI");
							ClubStudio.Validate_Robert_Bryant_Sign_in_l9_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
							context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_RI");
							driver.quit();break;
							
							
						case "Validate_Iagree_textandbtn_in_l9_RI":
							
							context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_RI");
							ClubStudio.Validate_Iagree_textandbtn_in_l9_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
							context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_RI");
							driver.quit();break;
							
							
						case "Validate_Prev_step_btn_in_l9_RI":
							
							context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9_RI");
							ClubStudio.Validate_Prev_step_btn_in_l9_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
							context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9_RI");
							driver.quit();break;
							
							
						case "Validate_Iagreebtn_and_succ_submsn_in_l9_RI":
							
							context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_RI");
							ClubStudio.Validate_Iagreebtn_and_succ_submsn_in_l9_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
							context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_RI");
							driver.quit();break;
							
							
							
						case "Validate_Success_msg_in_final_page_RI":
							
							context.setAttribute("fileName", "Validate_Success_msg_in_final_page_RI");
							ClubStudio.Validate_Success_msg_in_final_page_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
							context.setAttribute("fileName", "Validate_Success_msg_in_final_page_RI");
							driver.quit();break;
							
							
						case "Validate_prtbtn_in_print_emp_app_page_RI":
							
							context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page_RI");
							ClubStudio.Validate_prtbtn_in_print_emp_app_page_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
							context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page_RI");
							driver.quit();break;
							
							
							
						case "Validate_Rules_link_in_l9_RI":
							
							context.setAttribute("fileName", "Validate_Rules_link_in_l9_RI");
							ClubStudio.Validate_Rules_link_in_l9_RI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
							context.setAttribute("fileName", "Validate_Rules_link_in_l9_RI");
							driver.quit();break;
							
							
							
						case "Validate_emp_para_RFI":
							
							context.setAttribute("fileName", "Validate_emp_para_RFI");
							ClubStudio.Validate_emp_para_RFI(testdata.get("TextMessage").toString(), Text_input, additional_input);
							context.setAttribute("fileName", "Validate_emp_para_RFI");
							driver.quit();
							break;
						
							

						case "Validate_App_info_text_RFI":
							
							context.setAttribute("fileName", "Validate_App_info_text_RFI");
							ClubStudio.Validate_App_info_text_RFI(testdata.get("TextMessage").toString(), Text_input, additional_input);
							context.setAttribute("fileName", "Validate_App_info_text_RFI");
							driver.quit();
							break;
							
							
						case "Validate_all_ip_fields_in_emp_page_RFI":
							
							context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page_RFI");
							ClubStudio.Validate_all_ip_fields_in_emp_page_RFI(testdata.get("TextMessage").toString(), Text_input);
							context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page_RFI");
							driver.quit();
							break;
							
							
						case "Validate_Howdidyouhearaboutus_dd_RFI":
							
							context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd_RFI");
							ClubStudio.Validate_Howdidyouhearaboutus_dd_RFI(testdata.get("TextMessage").toString(), Text_input, Dropdown_values);
							context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd_RFI");
							driver.quit();
							break;
							
						case "Validate_Radiobtn18YearsOld_options_RFI":
							
							context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_RFI");
							ClubStudio.Validate_Radiobtn18YearsOld_options_RFI(testdata.get("TextMessage").toString(), Text_input);
							context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_RFI");
							driver.quit();
							break;
							
							
						case "Validate_US_format_text_RFI":
							
							context.setAttribute("fileName", "Validate_US_format_text_RFI");
							ClubStudio.Validate_US_format_text_RFI(testdata.get("TextMessage").toString(), Text_input, additional_input);
							context.setAttribute("fileName", "Validate_US_format_text_RFI");
							driver.quit();
							break;
							
							
						case "Validate_Miles_text_RFI":
							
							context.setAttribute("fileName", "Validate_Miles_text_RFI");
							ClubStudio.Validate_Miles_text_RFI(testdata.get("TextMessage").toString(), Text_input, additional_input);
							context.setAttribute("fileName", "Validate_Miles_text_RFI");
							driver.quit();
							break;
							
						case "Validate_phone_errorlabel_RFI":
							
							context.setAttribute("fileName", "Validate_phone_errorlabel_RFI");
							ClubStudio.Validate_phone_errorlabel_RFI(testdata.get("TextMessage").toString(), Text_input, additional_input);
							context.setAttribute("fileName", "Validate_phone_errorlabel_RFI");
							driver.quit();
							break;
							
							
						case "Validate_Next_step_button_in_l1_RFI":
							
							context.setAttribute("fileName", "Validate_Next_step_button_in_l1_RFI");
							ClubStudio.Validate_Next_step_button_in_l1_RFI(testdata.get("TextMessage").toString(), Text_input);
							context.setAttribute("fileName", "Validate_Next_step_button_in_l1_RFI");
							driver.quit();
							break;
							
							
							
						case "Validate_input_in_all_fields_RFI":
							
						context.setAttribute("fileName", "Validate_input_in_all_fields_RFI");
						ClubStudio.Validate_input_in_all_fields_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode  );
						context.setAttribute("fileName", "Validate_input_in_all_fields_RFI");
						driver.quit();break;
							
						
						
						case "Validate_List18YrsOld_No_popupalrt_RFI":
							
							context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt_RFI");
							ClubStudio.Validate_List18YrsOld_No_popupalrt_RFI(testdata.get("TextMessage").toString(), Text_input, Radiobtn18YearsOld);
							context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt_RFI");
							driver.quit();
							break;
							
							
							
						case "Validate_Next_step_l1_RFI":
							
						context.setAttribute("fileName", "Validate_Next_step_l1_RFI");
						ClubStudio.Validate_Next_step_l1_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
						context.setAttribute("fileName", "Validate_Next_step_l1_RFI");
						driver.quit();break;
							
						
						case "Validate_education_level_dd_RFI":
							
						context.setAttribute("fileName", "Validate_education_level_dd_RFFI");
						ClubStudio.Validate_education_level_dd_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
						context.setAttribute("fileName", "Validate_education_level_dd_RI");
						driver.quit();break;
						
							
						
						case "Validate_edu_level_dd_allvalues_RFI":
							
						context.setAttribute("fileName", "Validate_edu_level_dd_allvalues_RFI");
						ClubStudio.Validate_edu_level_dd_allvalues_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input , E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_edu_level_dd_allvalues_RFI");
						driver.quit();break;
						
						
						
						case "Validate_previous_next_step_buttons_l2_RFI":
							
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2_RFI");
						ClubStudio.Validate_previous_next_step_buttons_l2_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2_RFI");
						driver.quit();break;
						
						
						case "Validate_previous_step_button_l2_RFI":
							
						context.setAttribute("fileName", "Validate_previous_step_button_l2_RFI");
						ClubStudio.Validate_previous_step_button_l2_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
						context.setAttribute("fileName", "Validate_previous_step_button_l2_RFI");
						driver.quit();break;
						
						
						case "Validate_Next_step_button_l2_RFI":
							
						context.setAttribute("fileName", "Validate_Next_step_button_l2_RFI");
						ClubStudio.Validate_Next_step_button_l2_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown  );
						context.setAttribute("fileName", "Validate_Next_step_button_l2_RFI");
						driver.quit();break;
						
						case "Validate_Exp_info_text_in_l3_RFI":
							
						context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_RFI");
						ClubStudio.Validate_Exp_info_text_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
						context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_RFI");
						driver.quit();break;
						
						case "Validate_GP_AI_text_in_l3_RFI":
							
						context.setAttribute("fileName", "Validate_GP_AI_text_in_l3_RFI");
						ClubStudio.Validate_GP_AI_text_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
						context.setAttribute("fileName", "Validate_GP_AI_text_in_l3_RFI");
						driver.quit();break;
						
						
						case "Validate_GP_AI_exp_dd_in_l3_RFI":
							
						context.setAttribute("fileName", "Validate_GP_AI_exp_dd_in_l3_RFI");
						ClubStudio.Validate_GP_AI_exp_dd_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown  );
						context.setAttribute("fileName", "Validate_GP_AI_exp_dd_in_l3_RFI");
						driver.quit();break;
						
						
						case "Validate_GP_AI_exp_dd_all_values_in_l3_RFI":
							
						context.setAttribute("fileName", "Validate_GP_AI_exp_dd_all_values_in_l3_RFI");
						ClubStudio.Validate_GP_AI_exp_dd_all_values_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
						context.setAttribute("fileName", "Validate_GP_AI_exp_dd_all_values_in_l3_RFI");
						driver.quit();break;
						
						
						case "Validate_Hold_a_Cert_rdo_btns_in_l3_RFI":
							
						context.setAttribute("fileName", "Validate_Hold_a_Cert_rdo_btns_in_l3_RFI");
						ClubStudio.Validate_Hold_a_Cert_rdo_btns_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_Hold_a_Cert_rdo_btns_in_l3_RFI");
						driver.quit();break;
						
						case "Validate_GF_A_CertfnInfo_link_RFI":
							
						context.setAttribute("fileName", "Validate_GF_A_CertfnInfo_link_RFI");
						ClubStudio.Validate_GF_A_CertfnInfo_link_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_GF_A_CertfnInfo_link_RFI");
						driver.quit();break;
						
						
						case "Validate_prev_next_step_btns_in_l3_RFI":
							
						context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l3_RFI");
						ClubStudio.Validate_prev_next_step_btns_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l3_RFI");
						driver.quit();break;
						
						
						case "Validate_previous_step_btn_in_l3_RFI":
							
						context.setAttribute("fileName", "Validate_previous_step_btn_in_l3_RFI");
						ClubStudio.Validate_previous_step_btn_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_previous_step_btn_in_l3_RFI");
						driver.quit();break;
						
						
						case "Validate_next_step_btn_in_l3_RFI":
							
							context.setAttribute("fileName", "Validate_next_step_btn_in_l3_RFI");
							ClubStudio.Validate_next_step_btn_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
							context.setAttribute("fileName", "Validate_next_step_btn_in_l3_RFI");
							driver.quit();break;

							
						case "Validate_exp_details_texts_in_l3_RFI":
							
						context.setAttribute("fileName", "Validate_exp_details_texts_in_l3_RFI");
						ClubStudio.Validate_exp_details_texts_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD, input_data);
						context.setAttribute("fileName", "Validate_exp_details_texts_in_l3_RFI");
						driver.quit();break;
								
							
						case "Validate_add_employer_btn_in_l3_RFI":
							
							context.setAttribute("fileName", "Validate_add_employer_btn_in_l3_RFI");
							ClubStudio.Validate_add_employer_btn_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD);
							context.setAttribute("fileName", "Validate_add_employer_btn_in_l3_RFI");
							driver.quit();break;
						
						
						case "Validate_TP_CE_CW_elements_in_l3_RFI":
							
							context.setAttribute("fileName", "Validate_TP_CE_CW_elements_in_l3_RFI");
							ClubStudio.Validate_TP_CE_CW_elements_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD);
							context.setAttribute("fileName", "Validate_TP_CE_CW_elements_in_l3_RFI");
							driver.quit();break;
							


						case "Validate_class_formats_chkbxs_in_l3_RFI":
							
							context.setAttribute("fileName", "Validate_class_formats_chkbxs_in_l3_RFI");
							ClubStudio.Validate_class_formats_chkbxs_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,input_data,Checkbox_class_formats);
							context.setAttribute("fileName", "Validate_class_formats_chkbxs_in_l3_RFI");
							driver.quit();break;
							
						
						case "Validate_Timeperiod_dd_all_options_in_l3_RFI":
							
							context.setAttribute("fileName", "Validate_Timeperiod_dd_all_options_in_l3_RFI");
							ClubStudio.Validate_Timeperiod_dd_all_options_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,Time_period_DD);
							context.setAttribute("fileName", "Validate_Timeperiod_dd_all_options_in_l3_RFI");
							driver.quit();break;
							
						
						case "Validate_Club_emplr_dd_all_options_in_l3_RFI":
							
							context.setAttribute("fileName", "Validate_Club_emplr_dd_all_options_in_l3_RFI");
							ClubStudio.Validate_Club_emplr_dd_all_options_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,Club_Employer_DD);
							context.setAttribute("fileName", "Validate_Club_emplr_dd_all_options_in_l3_RFI");
							driver.quit();break;	
							
							
						case "Validate_cpw_ip_value_in_l3_RFI":
							
							context.setAttribute("fileName", "Validate_cpw_ip_value_in_l3_RFI");
							ClubStudio.Validate_cpw_ip_value_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,Class_per_week);
							context.setAttribute("fileName", "Validate_cpw_ip_value_in_l3_RFI");
							driver.quit();break;
							
						
							
						case "Validate_slt_classformats_chkbxs_in_l3_RFI":
							
							context.setAttribute("fileName", "Validate_slt_classformats_chkbxs_in_l3_RFI");
							ClubStudio.Validate_slt_classformats_chkbxs_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,Checkbox_class_formats);
							context.setAttribute("fileName", "Validate_slt_classformats_chkbxs_in_l3_RFI");
							driver.quit();break;

							
							
							case "Validate_AE_sec2_allelements_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_AE_sec2_allelements_in_l3_RFI");
								ClubStudio.Validate_AE_sec2_allelements_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,input_data,Checkbox_class_formats);
								context.setAttribute("fileName", "Validate_AE_sec2_allelements_in_l3_RFI");
								driver.quit();break;
						
							case "Validate_AE_sec3_allelements_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_AE_sec3_allelements_in_l3_RFI");
								ClubStudio.Validate_AE_sec3_allelements_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,input_data,Checkbox_class_formats);
								context.setAttribute("fileName", "Validate_AE_sec3_allelements_in_l3_RFI");
								driver.quit();break;
							
								
							case "Validate_alert_nomorethan3_Emprs_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_alert_nomorethan3_Emprs_in_l3_RFI");
								ClubStudio.Validate_alert_nomorethan3_Emprs_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,input_data,Checkbox_class_formats);
								context.setAttribute("fileName", "Validate_alert_nomorethan3_Emprs_in_l3_RFI");
								driver.quit();break;

							
								
							case "Validate_Aerobic_cert_texts_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_Aerobic_cert_texts_in_l3_RFI");
								ClubStudio.Validate_Aerobic_cert_texts_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, input_data );
								context.setAttribute("fileName", "Validate_Aerobic_cert_texts_in_l3_RFI");
								driver.quit();break;
						
								
							case "Validate_Add_cert_btn_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_Add_cert_btn_in_l3_RFI");
								ClubStudio.Validate_Add_cert_btn_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
								context.setAttribute("fileName", "Validate_Add_cert_btn_in_l3_RFI");
								driver.quit();break;
								
							case "Validate_Aerobic_cert_all_fields_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_Aerobic_cert_all_fields_in_l3_RFI");
								ClubStudio.Validate_Aerobic_cert_all_fields_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
								context.setAttribute("fileName", "Validate_Aerobic_cert_all_fields_in_l3_RFI");
								driver.quit();break;
						
								
							case "Validate_Choosefile_and_cert_format_txt_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_Choosefile_and_cert_format_txt_in_l3_RFI");
								ClubStudio.Validate_Choosefile_and_cert_format_txt_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, input_data );
								context.setAttribute("fileName", "Validate_Choosefile_and_cert_format_txt_in_l3_RFI");
								driver.quit();break;
								
								
							case "Validate_add_emplr_remove_img_btn_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_add_emplr_remove_img_btn_in_l3_RFI");
								ClubStudio.Validate_add_emplr_remove_img_btn_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,input_data );
								context.setAttribute("fileName", "Validate_add_emplr_remove_img_btn_in_l3_RFI");
								driver.quit();break;
								
								
							case "Validate_Aero_cert_remove_img_btn_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_Aero_cert_remove_img_btn_in_l3_RFI");
								ClubStudio.Validate_Aero_cert_remove_img_btn_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, input_data );
								context.setAttribute("fileName", "Validate_Aero_cert_remove_img_btn_in_l3_RFI");
								driver.quit();break;
								
								
							case "Validate_upload_cert_file_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_upload_cert_file_in_l3_RFI");
								ClubStudio.Validate_upload_cert_file_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, input_data, File_name );
								context.setAttribute("fileName", "Validate_upload_cert_file_in_l3_RFI");
								driver.quit();break;
								
							case "Validate_CertifiedIn_dd_all_values_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_CertifiedIn_dd_all_values_in_l3_RFI");
								ClubStudio.Validate_CertifiedIn_dd_all_values_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, Certified_In_DD );
								context.setAttribute("fileName", "Validate_CertifiedIn_dd_all_values_in_l3_RFI");
								driver.quit();break;
								
								
							case "Validate_CertifiedIn_select_desiredvalue_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_CertifiedIn_select_desiredvalue_in_l3_RFI");
								ClubStudio.Validate_CertifiedIn_select_desiredvalue_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, Certified_In_DD );
								context.setAttribute("fileName", "Validate_CertifiedIn_select_desiredvalue_in_l3_RFI");
								driver.quit();break;
								
								
							case "Validate_IssuedBy_DD_enabled_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_IssuedBy_DD_enabled_in_l3_RFI");
								ClubStudio.Validate_IssuedBy_DD_enabled_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, Certified_In_DD );
								context.setAttribute("fileName", "Validate_IssuedBy_DD_enabled_in_l3_RFI");
								driver.quit();break;
								
								
								
							case "Validate_IssuedBy_DD_disabled_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_IssuedBy_DD_disabled_in_l3_RFI");
								ClubStudio.Validate_IssuedBy_DD_disabled_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, Certified_In_DD );
								context.setAttribute("fileName", "Validate_IssuedBy_DD_disabled_in_l3_RFI");
								driver.quit();break;
								
								
							case "Validate_IssuedBy_dd_all_values_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_IssuedBy_dd_all_values_in_l3_RFI");
								ClubStudio.Validate_IssuedBy_dd_all_values_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, Certified_In_DD,Certification_IssuedByDPValues );
								context.setAttribute("fileName", "Validate_IssuedBy_dd_all_values_in_l3_RFI");
								driver.quit();break;
								
								
							case "Validate_Input_in_Cert_no_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_Input_in_Cert_no_in_l3_RFI");
								ClubStudio.Validate_Input_in_Cert_no_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button,  Certificate_No);
								context.setAttribute("fileName", "Validate_Input_in_Cert_no_in_l3_RFI");
								driver.quit();break;
								
							case "Validate_filling_all_fields_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_filling_all_fields_in_l3_RFI");
								ClubStudio.Validate_filling_all_fields_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
								context.setAttribute("fileName", "Validate_filling_all_fields_in_l3_RFI");
								driver.quit();break;
								
								
							case "Validate_Aero_cert2_all_fields_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_Aero_cert2_all_fields_in_l3_RFI");
								ClubStudio.Validate_Aero_cert2_all_fields_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
								context.setAttribute("fileName", "Validate_Aero_cert2_all_fields_in_l3_RFI");
								driver.quit();break;
								
							case "Validate_Aero_cert3_all_fields_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_Aero_cert3_all_fields_in_l3_RFI");
								ClubStudio.Validate_Aero_cert3_all_fields_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
								context.setAttribute("fileName", "Validate_Aero_cert3_all_fields_in_l3_RFI");
								driver.quit();break;
								
							case "Validate_Aero_cert4_all_fields_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_Aero_cert4_all_fields_in_l3_RFI");
								ClubStudio.Validate_Aero_cert4_all_fields_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
								context.setAttribute("fileName", "Validate_Aero_cert4_all_fields_in_l3_RFI");
								driver.quit();break;
								
							case "Validate_alert_nomorethan_4_cert_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_alert_nomorethan_4_cert_in_l3_RFI");
								ClubStudio.Validate_alert_nomorethan_4_cert_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
								context.setAttribute("fileName", "Validate_alert_nomorethan_4_cert_in_l3_RFI");
								driver.quit();break;
								
								
							case "Validate_removebtn_by_ip_in_cert_sec_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_removebtn_by_ip_in_cert_sec_in_l3_RFI");
								ClubStudio.Validate_removebtn_by_ip_in_cert_sec_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name, input_data  );
								context.setAttribute("fileName", "Validate_removebtn_by_ip_in_cert_sec_in_l3_RFI");
								driver.quit();break;
								
								
								
								
							case "Validate_removebtn_by_ip_addemployer_in_l3_RFI":
								
								context.setAttribute("fileName", "Validate_removebtn_by_ip_addemployer_in_l3_RFI");
								ClubStudio.Validate_removebtn_by_ip_addemployer_in_l3_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats  );
								context.setAttribute("fileName", "Validate_removebtn_by_ip_addemployer_in_l3_RFI");
								driver.quit();break;
								
								
								
							case "Validate_emp_his_pre_emp_texts_in_l4_RFI":
								
								context.setAttribute("fileName", "Validate_emp_his_pre_emp_texts_in_l4_RFI");
								ClubStudio.Validate_emp_his_pre_emp_texts_in_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
								context.setAttribute("fileName", "Validate_emp_his_pre_emp_texts_in_l4_RFI");
								driver.quit();break;
								
							case "Validate_radio_btns_of_emp_his_in_l4_RFI":
								
								context.setAttribute("fileName", "Validate_radio_btns_of_emp_his_in_l4_RFI");
								ClubStudio.Validate_radio_btns_of_emp_his_in_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
								context.setAttribute("fileName", "Validate_radio_btns_of_emp_his_in_l4_RFI");
								driver.quit();break;
								
								
							case "Validate_upload_resume_chkbx_in_l4_RFI":
								
								context.setAttribute("fileName", "Validate_upload_resume_chkbx_in_l4_RFI");
								ClubStudio.Validate_upload_resume_chkbx_in_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
								context.setAttribute("fileName", "Validate_upload_resume_chkbx_in_l4_RFI");
								driver.quit();break;
								
								
								
							case "Validate_upload_resume_sec_in_l4_RFI":
								
								context.setAttribute("fileName", "Validate_upload_resume_sec_in_l4_RFI");
								ClubStudio.Validate_upload_resume_sec_in_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name, input_data );
								context.setAttribute("fileName", "Validate_upload_resume_sec_in_l4_RFI");
								driver.quit();break;
								
								
								
							case "Validate_upload_resumefile_l4_RFI":
								
								context.setAttribute("fileName", "Validate_upload_resumefile_l4_RFI");
								ClubStudio.Validate_upload_resumefile_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name, input_data );
								context.setAttribute("fileName", "Validate_upload_resumefile_l4_RFI");
								driver.quit();break;
								
								
								
							case "Validate_current_previous_emp_texts_in_l4_RFI":
								
								context.setAttribute("fileName", "Validate_current_previous_emp_texts_in_l4_RFI");
								ClubStudio.Validate_current_previous_emp_texts_in_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name, input_data );
								context.setAttribute("fileName", "Validate_current_previous_emp_texts_in_l4_RFI");
								driver.quit();break;
								
								
							case "Validate_all_input_fields_in_l4_RFI":
								
								context.setAttribute("fileName", "Validate_all_input_fields_in_l4_RFI");
								ClubStudio.Validate_all_input_fields_in_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
								context.setAttribute("fileName", "Validate_all_input_fields_in_l4_RFI");
								driver.quit();break;
								
								
								
							case "Validate_ip_inallfields_in_l4_RFI":
								
								context.setAttribute("fileName", "Validate_ip_inallfields_in_l4_RFI");
								ClubStudio.Validate_ip_inallfields_in_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button);
								context.setAttribute("fileName", "Validate_ip_inallfields_in_l4_RFI");
								driver.quit();break;
								
								
								
							case "Validate_prev_next_step_btns_in_l4_RFI":
								
								context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4_RFI");
								ClubStudio.Validate_prev_next_step_btns_in_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
								context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4_RFI");
								driver.quit();break;
								
								
								
							case "Validate_add_emply_2_btn_in_l4_RFI":
								
								context.setAttribute("fileName", "Validate_add_emply_2_btn_in_l4_RFI");
								ClubStudio.Validate_add_emply_2_btn_in_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
								context.setAttribute("fileName", "Validate_add_emply_2_btn_in_l4_RFI");
								driver.quit();break;
								
								
							case "Validate_Next_btn_in_l4_RFI":
								
								context.setAttribute("fileName", "Validate_Next_btn_in_l4_RFI");
								ClubStudio.Validate_Next_btn_in_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
								context.setAttribute("fileName", "Validate_Next_btn_in_l4_RFI");
								driver.quit();break;
							
								
							case "Validate_No_Previous_Emp_RdoBtn_in_l4_RFI":
								
								context.setAttribute("fileName", "Validate_No_Previous_Emp_RdoBtn_in_l4_RFI");
								ClubStudio.Validate_No_Previous_Emp_RdoBtn_in_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
								context.setAttribute("fileName", "Validate_No_Previous_Emp_RdoBtn_in_l4_RFI");
								driver.quit();break;
								
								
							case "Validate_prev_step_btn_in_l4_RFI":
								
								context.setAttribute("fileName", "Validate_prev_step_btn_in_l4_RFI");
								ClubStudio.Validate_prev_step_btn_in_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
								context.setAttribute("fileName", "Validate_prev_step_btn_in_l4_RFI");
								driver.quit();break;
								
								
							case "Validate_all_ip_fieldsof_Addemplr2_in_l4_RFI":
								
								context.setAttribute("fileName", "Validate_all_ip_fieldsof_Addemplr2_in_l4_RFI");
								ClubStudio.Validate_all_ip_fieldsof_Addemplr2_in_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
								context.setAttribute("fileName", "Validate_all_ip_fieldsof_Addemplr2_in_l4_RFI");
								driver.quit();break;
								
								
							case "Validate_all_ip_fieldsof_Addemplr3_in_l4_RFI":
								
								context.setAttribute("fileName", "Validate_all_ip_fieldsof_Addemplr3_in_l4_RFI");
								ClubStudio.Validate_all_ip_fieldsof_Addemplr3_in_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
								context.setAttribute("fileName", "Validate_all_ip_fieldsof_Addemplr3_in_l4_RFI");
								driver.quit();break;
								
						
								
								
							case "Validate_removebtn2_by_ip_in_empr2_in_l4_RFI":
								
								context.setAttribute("fileName", "Validate_removebtn2_by_ip_in_empr2_in_l4_RFI");
								ClubStudio.Validate_removebtn2_by_ip_in_empr2_in_l4_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button);
								context.setAttribute("fileName", "Validate_removebtn2_by_ip_in_empr2_in_l4_RFI");
								driver.quit();break;
								
								
								
							case "Validate_Indicate_languages_text_l5_RFI":
								
								context.setAttribute("fileName", "Validate_Indicate_languages_text_l5_RFI");
								ClubStudio.Validate_Indicate_languages_text_l5_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, input_data);
								context.setAttribute("fileName", "Validate_Indicate_languages_text_l5_RFI");
								driver.quit();break;
								
							case "Validate_all_languages_in_l5_RFI":
								
								context.setAttribute("fileName", "Validate_all_languages_in_l5_RFI");
								ClubStudio.Validate_all_languages_in_l5_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
								context.setAttribute("fileName", "Validate_all_languages_in_l5_RFI");
								driver.quit();break;
								
								
							case "Validate_bydefault_Eng_lang_isselected_in_l5_RFI":
								
								context.setAttribute("fileName", "Validate_bydefault_Eng_lang_isselected_in_l5_RFI");
								ClubStudio.Validate_bydefault_Eng_lang_isselected_in_l5_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
								context.setAttribute("fileName", "Validate_bydefault_Eng_lang_isselected_in_l5_RFI");
								driver.quit();break;
								
							case "Validate_select_desired_langs_in_l5_RFI":
								
								context.setAttribute("fileName", "Validate_select_desired_langs_in_l5_RFI");
								ClubStudio.Validate_select_desired_langs_in_l5_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
								context.setAttribute("fileName", "Validate_select_desired_langs_in_l5_RFI");
								driver.quit();break;
								
							case "Validate_prev_next_step_btns_in_l5_RFI":
								
								context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5_RFI");
								ClubStudio.Validate_prev_next_step_btns_in_l5_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
								context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5_RFI");
								driver.quit();break;
								
							case "Validate_prev_step_btn_in_l5_RFI":
								
								context.setAttribute("fileName", "Validate_prev_step_btn_in_l5_RFI");
								ClubStudio.Validate_prev_step_btn_in_l5_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
								context.setAttribute("fileName", "Validate_prev_step_btn_in_l5_RFI");
								driver.quit();break;
								
							case "Validate_Next_step_btn_in_l5_RFI":
								
								context.setAttribute("fileName", "Validate_Next_step_btn_in_l5_RFI");
								ClubStudio.Validate_Next_step_btn_in_l5_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
								context.setAttribute("fileName", "Validate_Next_step_btn_in_l5_RFI");
								driver.quit();break;
								
						
							
							case "Validate_text_COqualify_in_l6_RFI":
								
								context.setAttribute("fileName", "Validate_text_COqualify_in_l6_RFI");
								ClubStudio.Validate_text_COqualify_in_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, input_data);
								context.setAttribute("fileName", "Validate_text_COqualify_in_l6_RFI");
								driver.quit();break;
								
								
							case "Validate_all_fields_in_l6_RFI":
								
								context.setAttribute("fileName", "Validate_all_fields_in_l6_RFI");
								ClubStudio.Validate_all_fields_in_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Considered_for_chkbx);
								context.setAttribute("fileName", "Validate_all_fields_in_l6_RFI");
								driver.quit();break;
								
								
								
							case "Validate_slt_Worktime_l6_RFI":
								
								context.setAttribute("fileName", "Validate_slt_Worktime_l6_RFI");
								ClubStudio.Validate_slt_Worktime_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Work_time);
								context.setAttribute("fileName", "Validate_slt_Worktime_l6_RFI");
								driver.quit();break;
								
								
								
							case "Validate_slt_considerfor_chkbxs_l6_RFI":
								
								context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6_RFI");
								ClubStudio.Validate_slt_considerfor_chkbxs_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx);
								context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6_RFI");
								driver.quit();break;
							
								
							case "Validate_deslt_considerfor_chkbxs_l6_RFI":
								
								context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6_RFI");
								ClubStudio.Validate_deslt_considerfor_chkbxs_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx);
								context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6_RFI");
								driver.quit();break;
								
								
								
							case "Validate_COs_asperCFchkbxsltn_l6_RFI":
								
								context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6_RFI");
								ClubStudio.Validate_COs_asperCFchkbxsltn_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx);
								context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6_RFI");
								driver.quit();break;
								
								
							case "Validate_COs_asperCFchkbxdesltn_l6_RFI":
								
								context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6_RFI");
								ClubStudio.Validate_COs_asperCFchkbxdesltn_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx, input_data);
								context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6_RFI");
								driver.quit();break;
								
								
							case "Validate_defaultvalueofCO_l6_RFI":
								
								context.setAttribute("fileName", "Validate_defaultvalueofCO_l6_RFI");
								ClubStudio.Validate_defaultvalueofCO_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Considered_for_chkbx);
								context.setAttribute("fileName", "Validate_defaultvalueofCO_l6_RFI");
								driver.quit();break;
								
		
								
							case "Validate_ip_date_to_begin_l6_RFI":
								
								context.setAttribute("fileName", "Validate_ip_date_to_begin_l6_RFI");
								ClubStudio.Validate_ip_date_to_begin_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Date_to_begin);
								context.setAttribute("fileName", "Validate_ip_date_to_begin_l6_RFI");
								driver.quit();break;
								
								
							case "Validate_empdwithus_no_rdobtn_l6_RFI":
								
								context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6_RFI");
								ClubStudio.Validate_empdwithus_no_rdobtn_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, input_data);
								context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6_RFI");
								driver.quit();break;
								
								
							case "Validate_basedonsltns_text_l6_RFI":
								
								context.setAttribute("fileName", "Validate_basedonsltns_text_l6_RFI");
								ClubStudio.Validate_basedonsltns_text_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, input_data);
								context.setAttribute("fileName", "Validate_basedonsltns_text_l6_RFI");
								driver.quit();break;
								
								
							case "Validate_Club_locations_l6_RFI":
								
								context.setAttribute("fileName", "Validate_Club_locations_l6_RFI");
								ClubStudio.Validate_Club_locations_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, input_data);
								context.setAttribute("fileName", "Validate_Club_locations_l6_RFI");
								driver.quit();break;
								
							case "Validate_Rehire_Questionnaire_sec_l6_RFI":
								
								context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l6_RFI");
								ClubStudio.Validate_Rehire_Questionnaire_sec_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, input_data);
								context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l6_RFI");
								driver.quit();break;
								
								
							case "Validate_Resigned_dd_allvalues_l6_RFI":
								
								context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6_RFI");
								ClubStudio.Validate_Resigned_dd_allvalues_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, EmploymentHowResigned_dd);
								context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6_RFI");
								driver.quit();break;
								
								
								
							case "Validate_ip_in_RQ_sec_l6_RFI":
								
								context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6_RFI");
								ClubStudio.Validate_ip_in_RQ_sec_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages , EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
								context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6_RFI");
								driver.quit();break;
							
								
								
							case "Validate_prev_next_step_btns_l6_RFI":
								
								context.setAttribute("fileName", "Validate_prev_next_step_btns_l6_RFI");
								ClubStudio.Validate_prev_next_step_btns_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
								context.setAttribute("fileName", "Validate_prev_next_step_btns_l6_RFI");
								driver.quit();break;
								
								
							case "Validate_prev_step_btn_in_l6_RFI":
								
								context.setAttribute("fileName", "Validate_prev_step_btn_in_l6_RFI");
								ClubStudio.Validate_prev_step_btn_in_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
								context.setAttribute("fileName", "Validate_prev_step_btn_in_l6_RFI");
								driver.quit();break;
								
							case "Validate_next_btn_byipallfields_l6_RFI":
								
								context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6_RFI");
								ClubStudio.Validate_next_btn_byipallfields_l6_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
								context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6_RFI");
								driver.quit();break;
								
								
								
							case "Validate_paras_in_l7_RFI":
								
								context.setAttribute("fileName", "Validate_paras_in_l7_RFI");
								ClubStudio.Validate_paras_in_l7_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, input_data);
								context.setAttribute("fileName", "Validate_paras_in_l7_RFI");
								driver.quit();break;
								
								
								
							case "Validate_rdobtns_in_l7_RFI":
								
								context.setAttribute("fileName", "Validate_rdobtns_in_l7_RFI");
								ClubStudio.Validate_rdobtns_in_l7_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
								context.setAttribute("fileName", "Validate_rdobtns_in_l7_RFI");
								driver.quit();break;
								
								
								
							case "Validate_all_form_sec_in_l7_RFI":
								
								context.setAttribute("fileName", "Validate_all_form_sec_in_l7_RFI");
								ClubStudio.Validate_all_form_sec_in_l7_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
								context.setAttribute("fileName", "Validate_all_form_sec_in_l7_RFI");
								driver.quit();break;
								
								
								
							case "Validate_all_options_of_Gender_dd_in_l7_RFI":
								
								context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_RFI");
								ClubStudio.Validate_all_options_of_Gender_dd_in_l7_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,Gender_dd);
								context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_RFI");
								driver.quit();break;
								
								
								
							case "Validate_all_options_of_RE_dd_in_l7_RFI":
								
								context.setAttribute("fileName", "Validate_all_options_of_RE_dd_in_l7_RFI");
								ClubStudio.Validate_all_options_of_RE_dd_in_l7_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,RaceEthnicity_dd);
								context.setAttribute("fileName", "Validate_all_options_of_RE_dd_in_l7_RFI");
								driver.quit();break;
								
								
							case "Validate_EOE_details_paras_in_l7_RFI":
								
								context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7_RFI");
								ClubStudio.Validate_EOE_details_paras_in_l7_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,input_data);
								context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7_RFI");
								driver.quit();break;
								
								
								
							case "Validate_No_rdobtnof_form_sec_in_l7_RFI":
								
								context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7_RFI");
								ClubStudio.Validate_No_rdobtnof_form_sec_in_l7_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
								context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7_RFI");
								driver.quit();break;
								
								
							case "Validate_prev_next_step_btns_in_l7_RFI":
								
								context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7_RFI");
								ClubStudio.Validate_prev_next_step_btns_in_l7_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
								context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7_RFI");
								driver.quit();break;
								
								
							case "Validate_prev_step_btn_in_l7_RFI":
								
								context.setAttribute("fileName", "Validate_prev_step_btn_in_l7_RFI");
								ClubStudio.Validate_prev_step_btn_in_l7_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
								context.setAttribute("fileName", "Validate_prev_step_btn_in_l7_RFI");
								driver.quit();break;
								
								
							case "Validate_Next_step_btn_in_l7_RFI":
								
								context.setAttribute("fileName", "Validate_Next_step_btn_in_l7_RFI");
								ClubStudio.Validate_Next_step_btn_in_l7_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
								context.setAttribute("fileName", "Validate_Next_step_btn_in_l7_RFI");
								driver.quit();break;
								
								
							case "Validate_Nav_to_l8_RFI":
								
								context.setAttribute("fileName", "Validate_Nav_to_l8_RFI");
								ClubStudio.Validate_Nav_to_l8_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
								context.setAttribute("fileName", "Validate_Nav_to_l8_RFI");
								driver.quit();break;
							
								
								
							case "Validate_AS_paras_in_l8_RFI":
								
								context.setAttribute("fileName", "Validate_AS_paras_in_l8_RFI");
								ClubStudio.Validate_AS_paras_in_l8_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
								context.setAttribute("fileName", "Validate_AS_paras_in_l8_RFI");
								driver.quit();break;
								
								
							case "Validate_ackmnt_in_l8_RFI":
								
								context.setAttribute("fileName", "Validate_ackmnt_in_l8_RFI");
								ClubStudio.Validate_ackmnt_in_l8_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
								context.setAttribute("fileName", "Validate_ackmnt_in_l8_RFI");
								driver.quit();break;
								
								
							case "Validate_ip_in_Signedbyname_in_l8_RFI":
								
								context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_RFI");
								ClubStudio.Validate_ip_in_Signedbyname_in_l8_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
								context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_RFI");
								driver.quit();break;
								
								
							case "Validate_prev_next_step_btns_in_l8_RFI":
								
								context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8_RFI");
								ClubStudio.Validate_prev_next_step_btns_in_l8_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
								context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8_RFI");
								driver.quit();break;
								
								
							case "Validate_prev_step_btn_in_l8_RFI":
								
								context.setAttribute("fileName", "Validate_prev_step_btn_in_l8_RFI");
								ClubStudio.Validate_prev_step_btn_in_l8_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
								context.setAttribute("fileName", "Validate_prev_step_btn_in_l8_RFI");
								driver.quit();break;
								
								
							case "Validate_Next_btn_in_l8_RFI":
								
								context.setAttribute("fileName", "Validate_Next_btn_in_l8_RFI");
								ClubStudio.Validate_Next_btn_in_l8_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
								context.setAttribute("fileName", "Validate_Next_btn_in_l8_RFI");
								driver.quit();break;
								
								
							case "Validate_heading_in_l9_RFI":
								
								context.setAttribute("fileName", "Validate_heading_in_l9_RFI");
								ClubStudio.Validate_heading_in_l9_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
								context.setAttribute("fileName", "Validate_heading_in_l9_RFI");
								driver.quit();break;
								
								
							case "Validate_Rules_procedures_in_l9_RFI":
								
								context.setAttribute("fileName", "Validate_Rules_procedures_in_l9_RFI");
								ClubStudio.Validate_Rules_procedures_in_l9_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
								context.setAttribute("fileName", "Validate_Rules_procedures_in_l9_RFI");
								driver.quit();break;
								
								
							case "Validate_ip_in_prtname_dateandipadd_in_l9_RFI":
								
								context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9_RFI");
								ClubStudio.Validate_ip_in_prtname_dateandipadd_in_l9_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, IP_Address);
								context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9_RFI");
								driver.quit();break;
								
								
								
								
							case "Validate_Robert_Bryant_Sign_in_l9_RFI":
								
								context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_RFI");
								ClubStudio.Validate_Robert_Bryant_Sign_in_l9_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
								context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_RFI");
								driver.quit();break;
								
								
							case "Validate_Iagree_textandbtn_in_l9_RFI":
								
								context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_RFI");
								ClubStudio.Validate_Iagree_textandbtn_in_l9_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
								context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_RFI");
								driver.quit();break;
								
								
							case "Validate_Prev_step_btn_in_l9_RFI":
								
								context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9_RFI");
								ClubStudio.Validate_Prev_step_btn_in_l9_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
								context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9_RFI");
								driver.quit();break;
								
								
							case "Validate_Iagreebtn_and_succ_submsn_in_l9_RFI":
								
								context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_RFI");
								ClubStudio.Validate_Iagreebtn_and_succ_submsn_in_l9_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
								context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_RFI");
								driver.quit();break;
								
								
								
							case "Validate_Success_msg_in_final_page_RFI":
								
								context.setAttribute("fileName", "Validate_Success_msg_in_final_page_RFI");
								ClubStudio.Validate_Success_msg_in_final_page_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
								context.setAttribute("fileName", "Validate_Success_msg_in_final_page_RFI");
								driver.quit();break;
								
								
							case "Validate_prtbtn_in_print_emp_app_page_RFI":
								
								context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page_RFI");
								ClubStudio.Validate_prtbtn_in_print_emp_app_page_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
								context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page_RFI");
								driver.quit();break;
								
								
								
							case "Validate_Rules_link_in_l9_RFI":
								
								context.setAttribute("fileName", "Validate_Rules_link_in_l9_RFI");
								ClubStudio.Validate_Rules_link_in_l9_RFI(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
								context.setAttribute("fileName", "Validate_Rules_link_in_l9_RFI");
								driver.quit();break;
								
								
								
							case "Validate_emp_para_BC":
								
								context.setAttribute("fileName", "Validate_emp_para_BC");
								ClubStudio.Validate_emp_para_BC(testdata.get("TextMessage").toString(), Text_input, additional_input);
								context.setAttribute("fileName", "Validate_emp_para_BC");
								driver.quit();
								break;
							
								

							case "Validate_App_info_text_BC":
								
								context.setAttribute("fileName", "Validate_App_info_text_BC");
								ClubStudio.Validate_App_info_text_BC(testdata.get("TextMessage").toString(), Text_input, additional_input);
								context.setAttribute("fileName", "Validate_App_info_text_BC");
								driver.quit();
								break;
								
								
							case "Validate_all_ip_fields_in_emp_page_BC":
								
								context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page_BC");
								ClubStudio.Validate_all_ip_fields_in_emp_page_BC(testdata.get("TextMessage").toString(), Text_input);
								context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page_BC");
								driver.quit();
								break;
								
								
							case "Validate_Howdidyouhearaboutus_dd_BC":
								
								context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd_BC");
								ClubStudio.Validate_Howdidyouhearaboutus_dd_BC(testdata.get("TextMessage").toString(), Text_input, Dropdown_values);
								context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd_BC");
								driver.quit();
								break;
								
							case "Validate_Radiobtn18YearsOld_options_BC":
								
								context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_BC");
								ClubStudio.Validate_Radiobtn18YearsOld_options_BC(testdata.get("TextMessage").toString(), Text_input);
								context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_BC");
								driver.quit();
								break;
								
								
							case "Validate_US_format_text_BC":
								
								context.setAttribute("fileName", "Validate_US_format_text_BC");
								ClubStudio.Validate_US_format_text_BC(testdata.get("TextMessage").toString(), Text_input, additional_input);
								context.setAttribute("fileName", "Validate_US_format_text_BC");
								driver.quit();
								break;
								
								
							case "Validate_Miles_text_BC":
								
								context.setAttribute("fileName", "Validate_Miles_text_BC");
								ClubStudio.Validate_Miles_text_BC(testdata.get("TextMessage").toString(), Text_input, additional_input);
								context.setAttribute("fileName", "Validate_Miles_text_BC");
								driver.quit();
								break;
								
							case "Validate_phone_errorlabel_BC":
								
								context.setAttribute("fileName", "Validate_phone_errorlabel_BC");
								ClubStudio.Validate_phone_errorlabel_BC(testdata.get("TextMessage").toString(), Text_input, additional_input);
								context.setAttribute("fileName", "Validate_phone_errorlabel_BC");
								driver.quit();
								break;
								
								
							case "Validate_Next_step_button_in_l1_BC":
								
								context.setAttribute("fileName", "Validate_Next_step_button_in_l1_BC");
								ClubStudio.Validate_Next_step_button_in_l1_BC(testdata.get("TextMessage").toString(), Text_input);
								context.setAttribute("fileName", "Validate_Next_step_button_in_l1_BC");
								driver.quit();
								break;
								
								
								
							case "Validate_input_in_all_fields_BC":
								
							context.setAttribute("fileName", "Validate_input_in_all_fields_BC");
							ClubStudio.Validate_input_in_all_fields_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode  );
							context.setAttribute("fileName", "Validate_input_in_all_fields_BC");
							driver.quit();break;
								
							
							
							case "Validate_List18YrsOld_No_popupalrt_BC":
								
								context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt_BC");
								ClubStudio.Validate_List18YrsOld_No_popupalrt_BC(testdata.get("TextMessage").toString(), Text_input, Radiobtn18YearsOld);
								context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt_BC");
								driver.quit();
								break;
								
								
								
							case "Validate_Next_step_l1_BC":
								
							context.setAttribute("fileName", "Validate_Next_step_l1_BC");
							ClubStudio.Validate_Next_step_l1_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
							context.setAttribute("fileName", "Validate_Next_step_l1_BC");
							driver.quit();break;
								
							
							case "Validate_education_level_dd_BC":
								
							context.setAttribute("fileName", "Validate_education_level_dd_RFFI");
							ClubStudio.Validate_education_level_dd_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
							context.setAttribute("fileName", "Validate_education_level_dd_RI");
							driver.quit();break;
							
								
							
							case "Validate_edu_level_dd_allvalues_BC":
								
							context.setAttribute("fileName", "Validate_edu_level_dd_allvalues_BC");
							ClubStudio.Validate_edu_level_dd_allvalues_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input , E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "Validate_edu_level_dd_allvalues_BC");
							driver.quit();break;
							
							
							
							case "Validate_previous_next_step_buttons_l2_BC":
								
							context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2_BC");
							ClubStudio.Validate_previous_next_step_buttons_l2_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
							context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2_BC");
							driver.quit();break;
							
							
							case "Validate_previous_step_button_l2_BC":
								
							context.setAttribute("fileName", "Validate_previous_step_button_l2_BC");
							ClubStudio.Validate_previous_step_button_l2_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
							context.setAttribute("fileName", "Validate_previous_step_button_l2_BC");
							driver.quit();break;
							
							
							case "Validate_Next_step_button_l2_BC":
								
							context.setAttribute("fileName", "Validate_Next_step_button_l2_BC");
							ClubStudio.Validate_Next_step_button_l2_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown  );
							context.setAttribute("fileName", "Validate_Next_step_button_l2_BC");
							driver.quit();break;
							
							case "Validate_Exp_info_text_in_l3_BC":
								
							context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_BC");
							ClubStudio.Validate_Exp_info_text_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
							context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_BC");
							driver.quit();break;
							
							case "Validate_GP_AI_text_in_l3_BC":
								
							context.setAttribute("fileName", "Validate_GP_AI_text_in_l3_BC");
							ClubStudio.Validate_GP_AI_text_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
							context.setAttribute("fileName", "Validate_GP_AI_text_in_l3_BC");
							driver.quit();break;
							
							
							case "Validate_GP_AI_exp_dd_in_l3_BC":
								
							context.setAttribute("fileName", "Validate_GP_AI_exp_dd_in_l3_BC");
							ClubStudio.Validate_GP_AI_exp_dd_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown  );
							context.setAttribute("fileName", "Validate_GP_AI_exp_dd_in_l3_BC");
							driver.quit();break;
							
							
							case "Validate_GP_AI_exp_dd_all_values_in_l3_BC":
								
							context.setAttribute("fileName", "Validate_GP_AI_exp_dd_all_values_in_l3_BC");
							ClubStudio.Validate_GP_AI_exp_dd_all_values_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
							context.setAttribute("fileName", "Validate_GP_AI_exp_dd_all_values_in_l3_BC");
							driver.quit();break;
							
							
							case "Validate_Hold_a_Cert_rdo_btns_in_l3_BC":
								
							context.setAttribute("fileName", "Validate_Hold_a_Cert_rdo_btns_in_l3_BC");
							ClubStudio.Validate_Hold_a_Cert_rdo_btns_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "Validate_Hold_a_Cert_rdo_btns_in_l3_BC");
							driver.quit();break;
							
							case "Validate_GF_A_CertfnInfo_link_BC":
								
							context.setAttribute("fileName", "Validate_GF_A_CertfnInfo_link_BC");
							ClubStudio.Validate_GF_A_CertfnInfo_link_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "Validate_GF_A_CertfnInfo_link_BC");
							driver.quit();break;
							
							
							case "Validate_prev_next_step_btns_in_l3_BC":
								
							context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l3_BC");
							ClubStudio.Validate_prev_next_step_btns_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l3_BC");
							driver.quit();break;
							
							
							case "Validate_previous_step_btn_in_l3_BC":
								
							context.setAttribute("fileName", "Validate_previous_step_btn_in_l3_BC");
							ClubStudio.Validate_previous_step_btn_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "Validate_previous_step_btn_in_l3_BC");
							driver.quit();break;
							
							
							case "Validate_next_step_btn_in_l3_BC":
								
								context.setAttribute("fileName", "Validate_next_step_btn_in_l3_BC");
								ClubStudio.Validate_next_step_btn_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
								context.setAttribute("fileName", "Validate_next_step_btn_in_l3_BC");
								driver.quit();break;

								
							case "Validate_exp_details_texts_in_l3_BC":
								
							context.setAttribute("fileName", "Validate_exp_details_texts_in_l3_BC");
							ClubStudio.Validate_exp_details_texts_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD, input_data);
							context.setAttribute("fileName", "Validate_exp_details_texts_in_l3_BC");
							driver.quit();break;
									
								
							case "Validate_add_employer_btn_in_l3_BC":
								
								context.setAttribute("fileName", "Validate_add_employer_btn_in_l3_BC");
								ClubStudio.Validate_add_employer_btn_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD);
								context.setAttribute("fileName", "Validate_add_employer_btn_in_l3_BC");
								driver.quit();break;
							
							
							case "Validate_TP_CE_CW_elements_in_l3_BC":
								
								context.setAttribute("fileName", "Validate_TP_CE_CW_elements_in_l3_BC");
								ClubStudio.Validate_TP_CE_CW_elements_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD);
								context.setAttribute("fileName", "Validate_TP_CE_CW_elements_in_l3_BC");
								driver.quit();break;
								


							case "Validate_class_formats_chkbxs_in_l3_BC":
								
								context.setAttribute("fileName", "Validate_class_formats_chkbxs_in_l3_BC");
								ClubStudio.Validate_class_formats_chkbxs_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,input_data,Checkbox_class_formats);
								context.setAttribute("fileName", "Validate_class_formats_chkbxs_in_l3_BC");
								driver.quit();break;
								
							
							case "Validate_Timeperiod_dd_all_options_in_l3_BC":
								
								context.setAttribute("fileName", "Validate_Timeperiod_dd_all_options_in_l3_BC");
								ClubStudio.Validate_Timeperiod_dd_all_options_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,Time_period_DD);
								context.setAttribute("fileName", "Validate_Timeperiod_dd_all_options_in_l3_BC");
								driver.quit();break;
								
							
							case "Validate_Club_emplr_dd_all_options_in_l3_BC":
								
								context.setAttribute("fileName", "Validate_Club_emplr_dd_all_options_in_l3_BC");
								ClubStudio.Validate_Club_emplr_dd_all_options_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,Club_Employer_DD);
								context.setAttribute("fileName", "Validate_Club_emplr_dd_all_options_in_l3_BC");
								driver.quit();break;	
								
								
							case "Validate_cpw_ip_value_in_l3_BC":
								
								context.setAttribute("fileName", "Validate_cpw_ip_value_in_l3_BC");
								ClubStudio.Validate_cpw_ip_value_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,Class_per_week);
								context.setAttribute("fileName", "Validate_cpw_ip_value_in_l3_BC");
								driver.quit();break;
								
							
								
							case "Validate_slt_classformats_chkbxs_in_l3_BC":
								
								context.setAttribute("fileName", "Validate_slt_classformats_chkbxs_in_l3_BC");
								ClubStudio.Validate_slt_classformats_chkbxs_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,Checkbox_class_formats);
								context.setAttribute("fileName", "Validate_slt_classformats_chkbxs_in_l3_BC");
								driver.quit();break;

								
								
								case "Validate_AE_sec2_allelements_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_AE_sec2_allelements_in_l3_BC");
									ClubStudio.Validate_AE_sec2_allelements_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,input_data,Checkbox_class_formats);
									context.setAttribute("fileName", "Validate_AE_sec2_allelements_in_l3_BC");
									driver.quit();break;
							
								case "Validate_AE_sec3_allelements_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_AE_sec3_allelements_in_l3_BC");
									ClubStudio.Validate_AE_sec3_allelements_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,input_data,Checkbox_class_formats);
									context.setAttribute("fileName", "Validate_AE_sec3_allelements_in_l3_BC");
									driver.quit();break;
								
									
								case "Validate_alert_nomorethan3_Emprs_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_alert_nomorethan3_Emprs_in_l3_BC");
									ClubStudio.Validate_alert_nomorethan3_Emprs_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,input_data,Checkbox_class_formats);
									context.setAttribute("fileName", "Validate_alert_nomorethan3_Emprs_in_l3_BC");
									driver.quit();break;

								
									
								case "Validate_Aerobic_cert_texts_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_Aerobic_cert_texts_in_l3_BC");
									ClubStudio.Validate_Aerobic_cert_texts_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, input_data );
									context.setAttribute("fileName", "Validate_Aerobic_cert_texts_in_l3_BC");
									driver.quit();break;
							
									
								case "Validate_Add_cert_btn_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_Add_cert_btn_in_l3_BC");
									ClubStudio.Validate_Add_cert_btn_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
									context.setAttribute("fileName", "Validate_Add_cert_btn_in_l3_BC");
									driver.quit();break;
									
								case "Validate_Aerobic_cert_all_fields_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_Aerobic_cert_all_fields_in_l3_BC");
									ClubStudio.Validate_Aerobic_cert_all_fields_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
									context.setAttribute("fileName", "Validate_Aerobic_cert_all_fields_in_l3_BC");
									driver.quit();break;
							
									
								case "Validate_Choosefile_and_cert_format_txt_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_Choosefile_and_cert_format_txt_in_l3_BC");
									ClubStudio.Validate_Choosefile_and_cert_format_txt_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, input_data );
									context.setAttribute("fileName", "Validate_Choosefile_and_cert_format_txt_in_l3_BC");
									driver.quit();break;
									
									
								case "Validate_add_emplr_remove_img_btn_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_add_emplr_remove_img_btn_in_l3_BC");
									ClubStudio.Validate_add_emplr_remove_img_btn_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Dropdown_values, Aerobics_Instructor_Exp_DD,input_data );
									context.setAttribute("fileName", "Validate_add_emplr_remove_img_btn_in_l3_BC");
									driver.quit();break;
									
									
								case "Validate_Aero_cert_remove_img_btn_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_Aero_cert_remove_img_btn_in_l3_BC");
									ClubStudio.Validate_Aero_cert_remove_img_btn_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, input_data );
									context.setAttribute("fileName", "Validate_Aero_cert_remove_img_btn_in_l3_BC");
									driver.quit();break;
									
									
								case "Validate_upload_cert_file_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_upload_cert_file_in_l3_BC");
									ClubStudio.Validate_upload_cert_file_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, input_data, File_name );
									context.setAttribute("fileName", "Validate_upload_cert_file_in_l3_BC");
									driver.quit();break;
											
									
									
								case "Validate_CertifiedIn_dd_all_values_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_CertifiedIn_dd_all_values_in_l3_BC");
									ClubStudio.Validate_CertifiedIn_dd_all_values_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, Certified_In_DD );
									context.setAttribute("fileName", "Validate_CertifiedIn_dd_all_values_in_l3_BC");
									driver.quit();break;
									
									
								case "Validate_CertifiedIn_select_desiredvalue_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_CertifiedIn_select_desiredvalue_in_l3_BC");
									ClubStudio.Validate_CertifiedIn_select_desiredvalue_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, Certified_In_DD );
									context.setAttribute("fileName", "Validate_CertifiedIn_select_desiredvalue_in_l3_BC");
									driver.quit();break;
									
									
								case "Validate_IssuedBy_DD_enabled_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_IssuedBy_DD_enabled_in_l3_BC");
									ClubStudio.Validate_IssuedBy_DD_enabled_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, Certified_In_DD );
									context.setAttribute("fileName", "Validate_IssuedBy_DD_enabled_in_l3_BC");
									driver.quit();break;
									
									
									
								case "Validate_IssuedBy_DD_disabled_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_IssuedBy_DD_disabled_in_l3_BC");
									ClubStudio.Validate_IssuedBy_DD_disabled_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, Certified_In_DD );
									context.setAttribute("fileName", "Validate_IssuedBy_DD_disabled_in_l3_BC");
									driver.quit();break;
									
									
								case "Validate_IssuedBy_dd_all_values_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_IssuedBy_dd_all_values_in_l3_BC");
									ClubStudio.Validate_IssuedBy_dd_all_values_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button, Certified_In_DD,Certification_IssuedByDPValues );
									context.setAttribute("fileName", "Validate_IssuedBy_dd_all_values_in_l3_BC");
									driver.quit();break;
									
									
								case "Validate_Input_in_Cert_no_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_Input_in_Cert_no_in_l3_BC");
									ClubStudio.Validate_Input_in_Cert_no_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button,  Certificate_No);
									context.setAttribute("fileName", "Validate_Input_in_Cert_no_in_l3_BC");
									driver.quit();break;
									
								case "Validate_filling_all_fields_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_filling_all_fields_in_l3_BC");
									ClubStudio.Validate_filling_all_fields_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
									context.setAttribute("fileName", "Validate_filling_all_fields_in_l3_BC");
									driver.quit();break;
									
									
								case "Validate_Aero_cert2_all_fields_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_Aero_cert2_all_fields_in_l3_BC");
									ClubStudio.Validate_Aero_cert2_all_fields_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
									context.setAttribute("fileName", "Validate_Aero_cert2_all_fields_in_l3_BC");
									driver.quit();break;
									
								case "Validate_Aero_cert3_all_fields_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_Aero_cert3_all_fields_in_l3_BC");
									ClubStudio.Validate_Aero_cert3_all_fields_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
									context.setAttribute("fileName", "Validate_Aero_cert3_all_fields_in_l3_BC");
									driver.quit();break;
									
								case "Validate_Aero_cert4_all_fields_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_Aero_cert4_all_fields_in_l3_BC");
									ClubStudio.Validate_Aero_cert4_all_fields_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
									context.setAttribute("fileName", "Validate_Aero_cert4_all_fields_in_l3_BC");
									driver.quit();break;
									
								case "Validate_alert_nomorethan_4_cert_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_alert_nomorethan_4_cert_in_l3_BC");
									ClubStudio.Validate_alert_nomorethan_4_cert_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Hold_cert_GT_AC_ratio_button );
									context.setAttribute("fileName", "Validate_alert_nomorethan_4_cert_in_l3_BC");
									driver.quit();break;
									
									
								case "Validate_removebtn_by_ip_in_cert_sec_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_removebtn_by_ip_in_cert_sec_in_l3_BC");
									ClubStudio.Validate_removebtn_by_ip_in_cert_sec_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name, input_data  );
									context.setAttribute("fileName", "Validate_removebtn_by_ip_in_cert_sec_in_l3_BC");
									driver.quit();break;
									
									
									
									
								case "Validate_removebtn_by_ip_addemployer_in_l3_BC":
									
									context.setAttribute("fileName", "Validate_removebtn_by_ip_addemployer_in_l3_BC");
									ClubStudio.Validate_removebtn_by_ip_addemployer_in_l3_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats  );
									context.setAttribute("fileName", "Validate_removebtn_by_ip_addemployer_in_l3_BC");
									driver.quit();break;
									
									
									
								case "Validate_emp_his_pre_emp_texts_in_l4_BC":
									
									context.setAttribute("fileName", "Validate_emp_his_pre_emp_texts_in_l4_BC");
									ClubStudio.Validate_emp_his_pre_emp_texts_in_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
									context.setAttribute("fileName", "Validate_emp_his_pre_emp_texts_in_l4_BC");
									driver.quit();break;
									
								case "Validate_radio_btns_of_emp_his_in_l4_BC":
									
									context.setAttribute("fileName", "Validate_radio_btns_of_emp_his_in_l4_BC");
									ClubStudio.Validate_radio_btns_of_emp_his_in_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
									context.setAttribute("fileName", "Validate_radio_btns_of_emp_his_in_l4_BC");
									driver.quit();break;
									
									
								case "Validate_upload_resume_chkbx_in_l4_BC":
									
									context.setAttribute("fileName", "Validate_upload_resume_chkbx_in_l4_BC");
									ClubStudio.Validate_upload_resume_chkbx_in_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
									context.setAttribute("fileName", "Validate_upload_resume_chkbx_in_l4_BC");
									driver.quit();break;
									
									
									
								case "Validate_upload_resume_sec_in_l4_BC":
									
									context.setAttribute("fileName", "Validate_upload_resume_sec_in_l4_BC");
									ClubStudio.Validate_upload_resume_sec_in_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name, input_data );
									context.setAttribute("fileName", "Validate_upload_resume_sec_in_l4_BC");
									driver.quit();break;
									
									
									
								case "Validate_upload_resumefile_l4_BC":
									
									context.setAttribute("fileName", "Validate_upload_resumefile_l4_BC");
									ClubStudio.Validate_upload_resumefile_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name, input_data );
									context.setAttribute("fileName", "Validate_upload_resumefile_l4_BC");
									driver.quit();break;
									
									
									
								case "Validate_current_previous_emp_texts_in_l4_BC":
									
									context.setAttribute("fileName", "Validate_current_previous_emp_texts_in_l4_BC");
									ClubStudio.Validate_current_previous_emp_texts_in_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name, input_data );
									context.setAttribute("fileName", "Validate_current_previous_emp_texts_in_l4_BC");
									driver.quit();break;
									
									
								case "Validate_all_input_fields_in_l4_BC":
									
									context.setAttribute("fileName", "Validate_all_input_fields_in_l4_BC");
									ClubStudio.Validate_all_input_fields_in_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
									context.setAttribute("fileName", "Validate_all_input_fields_in_l4_BC");
									driver.quit();break;
									
									
									
								case "Validate_ip_inallfields_in_l4_BC":
									
									context.setAttribute("fileName", "Validate_ip_inallfields_in_l4_BC");
									ClubStudio.Validate_ip_inallfields_in_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button);
									context.setAttribute("fileName", "Validate_ip_inallfields_in_l4_BC");
									driver.quit();break;
									
									
									
								case "Validate_prev_next_step_btns_in_l4_BC":
									
									context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4_BC");
									ClubStudio.Validate_prev_next_step_btns_in_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
									context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4_BC");
									driver.quit();break;
									
									
									
								case "Validate_add_emply_2_btn_in_l4_BC":
									
									context.setAttribute("fileName", "Validate_add_emply_2_btn_in_l4_BC");
									ClubStudio.Validate_add_emply_2_btn_in_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
									context.setAttribute("fileName", "Validate_add_emply_2_btn_in_l4_BC");
									driver.quit();break;
									
									
								case "Validate_Next_btn_in_l4_BC":
									
									context.setAttribute("fileName", "Validate_Next_btn_in_l4_BC");
									ClubStudio.Validate_Next_btn_in_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
									context.setAttribute("fileName", "Validate_Next_btn_in_l4_BC");
									driver.quit();break;
								
									
								case "Validate_No_Previous_Emp_RdoBtn_in_l4_BC":
									
									context.setAttribute("fileName", "Validate_No_Previous_Emp_RdoBtn_in_l4_BC");
									ClubStudio.Validate_No_Previous_Emp_RdoBtn_in_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
									context.setAttribute("fileName", "Validate_No_Previous_Emp_RdoBtn_in_l4_BC");
									driver.quit();break;
									
									
								case "Validate_prev_step_btn_in_l4_BC":
									
									context.setAttribute("fileName", "Validate_prev_step_btn_in_l4_BC");
									ClubStudio.Validate_prev_step_btn_in_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
									context.setAttribute("fileName", "Validate_prev_step_btn_in_l4_BC");
									driver.quit();break;
									
									
								case "Validate_all_ip_fieldsof_Addemplr2_in_l4_BC":
									
									context.setAttribute("fileName", "Validate_all_ip_fieldsof_Addemplr2_in_l4_BC");
									ClubStudio.Validate_all_ip_fieldsof_Addemplr2_in_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
									context.setAttribute("fileName", "Validate_all_ip_fieldsof_Addemplr2_in_l4_BC");
									driver.quit();break;
									
									
								case "Validate_all_ip_fieldsof_Addemplr3_in_l4_BC":
									
									context.setAttribute("fileName", "Validate_all_ip_fieldsof_Addemplr3_in_l4_BC");
									ClubStudio.Validate_all_ip_fieldsof_Addemplr3_in_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name );
									context.setAttribute("fileName", "Validate_all_ip_fieldsof_Addemplr3_in_l4_BC");
									driver.quit();break;
									
							
									
									
								case "Validate_removebtn2_by_ip_in_empr2_in_l4_BC":
									
									context.setAttribute("fileName", "Validate_removebtn2_by_ip_in_empr2_in_l4_BC");
									ClubStudio.Validate_removebtn2_by_ip_in_empr2_in_l4_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button);
									context.setAttribute("fileName", "Validate_removebtn2_by_ip_in_empr2_in_l4_BC");
									driver.quit();break;
									
								case "Validate_Indicate_languages_text_l5_BC":
									
									context.setAttribute("fileName", "Validate_Indicate_languages_text_l5_BC");
									ClubStudio.Validate_Indicate_languages_text_l5_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, input_data);
									context.setAttribute("fileName", "Validate_Indicate_languages_text_l5_BC");
									driver.quit();break;
									
								case "Validate_all_languages_in_l5_BC":
									
									context.setAttribute("fileName", "Validate_all_languages_in_l5_BC");
									ClubStudio.Validate_all_languages_in_l5_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
									context.setAttribute("fileName", "Validate_all_languages_in_l5_BC");
									driver.quit();break;
									
									
								case "Validate_bydefault_Eng_lang_isselected_in_l5_BC":
									
									context.setAttribute("fileName", "Validate_bydefault_Eng_lang_isselected_in_l5_BC");
									ClubStudio.Validate_bydefault_Eng_lang_isselected_in_l5_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
									context.setAttribute("fileName", "Validate_bydefault_Eng_lang_isselected_in_l5_BC");
									driver.quit();break;
									
								case "Validate_select_desired_langs_in_l5_BC":
									
									context.setAttribute("fileName", "Validate_select_desired_langs_in_l5_BC");
									ClubStudio.Validate_select_desired_langs_in_l5_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
									context.setAttribute("fileName", "Validate_select_desired_langs_in_l5_BC");
									driver.quit();break;
									
								case "Validate_prev_next_step_btns_in_l5_BC":
									
									context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5_BC");
									ClubStudio.Validate_prev_next_step_btns_in_l5_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
									context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5_BC");
									driver.quit();break;
									
								case "Validate_prev_step_btn_in_l5_BC":
									
									context.setAttribute("fileName", "Validate_prev_step_btn_in_l5_BC");
									ClubStudio.Validate_prev_step_btn_in_l5_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
									context.setAttribute("fileName", "Validate_prev_step_btn_in_l5_BC");
									driver.quit();break;
									
								case "Validate_Next_step_btn_in_l5_BC":
									
									context.setAttribute("fileName", "Validate_Next_step_btn_in_l5_BC");
									ClubStudio.Validate_Next_step_btn_in_l5_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
									context.setAttribute("fileName", "Validate_Next_step_btn_in_l5_BC");
									driver.quit();break;
									
							
								
								case "Validate_text_COqualify_in_l6_BC":
									
									context.setAttribute("fileName", "Validate_text_COqualify_in_l6_BC");
									ClubStudio.Validate_text_COqualify_in_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, input_data);
									context.setAttribute("fileName", "Validate_text_COqualify_in_l6_BC");
									driver.quit();break;
									
									
								case "Validate_all_fields_in_l6_BC":
									
									context.setAttribute("fileName", "Validate_all_fields_in_l6_BC");
									ClubStudio.Validate_all_fields_in_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Considered_for_chkbx);
									context.setAttribute("fileName", "Validate_all_fields_in_l6_BC");
									driver.quit();break;
									
									
									
								case "Validate_slt_Worktime_l6_BC":
									
									context.setAttribute("fileName", "Validate_slt_Worktime_l6_BC");
									ClubStudio.Validate_slt_Worktime_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Work_time);
									context.setAttribute("fileName", "Validate_slt_Worktime_l6_BC");
									driver.quit();break;
									
									
									
								case "Validate_slt_considerfor_chkbxs_l6_BC":
									
									context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6_BC");
									ClubStudio.Validate_slt_considerfor_chkbxs_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx);
									context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6_BC");
									driver.quit();break;
								
									
									
									
								case "Validate_deslt_considerfor_chkbxs_l6_BC":
									
									context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6_BC");
									ClubStudio.Validate_deslt_considerfor_chkbxs_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx);
									context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6_BC");
									driver.quit();break;
									
									
									
								case "Validate_COs_asperCFchkbxsltn_l6_BC":
									
									context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6_BC");
									ClubStudio.Validate_COs_asperCFchkbxsltn_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx);
									context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6_BC");
									driver.quit();break;
									
									
								case "Validate_COs_asperCFchkbxdesltn_l6_BC":
									
									context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6_BC");
									ClubStudio.Validate_COs_asperCFchkbxdesltn_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx, input_data);
									context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6_BC");
									driver.quit();break;
									
									
								case "Validate_defaultvalueofCO_l6_BC":
									
									context.setAttribute("fileName", "Validate_defaultvalueofCO_l6_BC");
									ClubStudio.Validate_defaultvalueofCO_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Considered_for_chkbx);
									context.setAttribute("fileName", "Validate_defaultvalueofCO_l6_BC");
									driver.quit();break;
									

									
								case "Validate_ip_date_to_begin_l6_BC":
									
									context.setAttribute("fileName", "Validate_ip_date_to_begin_l6_BC");
									ClubStudio.Validate_ip_date_to_begin_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, Date_to_begin);
									context.setAttribute("fileName", "Validate_ip_date_to_begin_l6_BC");
									driver.quit();break;
									
									
								case "Validate_empdwithus_no_rdobtn_l6_BC":
									
									context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6_BC");
									ClubStudio.Validate_empdwithus_no_rdobtn_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, input_data);
									context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6_BC");
									driver.quit();break;
									
									
								case "Validate_basedonsltns_text_l6_BC":
									
									context.setAttribute("fileName", "Validate_basedonsltns_text_l6_BC");
									ClubStudio.Validate_basedonsltns_text_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, input_data);
									context.setAttribute("fileName", "Validate_basedonsltns_text_l6_BC");
									driver.quit();break;
									
									
								case "Validate_Club_locations_l6_BC":
									
									context.setAttribute("fileName", "Validate_Club_locations_l6_BC");
									ClubStudio.Validate_Club_locations_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, input_data);
									context.setAttribute("fileName", "Validate_Club_locations_l6_BC");
									driver.quit();break;
									
								case "Validate_Rehire_Questionnaire_sec_l6_BC":
									
									context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l6_BC");
									ClubStudio.Validate_Rehire_Questionnaire_sec_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, input_data);
									context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l6_BC");
									driver.quit();break;
									
									
								case "Validate_Resigned_dd_allvalues_l6_BC":
									
									context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6_BC");
									ClubStudio.Validate_Resigned_dd_allvalues_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages, EmploymentHowResigned_dd);
									context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6_BC");
									driver.quit();break;
									
									
									
								case "Validate_ip_in_RQ_sec_l6_BC":
									
									context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6_BC");
									ClubStudio.Validate_ip_in_RQ_sec_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages , EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
									context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6_BC");
									driver.quit();break;
								
									
									
								case "Validate_prev_next_step_btns_l6_BC":
									
									context.setAttribute("fileName", "Validate_prev_next_step_btns_l6_BC");
									ClubStudio.Validate_prev_next_step_btns_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
									context.setAttribute("fileName", "Validate_prev_next_step_btns_l6_BC");
									driver.quit();break;
									
									
								case "Validate_prev_step_btn_in_l6_BC":
									
									context.setAttribute("fileName", "Validate_prev_step_btn_in_l6_BC");
									ClubStudio.Validate_prev_step_btn_in_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
									context.setAttribute("fileName", "Validate_prev_step_btn_in_l6_BC");
									driver.quit();break;
									
								case "Validate_next_btn_byipallfields_l6_BC":
									
									context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6_BC");
									ClubStudio.Validate_next_btn_byipallfields_l6_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
									context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6_BC");
									driver.quit();break;
									
									
									
								case "Validate_paras_in_l7_BC":
									
									context.setAttribute("fileName", "Validate_paras_in_l7_BC");
									ClubStudio.Validate_paras_in_l7_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, input_data);
									context.setAttribute("fileName", "Validate_paras_in_l7_BC");
									driver.quit();break;
									
									
									
								case "Validate_rdobtns_in_l7_BC":
									
									context.setAttribute("fileName", "Validate_rdobtns_in_l7_BC");
									ClubStudio.Validate_rdobtns_in_l7_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
									context.setAttribute("fileName", "Validate_rdobtns_in_l7_BC");
									driver.quit();break;
									
									
									
								case "Validate_all_form_sec_in_l7_BC":
									
									context.setAttribute("fileName", "Validate_all_form_sec_in_l7_BC");
									ClubStudio.Validate_all_form_sec_in_l7_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
									context.setAttribute("fileName", "Validate_all_form_sec_in_l7_BC");
									driver.quit();break;
									
									
									
								case "Validate_all_options_of_Gender_dd_in_l7_BC":
									
									context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_BC");
									ClubStudio.Validate_all_options_of_Gender_dd_in_l7_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,Gender_dd);
									context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_BC");
									driver.quit();break;
									
									
									
								case "Validate_all_options_of_RE_dd_in_l7_BC":
									
									context.setAttribute("fileName", "Validate_all_options_of_RE_dd_in_l7_BC");
									ClubStudio.Validate_all_options_of_RE_dd_in_l7_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,RaceEthnicity_dd);
									context.setAttribute("fileName", "Validate_all_options_of_RE_dd_in_l7_BC");
									driver.quit();break;
									
									
								case "Validate_EOE_details_paras_in_l7_BC":
									
									context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7_BC");
									ClubStudio.Validate_EOE_details_paras_in_l7_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,input_data);
									context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7_BC");
									driver.quit();break;
									
									
									
								case "Validate_No_rdobtnof_form_sec_in_l7_BC":
									
									context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7_BC");
									ClubStudio.Validate_No_rdobtnof_form_sec_in_l7_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
									context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7_BC");
									driver.quit();break;
									
									
								case "Validate_prev_next_step_btns_in_l7_BC":
									
									context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7_BC");
									ClubStudio.Validate_prev_next_step_btns_in_l7_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
									context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7_BC");
									driver.quit();break;
									
									
								case "Validate_prev_step_btn_in_l7_BC":
									
									context.setAttribute("fileName", "Validate_prev_step_btn_in_l7_BC");
									ClubStudio.Validate_prev_step_btn_in_l7_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
									context.setAttribute("fileName", "Validate_prev_step_btn_in_l7_BC");
									driver.quit();break;
									
									
								case "Validate_Next_step_btn_in_l7_BC":
									
									context.setAttribute("fileName", "Validate_Next_step_btn_in_l7_BC");
									ClubStudio.Validate_Next_step_btn_in_l7_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
									context.setAttribute("fileName", "Validate_Next_step_btn_in_l7_BC");
									driver.quit();break;
									
									
								case "Validate_Nav_to_l8_BC":
									
									context.setAttribute("fileName", "Validate_Nav_to_l8_BC");
									ClubStudio.Validate_Nav_to_l8_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
									context.setAttribute("fileName", "Validate_Nav_to_l8_BC");
									driver.quit();break;
								
									
									
								case "Validate_AS_paras_in_l8_BC":
									
									context.setAttribute("fileName", "Validate_AS_paras_in_l8_BC");
									ClubStudio.Validate_AS_paras_in_l8_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
									context.setAttribute("fileName", "Validate_AS_paras_in_l8_BC");
									driver.quit();break;
									
									
								case "Validate_ackmnt_in_l8_BC":
									
									context.setAttribute("fileName", "Validate_ackmnt_in_l8_BC");
									ClubStudio.Validate_ackmnt_in_l8_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
									context.setAttribute("fileName", "Validate_ackmnt_in_l8_BC");
									driver.quit();break;
									
									
								case "Validate_ip_in_Signedbyname_in_l8_BC":
									
									context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_BC");
									ClubStudio.Validate_ip_in_Signedbyname_in_l8_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
									context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_BC");
									driver.quit();break;
									
									
								case "Validate_prev_next_step_btns_in_l8_BC":
									
									context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8_BC");
									ClubStudio.Validate_prev_next_step_btns_in_l8_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
									context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8_BC");
									driver.quit();break;
									
									
								case "Validate_prev_step_btn_in_l8_BC":
									
									context.setAttribute("fileName", "Validate_prev_step_btn_in_l8_BC");
									ClubStudio.Validate_prev_step_btn_in_l8_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
									context.setAttribute("fileName", "Validate_prev_step_btn_in_l8_BC");
									driver.quit();break;
									
									
								case "Validate_Next_btn_in_l8_BC":
									
									context.setAttribute("fileName", "Validate_Next_btn_in_l8_BC");
									ClubStudio.Validate_Next_btn_in_l8_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
									context.setAttribute("fileName", "Validate_Next_btn_in_l8_BC");
									driver.quit();break;
									
									
								case "Validate_heading_in_l9_BC":
									
									context.setAttribute("fileName", "Validate_heading_in_l9_BC");
									ClubStudio.Validate_heading_in_l9_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
									context.setAttribute("fileName", "Validate_heading_in_l9_BC");
									driver.quit();break;
									
									
								case "Validate_Rules_procedures_in_l9_BC":
									
									context.setAttribute("fileName", "Validate_Rules_procedures_in_l9_BC");
									ClubStudio.Validate_Rules_procedures_in_l9_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
									context.setAttribute("fileName", "Validate_Rules_procedures_in_l9_BC");
									driver.quit();break;
									
									
								case "Validate_ip_in_prtname_dateandipadd_in_l9_BC":
									
									context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9_BC");
									ClubStudio.Validate_ip_in_prtname_dateandipadd_in_l9_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, IP_Address);
									context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9_BC");
									driver.quit();break;
									
									
									
									
								case "Validate_Robert_Bryant_Sign_in_l9_BC":
									
									context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_BC");
									ClubStudio.Validate_Robert_Bryant_Sign_in_l9_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
									context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_BC");
									driver.quit();break;
									
									
								case "Validate_Iagree_textandbtn_in_l9_BC":
									
									context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_BC");
									ClubStudio.Validate_Iagree_textandbtn_in_l9_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
									context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_BC");
									driver.quit();break;
									
									
								case "Validate_Prev_step_btn_in_l9_BC":
									
									context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9_BC");
									ClubStudio.Validate_Prev_step_btn_in_l9_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
									context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9_BC");
									driver.quit();break;
									
									
								case "Validate_Iagreebtn_and_succ_submsn_in_l9_BC":
									
									context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_BC");
									ClubStudio.Validate_Iagreebtn_and_succ_submsn_in_l9_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
									context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_BC");
									driver.quit();break;
									
									
									
								case "Validate_Success_msg_in_final_page_BC":
									
									context.setAttribute("fileName", "Validate_Success_msg_in_final_page_BC");
									ClubStudio.Validate_Success_msg_in_final_page_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
									context.setAttribute("fileName", "Validate_Success_msg_in_final_page_BC");
									driver.quit();break;
									
									
								case "Validate_prtbtn_in_print_emp_app_page_BC":
									
									context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page_BC");
									ClubStudio.Validate_prtbtn_in_print_emp_app_page_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd, input_data);
									context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page_BC");
									driver.quit();break;
									
									
									
								case "Validate_Rules_link_in_l9_BC":
									
									context.setAttribute("fileName", "Validate_Rules_link_in_l9_BC");
									ClubStudio.Validate_Rules_link_in_l9_BC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown ,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name , Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages,Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd,RaceEthnicity_dd);
									context.setAttribute("fileName", "Validate_Rules_link_in_l9_BC");
									driver.quit();break;
									
	
	

			
		
								
							
	//					*/
	
						
						
					default:
						driver.quit();
						break;
	
					}
					
					// EndTest
	//				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
					ExtentTestManager.getTest().log(Status.PASS, "*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
					ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
					ExtentTestManager.endTest();
					ExtentManager.getInstance().flush();
					Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
					Log.info("Browser is closed");
	
	
				}
	
			} 
			catch (Exception e)
			{
				Thread.sleep(1000);
				ExtentTestManager.getTest().log(Status.FAIL, "*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				Log.error("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				String stackTrace = Throwables.getStackTraceAsString(e);
				Log.error( stackTrace);
			
				
				String fileName = (String) context.getAttribute("fileName");
	
				try {
					File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
							testdata.get("TestScenario").toString());
					ExtentTestManager.getTest().fail(e.getMessage(),
							MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
					ExtentTestManager.getTest().log(Status.FAIL, e);
					} 
				catch (Exception e1) {
					System.out.println("File not found " + e1);
									}
				ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");
	
	//			 Logout
				context.setAttribute("fileName", "Logout");
				if (com.test.user.All_scenarios.driver!=null)driver.quit();
				ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
				Log.info("Browser is closed");
	
				// EndTest
				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
				ExtentTestManager.endTest();
				ExtentManager.getInstance().flush();
				Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
				throw new Exception(stackTrace);
			} 
			catch (AssertionError e) 
			{
				Thread.sleep(1000);
	//			System.out.println("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				ExtentTestManager.getTest().log(Status.FAIL, "*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				Log.error("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				String stackTrace = Throwables.getStackTraceAsString(e);
				Log.error( stackTrace);
				
				String fileName = (String) context.getAttribute("fileName");
	
				try {
					File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
							testdata.get("TestScenario").toString());
					ExtentTestManager.getTest().fail(e.getMessage(),
							MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
					ExtentTestManager.getTest().log(Status.FAIL, e);
					} 
				catch (Exception e1)
				{
					System.out.println("File not found " + e1);
				}
				ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");
	
				// Logout
				context.setAttribute("fileName", "Logout");
				driver.quit();
				ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
				Log.info("Browser is closed");
	
				// EndTest
				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
				ExtentTestManager.endTest();
				ExtentManager.getInstance().flush();
				Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
				
				throw new Exception(stackTrace);
				
			}
		}

		@DataProvider(name = "TestData")
		public static Object[][] gettestdate() throws IOException {
	
			Object[][] objectarry = null;
			java.util.List<Map<String, String>> completedata = com.Utility.ExcelReader.getdata("ClubStudio");
	
			java.util.List<Map<String, String>> completedata1 = new ArrayList<Map<String,String>>();
			int j=0;
	
			for (int i = 0; i < completedata.size(); i++) {
				if(completedata.get(i).get("Run").toString().equalsIgnoreCase("Yes")) 
				{
				completedata1.add(j, completedata.get(i));
				j++;
				}
			}
			
			objectarry = new Object[completedata1.size()][1];
			
			for (int i = 0; i < completedata1.size(); i++) {
				objectarry[i][0] = completedata1.get(i);
			}
			return objectarry;
	
		}
	
		public void Takescreenshot(String fileName, String scenario) {
			try {
				File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
						scenario);
				ExtentTestManager.getTest().pass("File upload screenshot",
						MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
				
				} 
			catch (Exception e1) {
				System.out.println("File not found " + e1);
								}
		}
		
		
	}



