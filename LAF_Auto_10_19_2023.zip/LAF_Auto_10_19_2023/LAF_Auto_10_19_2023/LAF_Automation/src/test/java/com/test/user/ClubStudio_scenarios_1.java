
	package com.test.user;
	
	import java.io.File;
	import java.io.IOException;
	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.List;
	import java.util.Map;
	import org.testng.ITestContext;
	import org.testng.annotations.AfterTest;
	import org.testng.annotations.BeforeSuite;
	import org.apache.commons.lang3.ObjectUtils.Null;
	import org.apache.poi.hssf.record.PageBreakRecord.Break;
	import org.testng.*;
	import org.testng.annotations.DataProvider;
	import org.testng.annotations.Test;
	import com.BasePackage.Base_Class;
	import com.Utility.Log;
	import com.aventstack.extentreports.MediaEntityBuilder;
	import com.aventstack.extentreports.Status;
	import com.extentReports.ExtentManager;
	import com.extentReports.ExtentTestManager;
	import com.google.common.base.Throwables;
	import com.listeners.TestListener;
	
	public class ClubStudio_scenarios_1 extends Base_Class  {
	
		Base_Class Base_Class;
		com.pages.Home Home;
		com.pages.Joinnow joinnow;
		Log log;
		TestListener TestListener;
		com.Utility.ScreenShot screenShot;
		com.pages.Employment Employment;
		com.pages.FreePass FreePass;
		com.pages.CareerOpportunity CareerOpportunity;
		com.pages.ClubStudio_1 ClubStudio_1;
		com.pages.ClubStudio ClubStudio;
		
		
		
		@BeforeSuite
		public void reference() {
			Base_Class = new Base_Class();
			log = new Log();
			TestListener = new TestListener();
			screenShot = new com.Utility.ScreenShot(null);
			Home = new com.pages.Home();
			joinnow = new com.pages.Joinnow();
			Employment = new com.pages.Employment();
			FreePass = new com.pages.FreePass();
			ClubStudio_1 = new com.pages.ClubStudio_1();
			ClubStudio = new com.pages.ClubStudio();
			CareerOpportunity = new com.pages.CareerOpportunity();
		}
		
		@Test(dataProvider = "TestData")
		public void RUNALL(Map<Object, Object> testdata, ITestContext context) throws Throwable {
	
			try {
	
				if (testdata.get("Run").toString().equalsIgnoreCase("Yes")) {
					String fileName;
					ExtentTestManager.startTest(testdata.get("TestScenario").toString());
					ExtentTestManager.getTest().log(Status.PASS, "*** Test Suite " + testdata.get("TestScenario").toString() + " running Starting ***");
					Log.info("*** Running test method " + testdata.get("TestScenario").toString() + "...");
					ExtentTestManager.getTest().log(Status.PASS, "*** Running test method " + testdata.get("TestScenario").toString() + "...");
				
					String Change_brand_name=testdata.get("Change_brand_name").toString();
					if(testdata.get("TextMessage").toString().trim().equalsIgnoreCase("Change_Brand".trim())) {
						
						Base_Class.setup_Change_brand();
						if(!Change_brand_name.isBlank() && !Change_brand_name.isEmpty()) Base_Class.Change_Brand(Change_brand_name);
						
					else {
						
						throw new Exception("please provide brand name to change the brand");
					
						}
						
					driver.quit();
						
					}
					
					else {
						Base_Class.setup();
					}
	
					
//					Base_Class.setup();
					ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered into Application URL ");
	
	
					String Dropdown_values=testdata.get("Dropdown_values").toString();
	
					String Country =testdata.get("Country").toString();
					String Ratesoramenities =testdata.get("Rates/amenities").toString();
					String Club_name =testdata.get("Club_name").toString();
					
					String Add_amenities =testdata.get("Add_amenities").toString();
					String Included_amenities =testdata.get("Included_amenities").toString();
				
					String Amount_details =testdata.get("Amount_details").toString();
					String rates_details =testdata.get("Rates_details").toString();
					String plan_rates =testdata.get("Plan_rates").toString();
					
					
					
					
					String Text_input =testdata.get("Text_input").toString();
		
					
					String Number_of_Persons1 =testdata.get("Number_of_Persons1").toString();
					String Initiation_Fee =testdata.get("Initiation_Fee").toString();
					String Billing_Frequency =testdata.get("Billing_Frequency").toString();				
					String Initial_Term =testdata.get("Initial_Term").toString();
					String Prepayment =testdata.get("Prepayment").toString();
					String First_Month_Dues =testdata.get("First_Month_Dues").toString();
					String Last_Month_Dues =testdata.get("Last_Month_Dues").toString();
					String Total_initial_Payment =testdata.get("Total_initial_Payment").toString();	
					String Annual_Fee_Per_Person =testdata.get("Annual_Fee_Per_Person").toString();
					
					String Everemployed_rdobtn =testdata.get("Everemployed_rdobtn").toString();
					String Date_to_begin =testdata.get("Date_to_begin").toString();
					String Languages =testdata.get("Languages").toString();
					String Work_time =testdata.get("Work_time").toString();
					String Url =testdata.get("Url").toString();
					String additional_input =testdata.get("additional_input").toString();
					String input_data =testdata.get("input_data").toString();
					String input_data1 =testdata.get("input_data1").toString();
					String input_data2 =testdata.get("input_data2").toString();
					String input_data3 =testdata.get("input_data3").toString();
					String input_data4 =testdata.get("input_data4").toString();
					String input_data5 =testdata.get("input_data5").toString();
					String input_data6 =testdata.get("input_data6").toString();
					String IP_Address =testdata.get("IP_Address").toString();
					
					String File_name =testdata.get("File_name").toString();
					
					String Job_short_des =testdata.get("Job_short_des").toString();
					String Job_long_des =testdata.get("Job_long_des").toString();
					String F_Name =testdata.get("F_Name").toString();
					String L_Name =testdata.get("L_Name").toString();
					String Full_name =testdata.get("Full_name").toString();
					String Phone =testdata.get("Member_Phone").toString();
					String Email =testdata.get("Email").toString();
					String Address =testdata.get("Member_address").toString();
	//				job_short_des
					String City =testdata.get("Member_City").toString();
					
					String E_EducationLeve_Dropdown = testdata.get("E_EducationLeve_Dropdown").toString();
	
					String Aerobics_Instructor_Exp_DD = testdata.get("Aerobics_Instructor_Exp_DD").toString();
					String Time_period_DD = testdata.get("Time_period_DD").toString();
					String Club_Employer_DD = testdata.get("Club_Employer_DD").toString();
					String Class_per_week = testdata.get("Class_per_week").toString();
					
					String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
					String PriorEmploymentWhyResigned_ip = testdata.get("PriorEmploymentWhyResigned_ip").toString();
					String EmploymentWhyLeaveCurrent_ip = testdata.get("EmploymentWhyLeaveCurrent_ip").toString();
					String EmploymentWhyReapply_ip = testdata.get("EmploymentWhyReapply_ip").toString();
					String EmploymentWhatLike_ip = testdata.get("EmploymentWhatLike_ip").toString();
					String EmploymentWhatDislike_ip = testdata.get("EmploymentWhatDislike_ip").toString();
					
					String EmploymentSuccess_ip = testdata.get("EmploymentSuccess_ip").toString();
					String EmploymentWhyResignInFuture_ip = testdata.get("EmploymentWhyResignInFuture_ip").toString();
					String Gender_dd = testdata.get("Gender_dd").toString();
					String RaceEthnicity_dd = testdata.get("RaceEthnicity_dd").toString();
	//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
	//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
	//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
	//				
					String Personal_Training_ExperienceDPValues = testdata.get("Personal_Training_ExperienceDPValues").toString();
					String Certification_IssuedByDPValues = testdata.get("Certification_IssuedByDPValues").toString();
					String Hold_cert_GT_AC_ratio_button = testdata.get("Hold_cert_GT_AC_ratio_button").toString();
					String Certified_In_DD = testdata.get("Certified_In_DD").toString();
					String Certificate_No = testdata.get("Certificate_No").toString();
					String Emp_gap = testdata.get("Emp_gap").toString();
					String Employer_name = testdata.get("Employer_name").toString();
					String Supervisor_name = testdata.get("Supervisor_name").toString();
					String From_date = testdata.get("From_date").toString();
					String To_date = testdata.get("To_date").toString();
					String Job_title = testdata.get("Job_title").toString();
					String Leaving_Reason = testdata.get("Leaving_Reason").toString();
					String Emp_details = testdata.get("Emp_details").toString();
					String Can_contact_radio_button = testdata.get("Can_contact_radio_button").toString();
					
					
					String Club_phone =testdata.get("Club_phone").toString();
					String Club_zip =testdata.get("Club_zip").toString();
					String Club_Address =testdata.get("Club_Address").toString();
					String Club_city =testdata.get("Club_city").toString();
	//				
					String State =testdata.get("State").toString();
					String Zipcode =testdata.get("Member_Zipcode").toString();
					String Radius_travel_to_work =testdata.get("Radius_travel_to_work").toString();
					String How_hear_abt_us =testdata.get("How_hear_abt_us").toString();
					String Radiobtn18YearsOld =testdata.get("Radiobtn18YearsOld").toString();
					String Payment_type =testdata.get("Payment_type").toString();
					String Card_number  =testdata.get("Card_number").toString();
					
					String Ex_month =testdata.get("Ex_month").toString();
					String Ex_year  =testdata.get("Ex_year").toString();
					
					String Routing_number  =testdata.get("Routing_number").toString();
					String Account_number =testdata.get("Account_number").toString();
					String Card_name =testdata.get("Card_name").toString();
					String Checkbox_class_formats =testdata.get("Checkbox_class_formats").toString();

					String No_Prev_emp_chk_box =testdata.get("No_Prev_emp_chk_box").toString();
				
					String Considered_for_chkbx =testdata.get("Considered_for_chkbx").toString();
						
					
					
					
							
					switch (testdata.get("TextMessage").toString()) {
					
						
					// Join Now Testcases
					

	case "CSF_Validate_Header_ClubStudio_1Fitness":
						
						context.setAttribute("fileName", "CSF_Validate_Header_ClubStudio_1Fitness");
						ClubStudio_1.TC_01_CSF_Validate_Header_ClubStudioFitness(testdata.get("TextMessage").toString(),Text_input);
						context.setAttribute("fileName", "CSF_Validate_Header_ClubStudio_1Fitness");
						driver.quit();break;


					case "CSF_Validate_Btn_Career":
						
						context.setAttribute("fileName", "CSF_Validate_Btn_Career");
						ClubStudio_1.TC_02_CSF_Validate_Btn_Career(testdata.get("TextMessage").toString(),Text_input);
						context.setAttribute("fileName", "CSF_Validate_Btn_Career");
						driver.quit();break;

					case "CSF_Validate_Text_ClubStudio_1Fitness_OnClickofCareers":
						
						context.setAttribute("fileName", "CSF_Validate_Text_ClubStudio_1Fitness_OnClickofCareers");
						ClubStudio_1.TC_03_CSF_Validate_Text_ClubStudioFitness_OnClickofCareers(testdata.get("TextMessage").toString(),Text_input);
						context.setAttribute("fileName", "CSF_Validate_Text_ClubStudio_1Fitness_OnClickofCareers");
						driver.quit();break;
	
					case "CSF_Validate_Text_CareerOpportunity_OnVipListPage":
						
						context.setAttribute("fileName", "CSF_Validate_Text_CareerOpportunity_OnVipListPage");
						ClubStudio_1.TC_04_CSF_Validate_Text_CareerOpportunity_OnVipListPage(testdata.get("TextMessage").toString(),Text_input);
						context.setAttribute("fileName", "CSF_Validate_Text_CareerOpportunity_OnVipListPage");
						driver.quit();break;
	
						
						
					case "CSF_Validate_Text_Wantojoinfull_OnVipListPage":
						
						context.setAttribute("fileName", "CSF_Validate_Text_Wantojoinfull_OnVipListPage");
						ClubStudio_1.TC_05_CSF_Validate_Text_Wantojoinfull_OnVipListPage(testdata.get("TextMessage").toString(),Text_input);
						context.setAttribute("fileName", "CSF_Validate_Text_Wantojoinfull_OnVipListPage");
						driver.quit();break;
	
					case "CSF_Validate_Text_SweatInstructor_OnVipListPage":
						
						context.setAttribute("fileName", "CSF_Validate_Text_SweatInstructor_OnVipListPage");
						ClubStudio_1.TC_06_CSF_Validate_Text_SweatInstructor_OnVipListPage(testdata.get("TextMessage").toString(),Text_input);
						context.setAttribute("fileName", "CSF_Validate_Text_SweatInstructor_OnVipListPage");
						driver.quit();break;
		
					case "CSF_Validate_Btn_MoreInfo_SweatInstructor":
						
						context.setAttribute("fileName", "CSF_Validate_Btn_MoreInfo_SweatInstructor");
						ClubStudio_1.TC_07_CSF_Validate_Btn_MoreInfo_SweatInstructor(testdata.get("TextMessage").toString(),Text_input);
						context.setAttribute("fileName", "CSF_Validate_Btn_MoreInfo_SweatInstructor");
						driver.quit();break;
		
					case "CSF_Validate_popupSweatInstructor_onClickofMoreInfo":
						
						context.setAttribute("fileName", "CSF_Validate_popupSweatInstructor_onClickofMoreInfo");
						ClubStudio_1.TC_08_CSF_Validate_popupSweatInstructor_onClickofMoreInfo(testdata.get("TextMessage").toString(),Text_input);
						context.setAttribute("fileName", "CSF_Validate_popupSweatInstructor_onClickofMoreInfo");
						driver.quit();
						break;
		
					case "CSF_Validate_onClickonApplyHere_SweatInst":
						
						context.setAttribute("fileName", "CSF_Validate_onClickonApplyHere_SweatInst");
						ClubStudio_1.TC_09_CSF_Validate_onClickonApplyHere_SweatInst(testdata.get("TextMessage").toString(),Text_input);
						context.setAttribute("fileName", "CSF_Validate_onClickonApplyHere_SweatInst");
						driver.quit();
						break;
			
					case "CSF_Validate_text_EmploymentApplication_EA":
						
						context.setAttribute("fileName", "CSF_Validate_text_EmploymentApplication_EA");
						ClubStudio_1.TC_10_CSF_Validate_text_EmploymentApplication_EA(testdata.get("TextMessage").toString(),Text_input);
						context.setAttribute("fileName", "CSF_Validate_text_EmploymentApplication_EA");
						driver.quit();
						break;
				
					case "CSF_Validate_Text_Below_EmploymentApp_EA":
						
						context.setAttribute("fileName", "CSF_Validate_Text_Below_EmploymentApp_EA");
						ClubStudio_1.TC_11_CSF_Validate_Text_Below_EmploymentApp_EA(testdata.get("TextMessage").toString(),Text_input);
						context.setAttribute("fileName", "CSF_Validate_Text_Below_EmploymentApp_EA");
						driver.quit();
						break;
						
					case "CSF_Validate_Text_AppInfo_ContandLocInfo_EA":
						
						context.setAttribute("fileName", "CSF_Validate_Text_AppInfo_ContandLocInfo_EA");
						ClubStudio_1.TC_12_CSF_Validate_Text_AppInfo_ContandLocInfo_EA(testdata.get("TextMessage").toString(),Text_input);
						context.setAttribute("fileName", "CSF_Validate_Text_AppInfo_ContandLocInfo_EA");
						driver.quit();
						break;
				
					case "Validate_mandatoryFields_EA":
						
						context.setAttribute("fileName", "Validate_mandatoryFields_EA");
						ClubStudio_1.TC_13_CSF_Validate_mandatoryFields_EA(testdata.get("TextMessage").toString(),Text_input);
						context.setAttribute("fileName", "Validate_mandatoryFields_EA");
						driver.quit();
						break;
						
					case "CSF_Validate_Dropdownvalues_HowDidUhearUs_EA":
						
						context.setAttribute("fileName", "CSF_Validate_Dropdownvalues_HowDidUhearUs_EA");
						ClubStudio_1.TC_14_CSF_Validate_Dropdownvalues_HowDidUhearUs_EA(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
						context.setAttribute("fileName", "CSF_Validate_Dropdownvalues_HowDidUhearUs_EA");
						driver.quit();
						break;
						
					case "CSF_Validate_Radiobutton_RU18_EA":
						
						context.setAttribute("fileName", "CSF_Validate_Radiobutton_RU18_EA");
						ClubStudio_1.TC_15_CSF_Validate_Radiobutton_RU18_EA(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
						context.setAttribute("fileName", "CSF_Validate_Radiobutton_RU18_EA");
						driver.quit();
						break;
						
					case "CSF_validate_Text_FormatUSCanada_EA":
						
						context.setAttribute("fileName", "CSF_validate_Text_FormatUSCanada_EA");
						ClubStudio_1.TC_16_CSF_validate_Text_FormatUSCanada_EA(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
						context.setAttribute("fileName", "CSF_validate_Text_FormatUSCanada_EA");
						driver.quit();
						break;
						
					case "CSF_validate_Text_Miles_EA":
						
						context.setAttribute("fileName", "CSF_validate_Text_Miles_EA");
						ClubStudio_1.TC_17_CSF_validate_Text_Miles_EA(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
						context.setAttribute("fileName", "CSF_validate_Text_Miles_EA");
						driver.quit();
						break;
					
					case "CSF_Validate_ErrorMsg_CellPhone_EA":
						
						context.setAttribute("fileName", "CSF_Validate_ErrorMsg_CellPhone_EA");
						ClubStudio_1.TC_18_CSF_Validate_ErrorMsg_CellPhone_EA(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
						context.setAttribute("fileName", "CSF_Validate_ErrorMsg_CellPhone_EA");
						driver.quit();
						break;
					
					case "CSF_Validate_Field_Input_EA":
						
						context.setAttribute("fileName", "CSF_Validate_Field_Input_EA");
						ClubStudio_1.TC_19_CSF_Validate_Field_Input_EA(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode);
						context.setAttribute("fileName", "CSF_Validate_Field_Input_EA");
						driver.quit();
						break;
					
case "CSF_Validate_Button_NextStep_EA":
						
						context.setAttribute("fileName", "CSF_Validate_Button_NextStep_EA");
						ClubStudio_1.TC_20_CSF_Validate_Button_NextStep_EA(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode);
						context.setAttribute("fileName", "CSF_Validate_Button_NextStep_EA");
						driver.quit();
						break;
						
case "CSF_Validate_url_CSF":
	
	context.setAttribute("fileName", "CSF_Validate_url_CSF");
	ClubStudio_1.TC_21_CSF_Validate_url_CSF(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
	context.setAttribute("fileName", "CSF_Validate_url_CSF");
	driver.quit();
	break;


case "CSF_Verify_YouMustBe18Years_popup_OnselectingRaiodNo":
	
	context.setAttribute("fileName", "CSF_Verify_YouMustBe18Years_popup_OnselectingRaiodNo");
	ClubStudio_1.TC_22_CSF_Verify_YouMustBe18Years_popup_OnselectingRaiodNo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
	context.setAttribute("fileName", "CSF_Verify_YouMustBe18Years_popup_OnselectingRaiodNo");
	driver.quit();
	break;

	
case "CSF_Validate_ClubsinurRadius":
	
	context.setAttribute("fileName", "CSF_Validate_ClubsinurRadius");
	ClubStudio_1.TC_23_CSF_Validate_ClubsinurRadius(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
	context.setAttribute("fileName", "CSF_Validate_ClubsinurRadius");
	driver.quit();
	break;

case "CSF_Validate_Nextbutton_ClickofApplicantinfo":
	
	context.setAttribute("fileName", "CSF_Validate_Nextbutton_ClickofApplicantinfo");
	ClubStudio_1.TC_24_CSF_Validate_Nextbutton_ClickofApplicantinfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode);
	context.setAttribute("fileName", "CSF_Validate_Nextbutton_ClickofApplicantinfo");
	driver.quit();
	break;
	
case "CSF_Validate_Text_EducationInfo":
	
	context.setAttribute("fileName", "CSF_Validate_Text_EducationInfo");
	ClubStudio_1.TC_25_CSF_Validate_Text_EducationInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
	context.setAttribute("fileName", "CSF_Validate_Text_EducationInfo");
	driver.quit();
	break;
	
case "CSF_Validate_Field_EducationLevel":
	
	context.setAttribute("fileName", "CSF_Validate_Field_EducationLevel");
	ClubStudio_1.TC_26_CSF_Validate_Field_EducationLevel(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
	context.setAttribute("fileName", "CSF_Validate_Field_EducationLevel");
	driver.quit();
	break;

	
case "CSF_Validate_DropdownValues_EducationLevel":
	
	context.setAttribute("fileName", "CSF_Validate_DropdownValues_EducationLevel");
	ClubStudio_1.TC_27_CSF_Validate_DropdownValues_EducationLevel(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSF_Validate_DropdownValues_EducationLevel");
	driver.quit();
	break;

case "CSF_Validate_EducationLevel_ButtonsPerviousNext":
	
	context.setAttribute("fileName", "CSF_Validate_EducationLevel_ButtonsPerviousNext");
	ClubStudio_1.TC_28_CSF_Validate_EducationLevel_ButtonsPerviousNext(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSF_Validate_EducationLevel_ButtonsPerviousNext");
	driver.quit();
	break;

	
case "CSF_Validate_PreviousPage_ClickofELPreviousbutton":
	
	context.setAttribute("fileName", "CSF_Validate_PreviousPage_ClickofELPreviousbutton");
	ClubStudio_1.TC_29_CSF_Validate_PreviousPage_ClickofELPreviousbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSF_Validate_PreviousPage_ClickofELPreviousbutton");
	driver.quit();
	break;

case "CSF_Validate_NextPage_ClickofELNextbutton":
	
	context.setAttribute("fileName", "CSF_Validate_NextPage_ClickofELNextbutton");
	ClubStudio_1.TC_30_CSF_Validate_NextPage_ClickofELNextbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input, E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSF_Validate_NextPage_ClickofELNextbutton");
	driver.quit();
	break;
	

case "CSF_Validate_EducationInfo_ClickofNextbutton":
	
	context.setAttribute("fileName", "CSF_Validate_EducationInfo_ClickofNextbutton");
	ClubStudio_1.TC_31_CSF_Validate_EducationInfo_ClickofNextbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSF_Validate_EducationInfo_ClickofNextbutton");
	driver.quit();
	break;
	
case "CSF_Validate_Text_ExperienceDetail_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_Text_ExperienceDetail_ExperienceInfo");
	ClubStudio_1.TC_32_CSF_Validate_Text_ExperienceDetail_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSF_Validate_Text_ExperienceDetail_ExperienceInfo");
	driver.quit();
	break;
					
case "CSF_Validate_Text_GroupFitnessAero_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_Text_GroupFitnessAero_ExperienceInfo");
	ClubStudio_1.TC_33_CSF_Validate_Text_GroupFitnessAero_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSF_Validate_Text_GroupFitnessAero_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_Fields_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_Fields_ExperienceInfo");
	ClubStudio_1.TC_34_CSF_Validate_Fields_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSF_Validate_Fields_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_DDValues_GroupFitnessAero_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_DDValues_GroupFitnessAero_ExperienceInfo");
	ClubStudio_1.TC_35_CSF_Validate_DDValues_GroupFitnessAero_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSF_Validate_DDValues_GroupFitnessAero_ExperienceInfo");
	driver.quit();
	break;
							
case "CSF_Validate_RadioBtn_DoUcurrentlyHold_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_RadioBtn_DoUcurrentlyHold_ExperienceInfo");
	ClubStudio_1.TC_36_CSF_Validate_RadioBtn_DoUcurrentlyHold_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSF_Validate_RadioBtn_DoUcurrentlyHold_ExperienceInfo");
	driver.quit();
	break;

case "CSF_Validate_Link_GroupFitness_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_Link_GroupFitness_ExperienceInfo");
	ClubStudio_1.TC_37_CSF_Validate_Link_GroupFitness_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSF_Validate_Link_GroupFitness_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_Text_AerobicCertif_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_Text_AerobicCertif_ExperienceInfo");
	ClubStudio_1.TC_38_CSF_Validate_Text_AerobicCertif_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSF_Validate_Text_AerobicCertif_ExperienceInfo");
	driver.quit();
	break;
	
	
case "CSF_Validate_Btn_AddCertificate_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_Btn_AddCertificate_ExperienceInfo");
	ClubStudio_1.TC_39_CSF_Validate_Btn_AddCertificate_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSF_Validate_Btn_AddCertificate_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_Fields_OnclickOfYesradio_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_Fields_OnclickOfYesradio_ExperienceInfo");
	ClubStudio_1.TC_40_CSF_Validate_Fields_OnclickOfYesradio_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSF_Validate_Fields_OnclickOfYesradio_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_DDValues_CertifiedIn_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_DDValues_CertifiedIn_ExperienceInfo");
	ClubStudio_1.TC_41_CSF_Validate_DDValues_CertifiedIn_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD);
	context.setAttribute("fileName", "CSF_Validate_DDValues_CertifiedIn_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_DDValues_IssedBy_OnSelecting_Aqua_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_DDValues_IssedBy_OnSelecting_Aqua_ExperienceInfo");
	ClubStudio_1.TC_42_CSF_Validate_DDValues_IssedBy_OnSelecting_Aqua_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_DDValues_IssedBy_OnSelecting_Aqua_ExperienceInfo");
	driver.quit();
	break;

case "CSF_Validate_DDValues_IssedBy_OnSelecting_Cycle_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_DDValues_IssedBy_OnSelecting_Cycle_ExperienceInfo");
	ClubStudio_1.TC_43_CSF_Validate_DDValues_IssedBy_OnSelecting_Cycle_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_DDValues_IssedBy_OnSelecting_Cycle_ExperienceInfo");
	driver.quit();
	break;

case "CSF_Validate_DDValues_IssedBy_OnSelecting_Dance_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_DDValues_IssedBy_OnSelecting_Dance_ExperienceInfo");
	ClubStudio_1.TC_44_CSF_Validate_DDValues_IssedBy_OnSelecting_Dance_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_DDValues_IssedBy_OnSelecting_Dance_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_DDValues_IssedBy_OnSelecting_GroupFitness_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_DDValues_IssedBy_OnSelecting_GroupFitness_ExperienceInfo");
	ClubStudio_1.TC_45_CSF_Validate_DDValues_IssedBy_OnSelecting_GroupFitness_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_DDValues_IssedBy_OnSelecting_GroupFitness_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_DDValues_IssedBy_OnSelecting_Kickboxing_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_DDValues_IssedBy_OnSelecting_Kickboxing_ExperienceInfo");
	ClubStudio_1.TC_46_CSF_Validate_DDValues_IssedBy_OnSelecting_Kickboxing_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_DDValues_IssedBy_OnSelecting_Kickboxing_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_DDValues_IssedBy_OnSelecting_MatPilatesBy_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_DDValues_IssedBy_OnSelecting_MatPilatesBy_ExperienceInfo");
	ClubStudio_1.TC_47_CSF_Validate_DDValues_IssedBy_OnSelecting_MatPilatesBy_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_DDValues_IssedBy_OnSelecting_MatPilatesBy_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_DDValues_IssedBy_OnSelecting_Yoga_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_DDValues_IssedBy_OnSelecting_Yoga_ExperienceInfo");
	ClubStudio_1.TC_48_CSF_Validate_DDValues_IssedBy_OnSelecting_Yoga_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_DDValues_IssedBy_OnSelecting_Yoga_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_Text_CertificateFiles_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_Text_CertificateFiles_ExperienceInfo");
	ClubStudio_1.TC_49_CSF_Validate_Text_CertificateFiles_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_Text_CertificateFiles_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_Btn_ChooseFile_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_Btn_ChooseFile_ExperienceInfo");
	ClubStudio_1.TC_50_CSF_Validate_Btn_ChooseFile_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_Btn_ChooseFile_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_FieldInputs_OnClickOfYes_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_FieldInputs_OnClickOfYes_ExperienceInfo");
	ClubStudio_1.TC_51_CSF_Validate_FieldInputs_OnClickOfYes_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_FieldInputs_OnClickOfYes_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_OnClickOfAddCertificate_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_OnClickOfAddCertificate_ExperienceInfo");
	ClubStudio_1.TC_52_CSF_Validate_OnClickOfAddCertificate_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_OnClickOfAddCertificate_ExperienceInfo");
	driver.quit();
	break;
	
	
case "CSF_Validate_OnClickOfRemove_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_OnClickOfRemove_ExperienceInfo");
	ClubStudio_1.TC_53_CSF_Validate_OnClickOfRemove_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_OnClickOfRemove_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_PopUp_NoMorethen4_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_PopUp_NoMorethen4_ExperienceInfo");
	ClubStudio_1.TC_54_CSF_Validate_PopUp_NoMorethen4_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_PopUp_NoMorethen4_ExperienceInfo");
	driver.quit();
	break;
	
case "CSF_Validate_text_GroupFitnessAero_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSF_Validate_text_GroupFitnessAero_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_55_CSF_Validate_text_GroupFitnessAero_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_text_GroupFitnessAero_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSF_Validate_text_PlzIdentify_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSF_Validate_text_PlzIdentify_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_56_CSF_Validate_text_PlzIdentify_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_text_PlzIdentify_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSF_Validate_Fields_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSF_Validate_Fields_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_57_CSF_Validate_Fields_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_Fields_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSF_Validate_DDV_OfTimeperiod_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSF_Validate_DDV_OfTimeperiod_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_58_CSF_Validate_DDV_OfTimeperiod_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD);
	context.setAttribute("fileName", "CSF_Validate_DDV_OfTimeperiod_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSF_Validate_DDV_OfClubEMp_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSF_Validate_DDV_OfClubEMp_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_59_CSF_Validate_DDV_OfClubEMp_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD);
	context.setAttribute("fileName", "CSF_Validate_DDV_OfClubEMp_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
	
case "CSF_Validate_FieldInput_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSF_Validate_FieldInput_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_60_CSF_Validate_FieldInput_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD,Class_per_week);
	context.setAttribute("fileName", "CSF_Validate_FieldInput_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSF_Validate_CB_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSF_Validate_CB_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_61_CSF_Validate_CB_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD,Class_per_week);
	context.setAttribute("fileName", "CSF_Validate_CB_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSF_Validate_CheckofCB_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSF_Validate_CheckofCB_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_62_CSF_Validate_CheckofCB_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD,Class_per_week);
	context.setAttribute("fileName", "CSF_Validate_CheckofCB_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSF_Validate_text_ClassFormat_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSF_Validate_text_ClassFormat_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_63_CSF_Validate_text_ClassFormat_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD,Class_per_week);
	context.setAttribute("fileName", "CSF_Validate_text_ClassFormat_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSF_Validate_newaddemplsection_onClickofAddEmpBtn_ExpInfo":
	
	context.setAttribute("fileName", "CSF_Validate_newaddemplsection_onClickofAddEmpBtn_ExpInfo");
	ClubStudio_1.TC_64_CSF_Validate_newaddemplsection_onClickofAddEmpBtn_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD,Class_per_week);
	context.setAttribute("fileName", "CSF_Validate_newaddemplsection_onClickofAddEmpBtn_ExpInfo");
	driver.quit();
	break;
	
case "CSF_Validate_RemovalofAddEmpsectio_onClickofRemoveBtn_ExpInfo":
	
	context.setAttribute("fileName", "CSF_Validate_RemovalofAddEmpsectio_onClickofRemoveBtn_ExpInfo");
	ClubStudio_1.TC_65_CSF_Validate_RemovalofAddEmpsectio_onClickofRemoveBtn_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD,Class_per_week);
	context.setAttribute("fileName", "CSF_Validate_RemovalofAddEmpsectio_onClickofRemoveBtn_ExpInfo");
	driver.quit();
	break;
	
case "CSF_Validate_Popup_Nomorethan3Employers_ExpInfo":
	
	context.setAttribute("fileName", "CSF_Validate_Popup_Nomorethan3Employers_ExpInfo");
	ClubStudio_1.TC_66_CSF_Validate_Popup_Nomorethan3Employers_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD,Class_per_week);
	context.setAttribute("fileName", "CSF_Validate_Popup_Nomorethan3Employers_ExpInfo");
	driver.quit();
	break;
	
		
	
	
case "CSF_Validate_Text_EducationInformation_OnClickoFPrevStepbtn_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_Text_EducationInformation_OnClickoFPrevStepbtn_ExperienceInfo");
	ClubStudio_1.TC_67_CSF_Validate_Text_EducationInformation_OnClickoFPrevStepbtn_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_Text_EducationInformation_OnClickoFPrevStepbtn_ExperienceInfo");
	driver.quit();
	break;


case "CSF_Validate_OnClickoFNextStepbtn_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_OnClickoFNextStepbtn_ExperienceInfo");
	ClubStudio_1.TC_68_CSF_Validate_OnClickoFNextStepbtn_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_OnClickoFNextStepbtn_ExperienceInfo");
	driver.quit();
	break;	

	
case "CSF_Validate_Text_EmploymentHistory_OnClickoFNextStepbtn_ExperienceInfo":
	
	context.setAttribute("fileName", "CSF_Validate_Text_EmploymentHistory_OnClickoFNextStepbtn_ExperienceInfo");
	ClubStudio_1.TC_69_CSF_Validate_Text_EmploymentHistory_OnClickoFNextStepbtn_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_Text_EmploymentHistory_OnClickoFNextStepbtn_ExperienceInfo");
	driver.quit();
	break;

case "CSF_Validate_Text_PreviousEmployment_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Text_PreviousEmployment_EmploymentHistory");
	ClubStudio_1.TC_70_CSF_Validate_Text_PreviousEmployment_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_Text_PreviousEmployment_EmploymentHistory");
	driver.quit();
	break;
	
case "CSF_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory");
	ClubStudio_1.TC_71_CSF_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory");
	driver.quit();
	break;
	
case "CSF_Validate_Field_EmploymentGapExp_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Field_EmploymentGapExp_EmploymentHistory");
	ClubStudio_1.TC_72_CSF_Validate_Field_EmploymentGapExp_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_Field_EmploymentGapExp_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSF_Validate_Field_IWillUploadMyResume_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Field_IWillUploadMyResume_EmploymentHistory");
	ClubStudio_1.TC_73_CSF_Validate_Field_IWillUploadMyResume_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_Field_IWillUploadMyResume_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSF_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory");
	ClubStudio_1.TC_74_CSF_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory");
	driver.quit();
	break;
	
case "CSF_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory");
	ClubStudio_1.TC_75_CSF_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory");
	driver.quit();
	break;
	
case "CSF_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory");
	ClubStudio_1.TC_76_CSF_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory");
	driver.quit();
	break;
	
case "CSF_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory");
	ClubStudio_1.TC_77_CSF_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSF_Validate_Text_EnterEmpHistory_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Text_EnterEmpHistory_EmploymentHistory");
	ClubStudio_1.TC_78_CSF_Validate_Text_EnterEmpHistory_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_Text_EnterEmpHistory_EmploymentHistory");
	driver.quit();
	break;
	
case "CSF_Validate_Text_PreviousEmployer1_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Text_PreviousEmployer1_EmploymentHistory");
	ClubStudio_1.TC_79_CSF_Validate_Text_PreviousEmployer1_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_Text_PreviousEmployer1_EmploymentHistory");
	driver.quit();
	break;
	
case "CSF_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory");
	ClubStudio_1.TC_80_CSF_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSF_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSF_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory");
	ClubStudio_1.TC_81_CSF_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory");
	driver.quit();
	break;
	
case "CSF_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory");
	ClubStudio_1.TC_82_CSF_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory");
	driver.quit();
	break;
	
case "CSF_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory");
	ClubStudio_1.TC_83_CSF_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSF_Validate_RadioOptions_CanbeContacted_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_RadioOptions_CanbeContacted_EmploymentHistory");
	ClubStudio_1.TC_84_CSF_Validate_RadioOptions_CanbeContacted_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_RadioOptions_CanbeContacted_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSF_Validate_Btn_AddEmployer2_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Btn_AddEmployer2_EmploymentHistory");
	ClubStudio_1.TC_85_CSF_Validate_Btn_AddEmployer2_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Btn_AddEmployer2_EmploymentHistory");
	driver.quit();
	break;
	
case "CSF_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory");
	ClubStudio_1.TC_86_CSF_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory");
	driver.quit();
	break;
	
case "CSF_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory");
	ClubStudio_1.TC_87_CSF_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory");
	driver.quit();
	break;
	
case "CSF_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory");
	ClubStudio_1.TC_88_CSF_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory");
	driver.quit();
	break;
	
case "CSF_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory");
	ClubStudio_1.TC_89_CSF_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSF_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory");
	ClubStudio_1.TC_90_CSF_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory");
	driver.quit();
	break;
	
case "CSF_Validate_OnClick_RemoveEmp3_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_OnClick_RemoveEmp3_EmploymentHistory");
	ClubStudio_1.TC_91_CSF_Validate_OnClick_RemoveEmp3_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_OnClick_RemoveEmp3_EmploymentHistory");
	driver.quit();
	break;
	

case "CSF_Validate_OnClick_RemoveEmp2_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_OnClick_RemoveEmp2_EmploymentHistory");
	ClubStudio_1.TC_92_CSF_Validate_OnClick_RemoveEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_OnClick_RemoveEmp2_EmploymentHistory");
	driver.quit();
	break;
	
case "CSF_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory");
	ClubStudio_1.TC_93_CSF_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSF_Validate_onClickNextbtn_EmploymentHistory":
	
	context.setAttribute("fileName", "CSF_Validate_onClickNextbtn_EmploymentHistory");
	ClubStudio_1.TC_94_CSF_Validate_onClickNextbtn_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_onClickNextbtn_EmploymentHistory");
	driver.quit();
	break;

case "CSF_Validate_Text_LanguageSkills_LanguageSkills":
	
	context.setAttribute("fileName", "CSF_Validate_Text_LanguageSkills_LanguageSkills");
	ClubStudio_1.TC_95_CSF_Validate_Text_LanguageSkills_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Text_LanguageSkills_LanguageSkills");
	driver.quit();
	break;

case "CSF_Validate_Text_IncicateLang_LanguageSkills":
	
	context.setAttribute("fileName", "CSF_Validate_Text_IncicateLang_LanguageSkills");
	ClubStudio_1.TC_96_CSF_Validate_Text_IncicateLang_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Text_IncicateLang_LanguageSkills");
	driver.quit();
	break;
	
	
case "CSF_Validate_Languages_LanguageSkills":
	
	context.setAttribute("fileName", "CSF_Validate_Languages_LanguageSkills");
	ClubStudio_1.TC_97_CSF_Validate_Languages_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Languages_LanguageSkills");
	driver.quit();
	break;
	
case "CSF_Validate_OnClickPrvBtn_LanguageSkills":
	
	context.setAttribute("fileName", "CSF_Validate_OnClickPrvBtn_LanguageSkills");
	ClubStudio_1.TC_98_CSF_Validate_OnClickPrvBtn_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_OnClickPrvBtn_LanguageSkills");
	driver.quit();
	break;
	
case "CSF_Validate_OnClickNextBtn_LanguageSkills":
	
	context.setAttribute("fileName", "CSF_Validate_OnClickNextBtn_LanguageSkills");
	ClubStudio_1.TC_99_CSF_Validate_OnClickNextBtn_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_OnClickNextBtn_LanguageSkills");
	driver.quit();
	break;
	
case "CSF_Validate_Text_CareerOptions_CareerOption":
	
	context.setAttribute("fileName", "CSF_Validate_Text_CareerOptions_CareerOption");
	ClubStudio_1.TC_100_CSF_Validate_Text_CareerOptions_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Text_CareerOptions_CareerOption");
	driver.quit();
	break;
	
	
case "CSF_Validate_Text_CrOpporUqualityfor_CareerOption":
	
	context.setAttribute("fileName", "CSF_Validate_Text_CrOpporUqualityfor_CareerOption");
	ClubStudio_1.TC_101_CSF_Validate_Text_CrOpporUqualityfor_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Text_CrOpporUqualityfor_CareerOption");
	driver.quit();
	break;
	
	
case "CSF_Validate_Fieldson_CareerOption":
	
	context.setAttribute("fileName", "CSF_Validate_Fieldson_CareerOption");
	ClubStudio_1.TC_102_CSF_Validate_Fieldson_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Fieldson_CareerOption");
	driver.quit();
	break;
	
case "CSF_Validate_RadioPartTimeFulltime_CareerOption":
	
	context.setAttribute("fileName", "CSF_Validate_RadioPartTimeFulltime_CareerOption");
	ClubStudio_1.TC_103_CSF_Validate_RadioPartTimeFulltime_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_RadioPartTimeFulltime_CareerOption");
	driver.quit();
	break;
	
case "CSF_Validate_CB_PilatiesTeacherDirector_CareerOption":
	
	context.setAttribute("fileName", "CSF_Validate_CB_PilatiesTeacherDirector_CareerOption");
	ClubStudio_1.TC_104_CSF_Validate_CB_PilatiesTeacherDirector_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_CB_PilatiesTeacherDirector_CareerOption");
	driver.quit();
	break;
	
	
case "CSF_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption":
	
	context.setAttribute("fileName", "CSF_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption");
	ClubStudio_1.TC_105_CSF_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption");
	driver.quit();
	break;
	
	
case "CSF_Validate_Text_BasedonURsele_CareerOption":
	
	context.setAttribute("fileName", "CSF_Validate_Text_BasedonURsele_CareerOption");
	ClubStudio_1.TC_106_CSF_Validate_Text_BasedonURsele_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Text_BasedonURsele_CareerOption");
	driver.quit();
	break;
	
	
case "CSF_Validate_Text_IfSReQuestionnaire_CareerOption":
	
	context.setAttribute("fileName", "CSF_Validate_Text_IfSReQuestionnaire_CareerOption");
	ClubStudio_1.TC_107_CSF_Validate_Text_IfSReQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Text_IfSReQuestionnaire_CareerOption");
	driver.quit();
	break;
	
case "CSF_Validate_Text_RehireQuestionnaire_CareerOption":
	
	context.setAttribute("fileName", "CSF_Validate_Text_RehireQuestionnaire_CareerOption");
	ClubStudio_1.TC_108_CSF_Validate_Text_RehireQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Text_RehireQuestionnaire_CareerOption");
	driver.quit();
	break;
	
case "CSF_Validate_Fields_UnderRehireQuestionnaire_CareerOption":
	
	context.setAttribute("fileName", "CSF_Validate_Fields_UnderRehireQuestionnaire_CareerOption");
	ClubStudio_1.TC_109_CSF_Validate_Fields_UnderRehireQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSF_Validate_Fields_UnderRehireQuestionnaire_CareerOption");
	driver.quit();
	break;
	
case "CSF_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption":
	
	context.setAttribute("fileName", "CSF_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption");
	ClubStudio_1.TC_110_CSF_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSF_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption");
	driver.quit();
	break;
	
case "CSF_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption":
	
	context.setAttribute("fileName", "CSF_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption");
	ClubStudio_1.TC_111_CSF_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSF_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption");
	driver.quit();
	break;

	
case "CSF_Validate_OnClickPrvBtn_CareerOption":
	
	context.setAttribute("fileName", "CSF_Validate_OnClickPrvBtn_CareerOption");
	ClubStudio_1.TC_112_CSF_Validate_OnClickPrvBtn_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSF_Validate_OnClickPrvBtn_CareerOption");
	driver.quit();
	break;
	
	
case "CSF_Validate_OnClickNextBtn_CareerOption":
	
	context.setAttribute("fileName", "CSF_Validate_OnClickNextBtn_CareerOption");
	ClubStudio_1.TC_113_CSF_Validate_OnClickNextBtn_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSF_Validate_OnClickNextBtn_CareerOption");
	driver.quit();
	break;
	
	
case "CSF_Validate_Text_EqualOpportunityEmpy_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_Text_EqualOpportunityEmpy_EOE");
	ClubStudio_1.TC_114_CSF_Validate_Text_EqualOpportunityEmpy_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSF_Validate_Text_EqualOpportunityEmpy_EOE");
	driver.quit();
	break;
	
case "CSF_Validate_Text_TheCompanyisan_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_Text_TheCompanyisan_EOE");
	ClubStudio_1.TC_115_CSF_Validate_Text_TheCompanyisan_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSF_Validate_Text_TheCompanyisan_EOE");
	driver.quit();
	break;
	
case "CSF_Validate_Text_CompletionOfForm_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_Text_CompletionOfForm_EOE");
	ClubStudio_1.TC_116_CSF_Validate_Text_CompletionOfForm_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSF_Validate_Text_CompletionOfForm_EOE");
	driver.quit();
	break;
	
case "CSF_Validate_Fields_EqualOpportunityEmploymentSection_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_Text_CompletionOfForm_EOE");
	ClubStudio_1.TC_117_CSF_Validate_Fields_EqualOpportunityEmploymentSection_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSF_Validate_Fields_EqualOpportunityEmploymentSection_EOE");
	driver.quit();
	break;
	
case "CSF_Validate_DDValues_WtisUrGender_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_DDValues_WtisUrGender_EOE");
	ClubStudio_1.TC_118_CSF_Validate_DDValues_WtisUrGender_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5);
	context.setAttribute("fileName", "CSF_Validate_DDValues_WtisUrGender_EOE");
	driver.quit();
	break;
	
	
case "CSF_Validate_DDValues_WtyourRaceEthnicOrigin_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_DDValues_WtyourRaceEthnicOrigin_EOE");
	ClubStudio_1.TC_119_CSF_Validate_DDValues_WtyourRaceEthnicOrigin_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSF_Validate_DDValues_WtyourRaceEthnicOrigin_EOE");
	driver.quit();
	break;
	
case "CSF_Validate_Text_HispanicorLatino_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_Text_HispanicorLatino_EOE");
	ClubStudio_1.TC_120_CSF_Validate_Text_HispanicorLatino_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSF_Validate_Text_HispanicorLatino_EOE");
	driver.quit();
	break;
	
	
case "CSF_Validate_Text_WhiteNotHispanicorLatino_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_Text_WhiteNotHispanicorLatino_EOE");
	ClubStudio_1.TC_121_CSF_Validate_Text_WhiteNotHispanicorLatino_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSF_Validate_Text_WhiteNotHispanicorLatino_EOE");
	driver.quit();
	break;
	
case "CSF_Validate_Text_BlackorAfricanAmerican_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_Text_BlackorAfricanAmerican_EOE");
	ClubStudio_1.TC_122_CSF_Validate_Text_BlackorAfricanAmerican_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSF_Validate_Text_BlackorAfricanAmerican_EOE");
	driver.quit();
	break;
	
	
case "CSF_Validate_Text_NativeHawaiianorOtherPacific_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_Text_NativeHawaiianorOtherPacific_EOE");
	ClubStudio_1.TC_123_CSF_Validate_Text_NativeHawaiianorOtherPacific_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSF_Validate_Text_NativeHawaiianorOtherPacific_EOE");
	driver.quit();
	break;	
	

case "CSF_Validate_Text_AsianNotHispanicorLatino_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_Text_AsianNotHispanicorLatino_EOE");
	ClubStudio_1.TC_124_CSF_Validate_Text_AsianNotHispanicorLatino_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSF_Validate_Text_AsianNotHispanicorLatino_EOE");
	driver.quit();
	break;	

case "CSF_Validate_Text_AmericanIndianorAlaskanNative_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_Text_AmericanIndianorAlaskanNative_EOE");
	ClubStudio_1.TC_125_CSF_Validate_Text_AmericanIndianorAlaskanNative_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSF_Validate_Text_AmericanIndianorAlaskanNative_EOE");
	driver.quit();
	break;	
	
case "CSF_Validate_Text_Allpersonswho_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_Text_Allpersonswho_EOE");
	ClubStudio_1.TC_126_CSF_Validate_Text_Allpersonswho_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSF_Validate_Text_Allpersonswho_EOE");
	driver.quit();
	break;	
	
case "CSF_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE");
	ClubStudio_1.TC_127_CSF_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSF_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE");
	driver.quit();
	break;	
	
case "CSF_Validate_Fieldinputs_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_Fieldinputs_EOE");
	ClubStudio_1.TC_128_CSF_Validate_Fieldinputs_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSF_Validate_Fieldinputs_EOE");
	driver.quit();
	break;	
	
case "CSF_Validate_PreviBtn_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_PreviBtn_EOE");
	ClubStudio_1.TC_129_CSF_Validate_PreviBtn_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSF_Validate_PreviBtn_EOE");
	driver.quit();
	break;	
	
case "CSF_Validate_NextBtn_EOE":
	
	context.setAttribute("fileName", "CSF_Validate_NextBtn_EOE");
	ClubStudio_1.TC_130_CSF_Validate_NextBtn_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSF_Validate_NextBtn_EOE");
	driver.quit();
	break;	
	
case "CSF_Validate_Text_ApplicationStatement_AppliSatement":
	
	context.setAttribute("fileName", "CSF_Validate_Text_ApplicationStatement_AppliSatement");
	ClubStudio_1.TC_131_CSF_Validate_Text_ApplicationStatement_AppliSatement(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSF_Validate_Text_ApplicationStatement_AppliSatement");
	driver.quit();
	break;	
	
	
case "CSF_Validate_Text_ThisApplicationCompleteParaOnApplicantStatement":
	
	context.setAttribute("fileName", "CSF_Validate_Text_ThisApplicationCompleteParaOnApplicantStatement");
	ClubStudio_1.TC_132_CSF_Validate_Text_ThisApplicationCompleteParaOnApplicantStatement(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSF_Validate_Text_ThisApplicationCompleteParaOnApplicantStatement");
	driver.quit();
	break;	
	
case "CSF_Validate_input_FirstNameLastName_acknowledgelineofApplicantStatementpage":
	
	context.setAttribute("fileName", "CSF_Validate_input_FirstNameLastName_acknowledgelineofApplicantStatementpage");
	ClubStudio_1.TC_133_CSF_Validate_input_FirstNameLastName_acknowledgelineofApplicantStatementpage(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_input_FirstNameLastName_acknowledgelineofApplicantStatementpage");
	driver.quit();
	break;
	
	
case "CSF_Validate_text_Iacknowledge_ApplicantStatementpage":
	
	context.setAttribute("fileName", "CSF_Validate_text_Iacknowledge_ApplicantStatementpage");
	ClubStudio_1.TC_134_CSF_Validate_text_Iacknowledge_ApplicantStatementpage(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_text_Iacknowledge_ApplicantStatementpage");
	driver.quit();
	break;
	
case "CSF_Validate_Previbtn_ApplicantStatementpage":
	
	context.setAttribute("fileName", "CSF_Validate_Previbtn_ApplicantStatementpage");
	ClubStudio_1.TC_135_CSF_Validate_Previbtn_ApplicantStatementpage(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Previbtn_ApplicantStatementpage");
	driver.quit();
	break;
	
case "CSF_Validate_Nextbtn_ApplicantStatementpage":
	
	context.setAttribute("fileName", "CSF_Validate_Nextbtn_ApplicantStatementpage");
	ClubStudio_1.TC_136_CSF_Validate_Nextbtn_ApplicantStatementpage(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Nextbtn_ApplicantStatementpage");
	driver.quit();
	break;
	
case "CSF_Validate_Text_ArbitationnDispute_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Text_ArbitationnDispute_AandD");
	ClubStudio_1.TC_137_CSF_Validate_Text_ArbitationnDispute_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Text_ArbitationnDispute_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_Text_Asaconditionofconsideration_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Text_Asaconditionofconsideration_AandD");
	ClubStudio_1.TC_138_CSF_Validate_Text_Asaconditionofconsideration_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Text_Asaconditionofconsideration_AandD");
	driver.quit();
	break;
	
	
case "CSF_Validate_Link_DisputeResolutionRulesandProcedures_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Link_DisputeResolutionRulesandProcedures_AandD");
	ClubStudio_1.TC_139_CSF_Validate_Link_DisputeResolutionRulesandProcedures_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Link_DisputeResolutionRulesandProcedures_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_Text_FITNESSINTERNATIONAL_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Text_FITNESSINTERNATIONAL_AandD");
	ClubStudio_1.TC_140_CSF_Validate_Text_FITNESSINTERNATIONAL_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Text_FITNESSINTERNATIONAL_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_Text_IrecognizeThatDifferences_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Text_IrecognizeThatDifferences_AandD");
	ClubStudio_1.TC_141_CSF_Validate_Text_IrecognizeThatDifferences_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Text_IrecognizeThatDifferences_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_Text_IunderstandthatifIdofile_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Text_IunderstandthatifIdofile_AandD");
	ClubStudio_1.TC_142_CSF_Validate_Text_IunderstandthatifIdofile_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Text_IunderstandthatifIdofile_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_Text_IFurtherUnderstandAgreeThat_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Text_IFurtherUnderstandAgreeThat_AandD");
	ClubStudio_1.TC_143_CSF_Validate_Text_IFurtherUnderstandAgreeThat_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Text_IFurtherUnderstandAgreeThat_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_Text_IHaveReadThisAgreementAndUnderstand_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Text_IHaveReadThisAgreementAndUnderstand_AandD");
	ClubStudio_1.TC_144_CSF_Validate_Text_IHaveReadThisAgreementAndUnderstand_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Text_IHaveReadThisAgreementAndUnderstand_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_Text_IAGreenAcknReceipt_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Text_IAGreenAcknReceipt_AandD");
	ClubStudio_1.TC_145_CSF_Validate_Text_IAGreenAcknReceipt_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Text_IAGreenAcknReceipt_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_Text_DateweekMonth_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Text_DateweekMonth_AandD");
	ClubStudio_1.TC_146_CSF_Validate_Text_DateweekMonth_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Text_DateweekMonth_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_Text_PrintName_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Text_PrintName_AandD");
	ClubStudio_1.TC_147_CSF_Validate_Text_PrintName_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Text_PrintName_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_Text_FitnessInternationalLLCagreestofollow_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Text_FitnessInternationalLLCagreestofollow_AandD");
	ClubStudio_1.TC_148_CSF_Validate_Text_FitnessInternationalLLCagreestofollow_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Text_FitnessInternationalLLCagreestofollow_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_ImgSign_RobertBryant_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_ImgSign_RobertBryant_AandD");
	ClubStudio_1.TC_149_CSF_Validate_ImgSign_RobertBryant_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_ImgSign_RobertBryant_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_Text_ByClickingBelow_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Text_ByClickingBelow_AandD");
	ClubStudio_1.TC_150_CSF_Validate_Text_ByClickingBelow_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Text_ByClickingBelow_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_Previbtn_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Previbtn_AandD");
	ClubStudio_1.TC_151_CSF_Validate_Previbtn_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Previbtn_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_Btn_IAgree_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Btn_IAgree_AandD");
	ClubStudio_1.TC_152_CSF_Validate_Btn_IAgree_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Btn_IAgree_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_Text_UrSubmittionWasSuccessful_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Text_UrSubmittionWasSuccessful_AandD");
	ClubStudio_1.TC_153_CSF_Validate_Text_UrSubmittionWasSuccessful_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Text_UrSubmittionWasSuccessful_AandD");
	driver.quit();
	break;
	
	
case "CSF_Validate_Text_ThankUforUrIntrest_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Text_ThankUforUrIntrest_AandD");
	ClubStudio_1.TC_154_CSF_Validate_Text_ThankUforUrIntrest_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Text_ThankUforUrIntrest_AandD");
	driver.quit();
	break;
	
	
case "CSF_Validate_Text_FitnessInternatiolLLC_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Text_FitnessInternatiolLLC_AandD");
	ClubStudio_1.TC_155_CSF_Validate_Text_FitnessInternatiolLLC_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Text_FitnessInternatiolLLC_AandD");
	driver.quit();
	break;
	
	
case "CSF_Validate_Btn_PrintUrApplication_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Btn_PrintUrApplication_AandD");
	ClubStudio_1.TC_156_CSF_Validate_Btn_PrintUrApplication_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Btn_PrintUrApplication_AandD");
	driver.quit();
	break;
	
case "CSF_Validate_Last_Page_AandD":
	
	context.setAttribute("fileName", "CSF_Validate_Last_Page_AandD");
	ClubStudio_1.TC_157_CSF_Validate_Last_Page_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSF_Validate_Last_Page_AandD");
	driver.quit();
	break;
	
	//---------------Careers Personal trainer-----------------------------------Lingraj
	
case "CSFPT_Validate_onClickonApplyHere_PErsonalTrainer":
	
	context.setAttribute("fileName", "CSFPT_Validate_onClickonApplyHere_PErsonalTrainer");
	ClubStudio_1.TC_01_CSFPT_Validate_onClickonApplyHere_PErsonalTrainer(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFPT_Validate_onClickonApplyHere_PErsonalTrainer");
	driver.quit();
	break;

case "CSFPT_Validate_text_EmploymentApplication_EA":
	
	context.setAttribute("fileName", "CSFPT_Validate_text_EmploymentApplication_EA");
	ClubStudio_1.TC_02_CSFPT_Validate_text_EmploymentApplication_EA(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFPT_Validate_text_EmploymentApplication_EA");
	driver.quit();
	break;

case "CSFPT_Validate_Text_Below_EmploymentApp_EA":
	
	context.setAttribute("fileName", "CSFPT_Validate_Text_Below_EmploymentApp_EA");
	ClubStudio_1.TC_03_CSFPT_Validate_Text_Below_EmploymentApp_EA(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFPT_Validate_Text_Below_EmploymentApp_EA");
	driver.quit();
	break;
	
case "CSFPT_Validate_Text_AppInfo_ContandLocInfo_EA":
	
	context.setAttribute("fileName", "CSFPT_Validate_Text_AppInfo_ContandLocInfo_EA");
	ClubStudio_1.TC_04_CSFPT_Validate_Text_AppInfo_ContandLocInfo_EA(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFPT_Validate_Text_AppInfo_ContandLocInfo_EA");
	driver.quit();
	break;

case "CSFPT_Validate_mandatoryFields_EA":
	
	context.setAttribute("fileName", "CSFPT_Validate_mandatoryFields_EA");
	ClubStudio_1.TC_05_CSFPT_Validate_mandatoryFields_EA(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFPT_Validate_mandatoryFields_EA");
	driver.quit();
	break;
	
case "CSFPT_Validate_Dropdownvalues_HowDidUhearUs_EA":
	
	context.setAttribute("fileName", "CSFPT_Validate_Dropdownvalues_HowDidUhearUs_EA");
	ClubStudio_1.TC_06_CSFPT_Validate_Dropdownvalues_HowDidUhearUs_EA(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
	context.setAttribute("fileName", "CSFPT_Validate_Dropdownvalues_HowDidUhearUs_EA");
	driver.quit();
	break;
	
case "CSFPT_Validate_Radiobutton_RU18_EA":
	
	context.setAttribute("fileName", "CSFPT_Validate_Radiobutton_RU18_EA");
	ClubStudio_1.TC_07_CSFPT_Validate_Radiobutton_RU18_EA(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
	context.setAttribute("fileName", "CSFPT_Validate_Radiobutton_RU18_EA");
	driver.quit();
	break;
	
case "CSFPT_validate_Text_FormatUSCanada_EA":
	
	context.setAttribute("fileName", "CSFPT_validate_Text_FormatUSCanada_EA");
	ClubStudio_1.TC_08_CSFPT_validate_Text_FormatUSCanada_EA(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
	context.setAttribute("fileName", "CSFPT_validate_Text_FormatUSCanada_EA");
	driver.quit();	
	break;
	
case "CSFPT_validate_Text_Miles_EA":
	
	context.setAttribute("fileName", "CSFPT_validate_Text_Miles_EA");
	ClubStudio_1.TC_09_CSFPT_validate_Text_Miles_EA(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
	context.setAttribute("fileName", "CSFPT_validate_Text_Miles_EA");
	driver.quit();
	break;

case "CSFPT_Validate_ErrorMsg_CellPhone_EA":
	
	context.setAttribute("fileName", "CSFPT_Validate_ErrorMsg_CellPhone_EA");
	ClubStudio_1.TC_10_CSFPT_Validate_ErrorMsg_CellPhone_EA(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
	context.setAttribute("fileName", "CSFPT_Validate_ErrorMsg_CellPhone_EA");
	driver.quit();
	break;

case "CSFPT_Validate_Field_Input_EA":
	
	context.setAttribute("fileName", "CSFPT_Validate_Field_Input_EA");
	ClubStudio_1.TC_11_CSFPT_Validate_Field_Input_EA(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode);
	context.setAttribute("fileName", "CSFPT_Validate_Field_Input_EA");
	driver.quit();
	break;

case "CSFPT_Validate_Button_NextStep_EA":
	
	context.setAttribute("fileName", "CSFPT_Validate_Button_NextStep_EA");
	ClubStudio_1.TC_12_CSFPT_Validate_Button_NextStep_EA(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode);
	context.setAttribute("fileName", "CSFPT_Validate_Button_NextStep_EA");
	driver.quit();
	break;
	
case "CSFPT_Validate_url_CSF":

context.setAttribute("fileName", "CSFPT_Validate_url_CSF");
ClubStudio_1.TC_13_CSFPT_Validate_url_CSF(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_url_CSF");
driver.quit();
break;


case "CSFPT_Verify_YouMustBe18Years_popup_OnselectingRaiodNo":

context.setAttribute("fileName", "CSFPT_Verify_YouMustBe18Years_popup_OnselectingRaiodNo");
ClubStudio_1.TC_14_CSFPT_Verify_YouMustBe18Years_popup_OnselectingRaiodNo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
context.setAttribute("fileName", "CSFPT_Verify_YouMustBe18Years_popup_OnselectingRaiodNo");
driver.quit();
break;


case "CSFPT_Validate_ClubsinurRadius":

context.setAttribute("fileName", "CSFPT_Validate_ClubsinurRadius");
ClubStudio_1.TC_15_CSFPT_Validate_ClubsinurRadius(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_ClubsinurRadius");
driver.quit();
break;

case "CSFPT_Validate_Nextbutton_ClickofApplicantinfo":

context.setAttribute("fileName", "CSFPT_Validate_Nextbutton_ClickofApplicantinfo");
ClubStudio_1.TC_16_CSFPT_Validate_Nextbutton_ClickofApplicantinfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode);
context.setAttribute("fileName", "CSFPT_Validate_Nextbutton_ClickofApplicantinfo");
driver.quit();
break;

case "CSFPT_Validate_Text_EducationInfo":

context.setAttribute("fileName", "CSFPT_Validate_Text_EducationInfo");
ClubStudio_1.TC_17_CSFPT_Validate_Text_EducationInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Text_EducationInfo");
driver.quit();
break;

case "CSFPT_Validate_Field_EducationLevel":

context.setAttribute("fileName", "CSFPT_Validate_Field_EducationLevel");
ClubStudio_1.TC_18_CSFPT_Validate_Field_EducationLevel(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Field_EducationLevel");
driver.quit();
break;


case "CSFPT_Validate_DropdownValues_EducationLevel":

context.setAttribute("fileName", "CSFPT_Validate_DropdownValues_EducationLevel");
ClubStudio_1.TC_19_CSFPT_Validate_DropdownValues_EducationLevel(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFPT_Validate_DropdownValues_EducationLevel");
driver.quit();
break;

case "CSFPT_Validate_EducationLevel_ButtonsPerviousNext":

context.setAttribute("fileName", "CSFPT_Validate_EducationLevel_ButtonsPerviousNext");
ClubStudio_1.TC_20_CSFPT_Validate_EducationLevel_ButtonsPerviousNext(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFPT_Validate_EducationLevel_ButtonsPerviousNext");
driver.quit();
break;


case "CSFPT_Validate_PreviousPage_ClickofELPreviousbutton":

context.setAttribute("fileName", "CSFPT_Validate_PreviousPage_ClickofELPreviousbutton");
ClubStudio_1.TC_21_CSFPT_Validate_PreviousPage_ClickofELPreviousbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFPT_Validate_PreviousPage_ClickofELPreviousbutton");
driver.quit();
break;

case "CSFPT_Validate_NextPage_ClickofELNextbutton":

context.setAttribute("fileName", "CSFPT_Validate_NextPage_ClickofELNextbutton");
ClubStudio_1.TC_22_CSFPT_Validate_NextPage_ClickofELNextbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input, E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFPT_Validate_NextPage_ClickofELNextbutton");
driver.quit();
break;


case "CSFPT_Validate_EducationInfo_ClickofNextbutton":

context.setAttribute("fileName", "CSFPT_Validate_EducationInfo_ClickofNextbutton");
ClubStudio_1.TC_23_CSFPT_Validate_EducationInfo_ClickofNextbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFPT_Validate_EducationInfo_ClickofNextbutton");
driver.quit();
break;


case "CSFPT_Validate_Text_ExperienceInformation_ExpInfo":

context.setAttribute("fileName", "CSFPT_Validate_Text_ExperienceInformation_ExpInfo");
ClubStudio_1.TC_24_CSFPT_Validate_Text_ExperienceInformation_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFPT_Validate_Text_ExperienceInformation_ExpInfo");
driver.quit();
break;


case "CSFPT_Validate_Text_ExperienceDetail_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Text_ExperienceDetail_ExperienceInfo");
ClubStudio_1.TC_25_CSFPT_Validate_Text_ExperienceDetail_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFPT_Validate_Text_ExperienceDetail_ExperienceInfo");
driver.quit();
break;


case "CSFPT_Validate_Text_PersonalTrainer_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Text_PersonalTrainer_ExperienceInfo");
ClubStudio_1.TC_26_CSFPT_Validate_Text_PersonalTrainer_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFPT_Validate_Text_PersonalTrainer_ExperienceInfo");
driver.quit();
break;


case "CSFPT_Validate_Field_PersonalTrainerCertificate_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Field_PersonalTrainerCertificate_ExperienceInfo");
ClubStudio_1.TC_27_CSFPT_Validate_Field_PersonalTrainerCertificate_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFPT_Validate_Field_PersonalTrainerCertificate_ExperienceInfo");
driver.quit();
break;



case "CSFPT_Validate_Radio_HoldPersonalTrainer_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Radio_HoldPersonalTrainer_ExperienceInfo");
ClubStudio_1.TC_28_CSFPT_Validate_Radio_HoldPersonalTrainer_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFPT_Validate_Radio_HoldPersonalTrainer_ExperienceInfo");
driver.quit();
break;


case "CSFPT_Validate_Link_PersonalTrainerCI_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Link_PersonalTrainerCI_ExperienceInfo");
ClubStudio_1.TC_29_CSFPT_Validate_Link_PersonalTrainerCI_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFPT_Validate_Link_PersonalTrainerCI_ExperienceInfo");
driver.quit();
break;


case "CSFPT_Validate_Field_PersonalTrainingExp_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Field_PersonalTrainingExp_ExperienceInfo");
ClubStudio_1.TC_30_CSFPT_Validate_Field_PersonalTrainingExp_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFPT_Validate_Field_PersonalTrainingExp_ExperienceInfo");
driver.quit();
break;


case "CSFPT_Validate_Dp_PersonalTrainingExp_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Dp_PersonalTrainingExp_ExperienceInfo");
ClubStudio_1.TC_31_CSFPT_Validate_Dp_PersonalTrainingExp_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
context.setAttribute("fileName", "CSFPT_Validate_Dp_PersonalTrainingExp_ExperienceInfo");
driver.quit();
break;


case "CSFPT_Validate_Text_Pleaseselectnomorethan_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Text_Pleaseselectnomorethan_ExperienceInfo");
ClubStudio_1.TC_32_CSFPT_Validate_Text_Pleaseselectnomorethan_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
context.setAttribute("fileName", "CSFPT_Validate_Text_Pleaseselectnomorethan_ExperienceInfo");
driver.quit();
break;


case "CSFPT_Validate_Fields_CertifissuedCertiNum_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Fields_CertifissuedCertiNum_ExperienceInfo");
ClubStudio_1.TC_33_CSFPT_Validate_Fields_CertifissuedCertiNum_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues);
context.setAttribute("fileName", "CSFPT_Validate_Fields_CertifissuedCertiNum_ExperienceInfo");
driver.quit();
break;


case "CSFPT_Validate_DropdownValue_Certissued_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_DropdownValue_Certissued_ExperienceInfo");
ClubStudio_1.TC_34_CSFPT_Validate_DropdownValue_Certissued_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues);
context.setAttribute("fileName", "CSFPT_Validate_DropdownValue_Certissued_ExperienceInfo");
driver.quit();
break;

case "CSFPT_Validate_Text_CertificateFilesDtl_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Text_CertificateFilesDtl_ExperienceInfo");
ClubStudio_1.TC_35_CSFPT_Validate_Text_CertificateFilesDtl_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues);
context.setAttribute("fileName", "CSFPT_Validate_Text_CertificateFilesDtl_ExperienceInfo");
driver.quit();
break;

case "CSFPT_Validate_ChooseFileUpload_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_ChooseFileUpload_ExperienceInfo");
ClubStudio_1.TC_36_CSFPT_Validate_ChooseFileUpload_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues);
context.setAttribute("fileName", "CSFPT_Validate_ChooseFileUpload_ExperienceInfo");
driver.quit();
break;

case "CSFPT_Validate_SelectCertificate_Certinum_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_SelectCertificate_Certinum_ExperienceInfo");
ClubStudio_1.TC_37_CSFPT_Validate_SelectCertificate_Certinum_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues);
context.setAttribute("fileName", "CSFPT_Validate_SelectCertificate_Certinum_ExperienceInfo");
driver.quit();
break;

case "CSFPT_Validate_Button_AddCertificate_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Button_AddCertificate_ExperienceInfo");
ClubStudio_1.TC_38_CSFPT_Validate_Button_AddCertificate_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues);
context.setAttribute("fileName", "CSFPT_Validate_Button_AddCertificate_ExperienceInfo");
driver.quit();
break;

case "CSFPT_Validate_Click_AddCertificate_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Click_AddCertificate_ExperienceInfo");
ClubStudio_1.TC_39_CSFPT_Validate_Click_AddCertificate_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues);
context.setAttribute("fileName", "CSFPT_Validate_Click_AddCertificate_ExperienceInfo");
driver.quit();
break;

case "CSFPT_Validate_PopUp_Nomorethan3TrainCerti_AddCerti_ExpIn":

context.setAttribute("fileName", "CSFPT_Validate_PopUp_Nomorethan3TrainCerti_AddCerti_ExpIn");
ClubStudio_1.TC_40_CSFPT_Validate_PopUp_Nomorethan3TrainCerti_AddCerti_ExpIn(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues);
context.setAttribute("fileName", "CSFPT_Validate_PopUp_Nomorethan3TrainCerti_AddCerti_ExpIn");
driver.quit();
break;

case "CSFPT_Validate_Button_RemoveIcon_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Button_RemoveIcon_ExperienceInfo");
ClubStudio_1.TC_41_CSFPT_Validate_Button_RemoveIcon_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues);
context.setAttribute("fileName", "CSFPT_Validate_Button_RemoveIcon_ExperienceInfo");
driver.quit();
break;

case "CSFPT_Validate_Click_RemoveIcon_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Click_RemoveIcon_ExperienceInfo");
ClubStudio_1.TC_42_CSFPT_Validate_Click_RemoveIcon_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues);
context.setAttribute("fileName", "CSFPT_Validate_Click_RemoveIcon_ExperienceInfo");
driver.quit();
break;

case "CSFPT_Validate_Button_PreviousNextExperInfopage_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Button_PreviousNextExperInfopage_ExperienceInfo");
ClubStudio_1.TC_43_CSFPT_Validate_Button_PreviousNextExperInfopage_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues);
context.setAttribute("fileName", "CSFPT_Validate_Button_PreviousNextExperInfopage_ExperienceInfo");
driver.quit();
break;

case "CSFPT_Validate_Click_PreviousExperInfopage_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Click_PreviousExperInfopage_ExperienceInfo");
ClubStudio_1.TC_44_CSFPT_Validate_Click_PreviousExperInfopage_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues);
context.setAttribute("fileName", "CSFPT_Validate_Click_PreviousExperInfopage_ExperienceInfo");
driver.quit();
break;


case "CSFPT_Validate_Click_NextExperInfopage_ExperienceInfo":

context.setAttribute("fileName", "CSFPT_Validate_Click_NextExperInfopage_ExperienceInfo");
ClubStudio_1.TC_45_CSFPT_Validate_Click_NextExperInfopage_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues);
context.setAttribute("fileName", "CSFPT_Validate_Click_NextExperInfopage_ExperienceInfo");
driver.quit();
break;


case "CSFPT_Validate_Text_EmploymentHistory":

context.setAttribute("fileName", "CSFPT_Validate_Text_EmploymentHistory");
ClubStudio_1.TC_46_CSFPT_Validate_Text_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Text_EmploymentHistory");
driver.quit();
break;


case "CSFPT_Validate_Text_PreviousEmployment_EH":

context.setAttribute("fileName", "CSFPT_Validate_Text_PreviousEmployment_EH");
ClubStudio_1.TC_47_CSFPT_Validate_Text_PreviousEmployment_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Text_PreviousEmployment_EH");
driver.quit();
break;
	
case "CSFPT_Validate_Radioptn_PreEmploymentnIhvEmphis_EH":

context.setAttribute("fileName", "CSFPT_Validate_Radioptn_PreEmploymentnIhvEmphis_EH");
ClubStudio_1.TC_48_CSFPT_Validate_Radioptn_PreEmploymentnIhvEmphis_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Radioptn_PreEmploymentnIhvEmphis_EH");
driver.quit();
break;
	
	
case "CSFPT_Validate_Field_EmploymentGapExp_EH":

context.setAttribute("fileName", "CSFPT_Validate_Field_EmploymentGapExp_EH");
ClubStudio_1.TC_49_CSFPT_Validate_Field_EmploymentGapExp_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Field_EmploymentGapExp_EH");
driver.quit();
break;	
	
	
case "CSFPT_Validate_Field_IWillUploadMyResume_EH":

context.setAttribute("fileName", "CSFPT_Validate_Field_IWillUploadMyResume_EH");
ClubStudio_1.TC_50_CSFPT_Validate_Field_IWillUploadMyResume_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Field_IWillUploadMyResume_EH");
driver.quit();
break;	
	
case "CSFPT_Validate_Text_Resume_OnClickofIwillupload_EH":

context.setAttribute("fileName", "CSFPT_Validate_Text_Resume_OnClickofIwillupload_EH");
ClubStudio_1.TC_51_CSFPT_Validate_Text_Resume_OnClickofIwillupload_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Text_Resume_OnClickofIwillupload_EH");
driver.quit();
break;	


case "CSFPT_Validate_Text_FileMustbfull_OnClickofIwillupload_EH":

context.setAttribute("fileName", "CSFPT_Validate_Text_FileMustbfull_OnClickofIwillupload_EH");
ClubStudio_1.TC_52_CSFPT_Validate_Text_FileMustbfull_OnClickofIwillupload_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Text_FileMustbfull_OnClickofIwillupload_EH");
driver.quit();
break;	

case "CSFPT_Validate_Btn_ChooseFile_OnClickofIwillupload_EH":

context.setAttribute("fileName", "CSFPT_Validate_Btn_ChooseFile_OnClickofIwillupload_EH");
ClubStudio_1.TC_53_CSFPT_Validate_Btn_ChooseFile_OnClickofIwillupload_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Btn_ChooseFile_OnClickofIwillupload_EH");
driver.quit();
break;


case "CSFPT_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EH":

context.setAttribute("fileName", "CSFPT_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EH");
ClubStudio_1.TC_54_CSFPT_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EH");
driver.quit();
break;


case "CSFPT_Validate_Text_EnterEmpHistory_EH":

context.setAttribute("fileName", "CSFPT_Validate_Text_EnterEmpHistory_EH");
ClubStudio_1.TC_55_CSFPT_Validate_Text_EnterEmpHistory_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Text_EnterEmpHistory_EH");
driver.quit();
break;


case "CSFPT_Validate_Text_PreviousEmployer1_EH":

context.setAttribute("fileName", "CSFPT_Validate_Text_PreviousEmployer1_EH");
ClubStudio_1.TC_56_CSFPT_Validate_Text_PreviousEmployer1_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Text_PreviousEmployer1_EH");
driver.quit();
break;

	
case "CSFPT_Validate_Fields_UnderPreviousEmployer1_EH":

context.setAttribute("fileName", "CSFPT_Validate_Fields_UnderPreviousEmployer1_EH");
ClubStudio_1.TC_57_CSFPT_Validate_Fields_UnderPreviousEmployer1_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Fields_UnderPreviousEmployer1_EH");
driver.quit();
break;

case "CSFPT_Validate_FieldsInputs_UnderPreviousEmployer1_EH":

context.setAttribute("fileName", "CSFPT_Validate_FieldsInputs_UnderPreviousEmployer1_EH");
ClubStudio_1.TC_58_CSFPT_Validate_FieldsInputs_UnderPreviousEmployer1_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_FieldsInputs_UnderPreviousEmployer1_EH");
driver.quit();
break;
	
case "CSFPT_Validate_Text_BSpecific_NearReasonforLeaving_EH":

context.setAttribute("fileName", "CSFPT_Validate_Text_BSpecific_NearReasonforLeaving_EH");
ClubStudio_1.TC_59_CSFPT_Validate_Text_BSpecific_NearReasonforLeaving_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Text_BSpecific_NearReasonforLeaving_EH");
driver.quit();
break;

case "CSFPT_Validate_Text_ListofJobs_NearEmploymentDetail_EH":

context.setAttribute("fileName", "CSFPT_Validate_Text_ListofJobs_NearEmploymentDetail_EH");
ClubStudio_1.TC_60_CSFPT_Validate_Text_ListofJobs_NearEmploymentDetail_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Text_ListofJobs_NearEmploymentDetail_EH");
driver.quit();
break;
	
	
case "CSFPT_Validate_RadioOptions_CanbeContacted_EH":

context.setAttribute("fileName", "CSFPT_Validate_RadioOptions_CanbeContacted_EH");
ClubStudio_1.TC_61_CSFPT_Validate_RadioOptions_CanbeContacted_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_RadioOptions_CanbeContacted_EH");
driver.quit();
break;
	
	
case "CSFPT_Validate_Btn_AddEmployer2_EH":

context.setAttribute("fileName", "CSFPT_Validate_Btn_AddEmployer2_EH");
ClubStudio_1.TC_62_CSFPT_Validate_Btn_AddEmployer2_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Btn_AddEmployer2_EH");
driver.quit();
break;
	
case "CSFPT_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EH":

context.setAttribute("fileName", "CSFPT_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EH");
ClubStudio_1.TC_63_CSFPT_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EH");
driver.quit();
break;


case "CSFPT_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EH":

context.setAttribute("fileName", "CSFPT_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EH");
ClubStudio_1.TC_64_CSFPT_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EH");
driver.quit();
break;


case "CSFPT_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EH":

context.setAttribute("fileName", "CSFPT_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EH");
ClubStudio_1.TC_65_CSFPT_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EH");
driver.quit();
break;



case "CSFPT_Validate_Btn_RemovEmp3_OnclickAddEmp3_EH":

context.setAttribute("fileName", "CSFPT_Validate_Btn_RemovEmp3_OnclickAddEmp3_EH");
ClubStudio_1.TC_66_CSFPT_Validate_Btn_RemovEmp3_OnclickAddEmp3_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Btn_RemovEmp3_OnclickAddEmp3_EH");
driver.quit();
break;


case "CSFPT_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EH":

context.setAttribute("fileName", "CSFPT_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EH");
ClubStudio_1.TC_67_CSFPT_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EH");
driver.quit();
break;


case "CSFPT_Validate_OnClick_RemoveEmp3_EH":

context.setAttribute("fileName", "CSFPT_Validate_OnClick_RemoveEmp3_EH");
ClubStudio_1.TC_68_CSFPT_Validate_OnClick_RemoveEmp3_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_OnClick_RemoveEmp3_EH");
driver.quit();
break;

case "CSFPT_Validate_OnClick_RemoveEmp2_EH":

context.setAttribute("fileName", "CSFPT_Validate_OnClick_RemoveEmp2_EH");
ClubStudio_1.TC_69_CSFPT_Validate_OnClick_RemoveEmp2_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_OnClick_RemoveEmp2_EH");
driver.quit();
break;

case "CSFPT_Validate_Txt_ExpInfo_onClickPreviosbtn_EH":

context.setAttribute("fileName", "CSFPT_Validate_Txt_ExpInfo_onClickPreviosbtn_EH");
ClubStudio_1.TC_70_CSFPT_Validate_Txt_ExpInfo_onClickPreviosbtn_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Txt_ExpInfo_onClickPreviosbtn_EH");
driver.quit();
break;


case "CSFPT_Validate_onClickNextbtn_EH":

context.setAttribute("fileName", "CSFPT_Validate_onClickNextbtn_EH");
ClubStudio_1.TC_71_CSFPT_Validate_onClickNextbtn_EH(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date);
context.setAttribute("fileName", "CSFPT_Validate_onClickNextbtn_EH");
driver.quit();
break;

case "CSFPT_Validate_Text_LanguageSkills_LanguageSkills":

context.setAttribute("fileName", "CSFPT_Validate_Text_LanguageSkills_LanguageSkills");
ClubStudio_1.TC_72_CSFPT_Validate_Text_LanguageSkills_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Text_LanguageSkills_LanguageSkills");
driver.quit();
break;


case "CSFPT_Validate_Text_IncicateLang_LanguageSkills":

context.setAttribute("fileName", "CSFPT_Validate_Text_IncicateLang_LanguageSkills");
ClubStudio_1.TC_73_CSFPT_Validate_Text_IncicateLang_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Text_IncicateLang_LanguageSkills");
driver.quit();
break;

case "CSFPT_Validate_Languages_LanguageSkills":

context.setAttribute("fileName", "CSFPT_Validate_Languages_LanguageSkills");
ClubStudio_1.TC_74_CSFPT_Validate_Languages_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_Languages_LanguageSkills");
driver.quit();
break;


case "CSFPT_Validate_OnClickPrvBtn_LanguageSkills":

context.setAttribute("fileName", "CSFPT_Validate_OnClickPrvBtn_LanguageSkills");
ClubStudio_1.TC_75_CSFPT_Validate_OnClickPrvBtn_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date,Text_input);
context.setAttribute("fileName", "CSFPT_Validate_OnClickPrvBtn_LanguageSkills");
driver.quit();
break;

case "CSFPT_Validate_OnClickNextBtn_LanguageSkills":

context.setAttribute("fileName", "CSFPT_Validate_OnClickNextBtn_LanguageSkills");
ClubStudio_1.TC_76_CSFPT_Validate_OnClickNextBtn_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date);
context.setAttribute("fileName", "CSFPT_Validate_OnClickNextBtn_LanguageSkills");
driver.quit();
break;



case "CSFPT_Validate_Text_CareerOptions_CO":
	context.setAttribute("fileName", "CSFPT_Validate_Text_CareerOptions_CO");
	ClubStudio_1.TC_77_CSFPT_Validate_Text_CareerOptions_CO(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
	context.setAttribute("fileName", "CSFPT_Validate_Text_CareerOptions_CO");
	driver.quit();
	break;					


case "CSFPT_Validate_Text_CrOpporUqualityfor_CO":
	context.setAttribute("fileName", "CSFPT_Validate_Text_CrOpporUqualityfor_CO");
	ClubStudio_1.TC_78_CSFPT_Validate_Text_CrOpporUqualityfor_CO(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
	context.setAttribute("fileName", "CSFPT_Validate_Text_CrOpporUqualityfor_CO");
	driver.quit();
	break;					


case "CSFPT_Validate_Fieldson_CO":
	context.setAttribute("fileName", "CSFPT_Validate_Fieldson_CO");
	ClubStudio_1.TC_79_CSFPT_Validate_Fieldson_CO(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
	context.setAttribute("fileName", "CSFPT_Validate_Fieldson_CO");
	driver.quit();
	break;					

case "CSFPT_Validate_RadioPartTimeFulltime_CO":
	context.setAttribute("fileName", "CSFPT_Validate_RadioPartTimeFulltime_CO");
	ClubStudio_1.TC_80_CSFPT_Validate_RadioPartTimeFulltime_CO(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
	context.setAttribute("fileName", "CSFPT_Validate_RadioPartTimeFulltime_CO");
	driver.quit();
	break;					

case "CSFPT_Validate_CB_PersonalTrainer_CO":
	context.setAttribute("fileName", "CSFPT_Validate_CB_PersonalTrainer_CO");
	ClubStudio_1.TC_81_CSFPT_Validate_CB_PersonalTrainer_CO(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
	context.setAttribute("fileName", "CSFPT_Validate_CB_PersonalTrainer_CO");
	driver.quit();
	break;					


case "CSFPT_Validate_RadioYesNo_RuNoworEverEmployed_CO":
	context.setAttribute("fileName", "CSFPT_Validate_RadioYesNo_RuNoworEverEmployed_CO");
	ClubStudio_1.TC_82_CSFPT_Validate_RadioYesNo_RuNoworEverEmployed_CO(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
	context.setAttribute("fileName", "CSFPT_Validate_RadioYesNo_RuNoworEverEmployed_CO");
	driver.quit();
	break;					


case "CSFPT_Validate_Text_BasedonURsele_CO":
	context.setAttribute("fileName", "CSFPT_Validate_Text_BasedonURsele_CO");
	ClubStudio_1.TC_83_CSFPT_Validate_Text_BasedonURsele_CO(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
	context.setAttribute("fileName", "CSFPT_Validate_Text_BasedonURsele_CO");
	driver.quit();
	break;					



case "CSFPT_Validate_Text_IfSReQuestionnaire_CO":
	context.setAttribute("fileName", "CSFPT_Validate_Text_IfSReQuestionnaire_CO");
	ClubStudio_1.TC_84_CSFPT_Validate_Text_IfSReQuestionnaire_CO(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
	context.setAttribute("fileName", "CSFPT_Validate_Text_IfSReQuestionnaire_CO");
	driver.quit();
	break;					


case "CSFPT_Validate_Text_RehireQuestionnaire_CO":
	context.setAttribute("fileName", "CSFPT_Validate_Text_RehireQuestionnaire_CO");
	ClubStudio_1.TC_85_CSFPT_Validate_Text_RehireQuestionnaire_CO(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
	context.setAttribute("fileName", "CSFPT_Validate_Text_RehireQuestionnaire_CO");
	driver.quit();
	break;	



case "CSFPT_Validate_Fields_UnderRehireQuestionnaire_CO":
	context.setAttribute("fileName", "CSFPT_Validate_Fields_UnderRehireQuestionnaire_CO");
	ClubStudio_1.TC_86_CSFPT_Validate_Fields_UnderRehireQuestionnaire_CO(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
	context.setAttribute("fileName", "CSFPT_Validate_Fields_UnderRehireQuestionnaire_CO");
	driver.quit();
	break;	


case "CSFPT_Validate_FieldInputs_UnderRehireQuestionnaire_CO":
	context.setAttribute("fileName", "CSFPT_Validate_FieldInputs_UnderRehireQuestionnaire_CO");
	ClubStudio_1.TC_87_CSFPT_Validate_FieldInputs_UnderRehireQuestionnaire_CO(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason );
	context.setAttribute("fileName", "CSFPT_Validate_FieldInputs_UnderRehireQuestionnaire_CO");
	driver.quit();
	break;	


case "CSFPT_Validate_Dropdown_HwdidUresignEmpwitUs_CO":
	context.setAttribute("fileName", "CSFPT_Validate_Dropdown_HwdidUresignEmpwitUs_CO");
	ClubStudio_1.TC_88_CSFPT_Validate_Dropdown_HwdidUresignEmpwitUs_CO(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason );
	context.setAttribute("fileName", "CSFPT_Validate_Dropdown_HwdidUresignEmpwitUs_CO");
	driver.quit();
	break;	

case "CSFPT_Validate_OnClickPrvBtn_CO":
	context.setAttribute("fileName", "CSFPT_Validate_OnClickPrvBtn_CO");
	ClubStudio_1.TC_89_CSFPT_Validate_OnClickPrvBtn_CO(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason );
	context.setAttribute("fileName", "CSFPT_Validate_OnClickPrvBtn_CO");
	driver.quit();
	break;	

case "CSFPT_Validate_OnClickNextBtn_CO":
	context.setAttribute("fileName", "CSFPT_Validate_OnClickNextBtn_CO");
	ClubStudio_1.TC_90_CSFPT_Validate_OnClickNextBtn_CO(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason );
	context.setAttribute("fileName", "CSFPT_Validate_OnClickNextBtn_CO");
	driver.quit();
	break;	

case "CSFPT_Validate_Text_EqualOpportunityEmpy_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_Text_EqualOpportunityEmpy_EOE");
	ClubStudio_1.TC_91_CSFPT_Validate_Text_EqualOpportunityEmpy_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason );
	context.setAttribute("fileName", "CSFPT_Validate_Text_EqualOpportunityEmpy_EOE");
	driver.quit();
	break;	


case "CSFPT_Validate_Text_TheCompanyisan_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_Text_TheCompanyisan_EOE");
	ClubStudio_1.TC_92_CSFPT_Validate_Text_TheCompanyisan_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason );
	context.setAttribute("fileName", "CSFPT_Validate_Text_TheCompanyisan_EOE");
	driver.quit();
	break;	

case "CSFPT_Validate_Text_CompletionOfForm_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_Text_CompletionOfForm_EOE");
	ClubStudio_1.TC_93_CSFPT_Validate_Text_CompletionOfForm_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason );
	context.setAttribute("fileName", "CSFPT_Validate_Text_CompletionOfForm_EOE");
	driver.quit();
	break;	
	
case "CSFPT_Validate_Fields_EqualOEmpSection_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_Fields_EqualOEmpSection_EOE");
	ClubStudio_1.TC_94_CSFPT_Validate_Fields_EqualOEmpSection_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason );
	context.setAttribute("fileName", "CSFPT_Validate_Fields_EqualOEmpSection_EOE");
	driver.quit();
	break;	


case "CSFPT_Validate_DDValues_WtisUrGender_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_DDValues_WtisUrGender_EOE");
	ClubStudio_1.TC_95_CSFPT_Validate_DDValues_WtisUrGender_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5 );
	context.setAttribute("fileName", "CSFPT_Validate_DDValues_WtisUrGender_EOE");
	driver.quit();
	break;	



case "CSFPT_Validate_DDValues_WtyourRaceEthnicOrigin_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_DDValues_WtyourRaceEthnicOrigin_EOE");
	ClubStudio_1.TC_96_CSFPT_Validate_DDValues_WtyourRaceEthnicOrigin_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
	context.setAttribute("fileName", "CSFPT_Validate_DDValues_WtyourRaceEthnicOrigin_EOE");
	driver.quit();
	break;	

case "CSFPT_Validate_Text_HispanicorLatino_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_Text_HispanicorLatino_EOE");
	ClubStudio_1.TC_97_CSFPT_Validate_Text_HispanicorLatino_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
	context.setAttribute("fileName", "CSFPT_Validate_Text_HispanicorLatino_EOE");
	driver.quit();
	break;	

case "CSFPT_Validate_Text_WhiteNotHispanicorLatino_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_Text_WhiteNotHispanicorLatino_EOE");
	ClubStudio_1.TC_98_CSFPT_Validate_Text_WhiteNotHispanicorLatino_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
	context.setAttribute("fileName", "CSFPT_Validate_Text_WhiteNotHispanicorLatino_EOE");
	driver.quit();
	break;	


case "CSFPT_Validate_Text_BlackorAfricanAmerican_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_Text_BlackorAfricanAmerican_EOE");
	ClubStudio_1.TC_99_CSFPT_Validate_Text_BlackorAfricanAmerican_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
	context.setAttribute("fileName", "CSFPT_Validate_Text_BlackorAfricanAmerican_EOE");
	driver.quit();
	break;	

case "CSFPT_Validate_Text_NativeHawaiianorOtherPacific_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_Text_NativeHawaiianorOtherPacific_EOE");
	ClubStudio_1.TC_100_CSFPT_Validate_Text_NativeHawaiianorOtherPacific_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
	context.setAttribute("fileName", "CSFPT_Validate_Text_NativeHawaiianorOtherPacific_EOE");
	driver.quit();
	break;	
	
	
case "CSFPT_Validate_Text_AsianNotHispanicorLatino_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_Text_AsianNotHispanicorLatino_EOE");
	ClubStudio_1.TC_101_CSFPT_Validate_Text_AsianNotHispanicorLatino_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
	context.setAttribute("fileName", "CSFPT_Validate_Text_AsianNotHispanicorLatino_EOE");
	driver.quit();
	break;	

case "CSFPT_Validate_Text_AmericanIndianorAlaskanNative_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_Text_AmericanIndianorAlaskanNative_EOE");
	ClubStudio_1.TC_102_CSFPT_Validate_Text_AmericanIndianorAlaskanNative_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
	context.setAttribute("fileName", "CSFPT_Validate_Text_AmericanIndianorAlaskanNative_EOE");
	driver.quit();
	break;	
	
case "CSFPT_Validate_Text_Allpersonswho_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_Text_Allpersonswho_EOE");
	ClubStudio_1.TC_103_CSFPT_Validate_Text_Allpersonswho_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
	context.setAttribute("fileName", "CSFPT_Validate_Text_Allpersonswho_EOE");
	driver.quit();
	break;	


case "CSFPT_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE");
	ClubStudio_1.TC_104_CSFPT_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
	context.setAttribute("fileName", "CSFPT_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE");
	driver.quit();
	break;	

case "CSFPT_Validate_Fieldinputs_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_Fieldinputs_EOE");
	ClubStudio_1.TC_105_CSFPT_Validate_Fieldinputs_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
	context.setAttribute("fileName", "CSFPT_Validate_Fieldinputs_EOE");
	driver.quit();
	break;	



case "CSFPT_Validate_PreviBtn_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_PreviBtn_EOE");
	ClubStudio_1.TC_106_CSFPT_Validate_PreviBtn_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
	context.setAttribute("fileName", "CSFPT_Validate_PreviBtn_EOE");
	driver.quit();
	break;	

case "CSFPT_Validate_NextBtn_EOE":
	context.setAttribute("fileName", "CSFPT_Validate_NextBtn_EOE");
	ClubStudio_1.TC_107_CSFPT_Validate_NextBtn_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
	context.setAttribute("fileName", "CSFPT_Validate_NextBtn_EOE");
	driver.quit();
	break;	


case "CSFPT_Validate_Text_ApplicationStatement_AS":
	context.setAttribute("fileName", "CSFPT_Validate_Text_ApplicationStatement_AS");
	ClubStudio_1.TC_108_CSFPT_Validate_Text_ApplicationStatement_AS(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
	context.setAttribute("fileName", "CSFPT_Validate_Text_ApplicationStatement_AS");
	driver.quit();
	break;	

case "CSFPT_Validate_Text_ThisApplicationCompletePar_AS":
	context.setAttribute("fileName", "CSFPT_Validate_Text_ThisApplicationCompletePar_AS");
	ClubStudio_1.TC_109_CSFPT_Validate_Text_ThisApplicationCompletePar_AS(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
	context.setAttribute("fileName", "CSFPT_Validate_Text_ThisApplicationCompletePar_AS");
	driver.quit();
	break;	

case "CSFPT_Validate_input_FirstNameLastName_acknowledgeline_AS":
	context.setAttribute("fileName", "CSFPT_Validate_input_FirstNameLastName_acknowledgeline_AS");
	ClubStudio_1.TC_110_CSFPT_Validate_input_FirstNameLastName_acknowledgeline_AS(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_input_FirstNameLastName_acknowledgeline_AS");
	driver.quit();
	break;	

case "CSFPT_Validate_text_Iacknowledge_AS":
	context.setAttribute("fileName", "CSFPT_Validate_text_Iacknowledge_AS");
	ClubStudio_1.TC_111_CSFPT_Validate_text_Iacknowledge_AS(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_text_Iacknowledge_AS");
	driver.quit();
	break;	


case "CSFPT_Validate_Previbtn_AS":
	context.setAttribute("fileName", "CSFPT_Validate_Previbtn_AS");
	ClubStudio_1.TC_112_CSFPT_Validate_Previbtn_AS(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Previbtn_AS");
	driver.quit();
	break;	

case "CSFPT_Validate_Nextbtn_AS":
	context.setAttribute("fileName", "CSFPT_Validate_Nextbtn_AS");
	ClubStudio_1.TC_113_CSFPT_Validate_Nextbtn_AS(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Nextbtn_AS");
	driver.quit();
	break;	

case "CSFPT_Validate_Text_ArbitationnDispute_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Text_ArbitationnDispute_AandD");
	ClubStudio_1.TC_114_CSFPT_Validate_Text_ArbitationnDispute_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Text_ArbitationnDispute_AandD");
	driver.quit();
	break;	
	
case "CSFPT_Validate_Text_Asaconditionofconsideration_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Text_Asaconditionofconsideration_AandD");
	ClubStudio_1.TC_115_CSFPT_Validate_Text_Asaconditionofconsideration_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Text_Asaconditionofconsideration_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_Link_DisputeResolutionRulesandProcedures_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Link_DisputeResolutionRulesandProcedures_AandD");
	ClubStudio_1.TC_116_CSFPT_Validate_Link_DisputeResolutionRulesandProcedures_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Link_DisputeResolutionRulesandProcedures_AandD");
	driver.quit();
	break;

case "CSFPT_Validate_Text_FITNESSINTERNATIONAL_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Text_FITNESSINTERNATIONAL_AandD");
	ClubStudio_1.TC_117_CSFPT_Validate_Text_FITNESSINTERNATIONAL_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Text_FITNESSINTERNATIONAL_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_Text_IrecognizeThatDifferences_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Text_IrecognizeThatDifferences_AandD");
	ClubStudio_1.TC_118_CSFPT_Validate_Text_IrecognizeThatDifferences_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Text_IrecognizeThatDifferences_AandD");
	driver.quit();
	break;
	
	
case "CSFPT_Validate_Text_IunderstandthatifIdofile_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Text_IunderstandthatifIdofile_AandD");
	ClubStudio_1.TC_119_CSFPT_Validate_Text_IunderstandthatifIdofile_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Text_IunderstandthatifIdofile_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_Text_IFurtherUnderstandAgreeThat_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Text_IFurtherUnderstandAgreeThat_AandD");
	ClubStudio_1.TC_120_CSFPT_Validate_Text_IFurtherUnderstandAgreeThat_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Text_IFurtherUnderstandAgreeThat_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_Text_IHvReadThisAgreeAndUnderstand_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Text_IHvReadThisAgreeAndUnderstand_AandD");
	ClubStudio_1.TC_121_CSFPT_Validate_Text_IHvReadThisAgreeAndUnderstand_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Text_IHvReadThisAgreeAndUnderstand_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_Text_IAGreenAcknReceipt_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Text_IAGreenAcknReceipt_AandD");
	ClubStudio_1.TC_122_CSFPT_Validate_Text_IAGreenAcknReceipt_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Text_IAGreenAcknReceipt_AandD");
	driver.quit();
	break;
	
	
case "CSFPT_Validate_Text_DateweekMonth_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Text_DateweekMonth_AandD");
	ClubStudio_1.TC_123_CSFPT_Validate_Text_DateweekMonth_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Text_DateweekMonth_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_Text_PrintName_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Text_PrintName_AandD");
	ClubStudio_1.TC_124_CSFPT_Validate_Text_PrintName_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Text_PrintName_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_Text_FitnessInternatlLLCagreestofollow_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Text_FitnessInternatlLLCagreestofollow_AandD");
	ClubStudio_1.TC_125_CSFPT_Validate_Text_FitnessInternatlLLCagreestofollow_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Text_FitnessInternatlLLCagreestofollow_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_ImgSign_RobertBryant_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_ImgSign_RobertBryant_AandD");
	ClubStudio_1.TC_126_CSFPT_Validate_ImgSign_RobertBryant_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_ImgSign_RobertBryant_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_Text_ByClickingBelow_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Text_ByClickingBelow_AandD");
	ClubStudio_1.TC_127_CSFPT_Validate_Text_ByClickingBelow_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Text_ByClickingBelow_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_Previbtn_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Previbtn_AandD");
	ClubStudio_1.TC_128_CSFPT_Validate_Previbtn_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Previbtn_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_Btn_IAgree_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Btn_IAgree_AandD");
	ClubStudio_1.TC_129_CSFPT_Validate_Btn_IAgree_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Btn_IAgree_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_Text_UrSubmittionWasSuccessful_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Text_UrSubmittionWasSuccessful_AandD");
	ClubStudio_1.TC_130_CSFPT_Validate_Text_UrSubmittionWasSuccessful_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Text_UrSubmittionWasSuccessful_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_Text_ThankUforUrIntrest_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Text_ThankUforUrIntrest_AandD");
	ClubStudio_1.TC_131_CSFPT_Validate_Text_ThankUforUrIntrest_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Text_ThankUforUrIntrest_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_Text_FitnessInternatiolLLC_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Text_FitnessInternatiolLLC_AandD");
	ClubStudio_1.TC_132_CSFPT_Validate_Text_FitnessInternatiolLLC_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Text_FitnessInternatiolLLC_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_Btn_PrintUrApplication_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Btn_PrintUrApplication_AandD");
	ClubStudio_1.TC_133_CSFPT_Validate_Btn_PrintUrApplication_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Btn_PrintUrApplication_AandD");
	driver.quit();
	break;
	
case "CSFPT_Validate_Last_Page_AandD":
	context.setAttribute("fileName", "CSFPT_Validate_Last_Page_AandD");
	ClubStudio_1.TC_134_CSFPT_Validate_Last_Page_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
	context.setAttribute("fileName", "CSFPT_Validate_Last_Page_AandD");
	driver.quit();
	break;
								


case "CSFCS4_Validate_text_EmploymentApplication_EA":
	
	context.setAttribute("fileName", "CSFCS4_Validate_text_EmploymentApplication_EA");
	ClubStudio_1.TC_01_CSFCS4_Validate_text_EmploymentApplication_EA(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFCS4_Validate_text_EmploymentApplication_EA");
	driver.quit();
	break;

case "CSFCS4_Validate_Text_Below_EmploymentApp_EA":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_Below_EmploymentApp_EA");
	ClubStudio_1.TC_02_CSFCS4_Validate_Text_Below_EmploymentApp_EA(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_Below_EmploymentApp_EA");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_AppInfo_ContandLocInfo_EA":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_AppInfo_ContandLocInfo_EA");
	ClubStudio_1.TC_03_CSFCS4_Validate_Text_AppInfo_ContandLocInfo_EA(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_AppInfo_ContandLocInfo_EA");
	driver.quit();
	break;

case "CSFCS4_Validate_mandatoryFields_EA":
	
	context.setAttribute("fileName", "CSFCS4_Validate_mandatoryFields_EA");
	ClubStudio_1.TC_04_CSFCS4_Validate_mandatoryFields_EA(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFCS4_Validate_mandatoryFields_EA");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Dropdownvalues_HowDidUhearUs_EA":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Dropdownvalues_HowDidUhearUs_EA");
	ClubStudio_1.TC_05_CSFCS4_Validate_Dropdownvalues_HowDidUhearUs_EA(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
	context.setAttribute("fileName", "CSFCS4_Validate_Dropdownvalues_HowDidUhearUs_EA");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Radiobutton_RU18_EA":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Radiobutton_RU18_EA");
	ClubStudio_1.TC_06_CSFCS4_Validate_Radiobutton_RU18_EA(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
	context.setAttribute("fileName", "CSFCS4_Validate_Radiobutton_RU18_EA");
	driver.quit();
	break;
	
case "CSFCS4_validate_Text_FormatUSCanada_EA":
	
	context.setAttribute("fileName", "CSFCS4_validate_Text_FormatUSCanada_EA");
	ClubStudio_1.TC_07_CSFCS4_validate_Text_FormatUSCanada_EA(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
	context.setAttribute("fileName", "CSFCS4_validate_Text_FormatUSCanada_EA");
	driver.quit();	
	break;
	
case "CSFCS4_validate_Text_Miles_EA":
	
	context.setAttribute("fileName", "CSFCS4_validate_Text_Miles_EA");
	ClubStudio_1.TC_08_CSFCS4_validate_Text_Miles_EA(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
	context.setAttribute("fileName", "CSFCS4_validate_Text_Miles_EA");
	driver.quit();
	break;

case "CSFCS4_Validate_ErrorMsg_CellPhone_EA":
	
	context.setAttribute("fileName", "CSFCS4_Validate_ErrorMsg_CellPhone_EA");
	ClubStudio_1.TC_09_CSFCS4_Validate_ErrorMsg_CellPhone_EA(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
	context.setAttribute("fileName", "CSFCS4_Validate_ErrorMsg_CellPhone_EA");
	driver.quit();
	break;

case "CSFCS4_Validate_Field_Input_EA":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Field_Input_EA");
	ClubStudio_1.TC_10_CSFCS4_Validate_Field_Input_EA(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode);
	context.setAttribute("fileName", "CSFCS4_Validate_Field_Input_EA");
	driver.quit();
	break;

case "CSFCS4_Validate_Button_NextStep_EA":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Button_NextStep_EA");
	ClubStudio_1.TC_11_CSFCS4_Validate_Button_NextStep_EA(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode);
	context.setAttribute("fileName", "CSFCS4_Validate_Button_NextStep_EA");
	driver.quit();
	break;
	
case "CSFCS4_Validate_url_CSF":

context.setAttribute("fileName", "CSFCS4_Validate_url_CSF");
ClubStudio_1.TC_12_CSFCS4_Validate_url_CSF(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
context.setAttribute("fileName", "CSFCS4_Validate_url_CSF");
driver.quit();
break;


case "CSFCS4_Verify_YouMustBe18Years_popup_OnselectingRaiodNo":

context.setAttribute("fileName", "CSFCS4_Verify_YouMustBe18Years_popup_OnselectingRaiodNo");
ClubStudio_1.TC_13_CSFCS4_Verify_YouMustBe18Years_popup_OnselectingRaiodNo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
context.setAttribute("fileName", "CSFCS4_Verify_YouMustBe18Years_popup_OnselectingRaiodNo");
driver.quit();
break;


case "CSFCS4_Validate_ClubsinurRadius":

context.setAttribute("fileName", "CSFCS4_Validate_ClubsinurRadius");
ClubStudio_1.TC_14_CSFCS4_Validate_ClubsinurRadius(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
context.setAttribute("fileName", "CSFCS4_Validate_ClubsinurRadius");
driver.quit();
break;

case "CSFCS4_Validate_Nextbutton_ClickofApplicantinfo":

context.setAttribute("fileName", "CSFCS4_Validate_Nextbutton_ClickofApplicantinfo");
ClubStudio_1.TC_15_CSFCS4_Validate_Nextbutton_ClickofApplicantinfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode);
context.setAttribute("fileName", "CSFCS4_Validate_Nextbutton_ClickofApplicantinfo");
driver.quit();
break;

case "CSFCS4_Validate_Text_EducationInfo":

context.setAttribute("fileName", "CSFCS4_Validate_Text_EducationInfo");
ClubStudio_1.TC_16_CSFCS4_Validate_Text_EducationInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
context.setAttribute("fileName", "CSFCS4_Validate_Text_EducationInfo");
driver.quit();
break;

case "CSFCS4_Validate_Field_EducationLevel":

context.setAttribute("fileName", "CSFCS4_Validate_Field_EducationLevel");
ClubStudio_1.TC_17_CSFCS4_Validate_Field_EducationLevel(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
context.setAttribute("fileName", "CSFCS4_Validate_Field_EducationLevel");
driver.quit();
break;


case "CSFCS4_Validate_DropdownValues_EducationLevel":

context.setAttribute("fileName", "CSFCS4_Validate_DropdownValues_EducationLevel");
ClubStudio_1.TC_18_CSFCS4_Validate_DropdownValues_EducationLevel(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFCS4_Validate_DropdownValues_EducationLevel");
driver.quit();
break;

case "CSFCS4_Validate_EducationLevel_ButtonsPerviousNext":

context.setAttribute("fileName", "CSFCS4_Validate_EducationLevel_ButtonsPerviousNext");
ClubStudio_1.TC_19_CSFCS4_Validate_EducationLevel_ButtonsPerviousNext(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFCS4_Validate_EducationLevel_ButtonsPerviousNext");
driver.quit();
break;


case "CSFCS4_Validate_PreviousPage_ClickofELPreviousbutton":

context.setAttribute("fileName", "CSFCS4_Validate_PreviousPage_ClickofELPreviousbutton");
ClubStudio_1.TC_20_CSFCS4_Validate_PreviousPage_ClickofELPreviousbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFCS4_Validate_PreviousPage_ClickofELPreviousbutton");
driver.quit();
break;

case "CSFCS4_Validate_NextPage_ClickofELNextbutton":

context.setAttribute("fileName", "CSFCS4_Validate_NextPage_ClickofELNextbutton");
ClubStudio_1.TC_21_CSFCS4_Validate_NextPage_ClickofELNextbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input, E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFCS4_Validate_NextPage_ClickofELNextbutton");
driver.quit();
break;


case "CSFCS4_Validate_EducationInfo_ClickofNextbutton":

context.setAttribute("fileName", "CSFCS4_Validate_EducationInfo_ClickofNextbutton");
ClubStudio_1.TC_22_CSFCS4_Validate_EducationInfo_ClickofNextbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFCS4_Validate_EducationInfo_ClickofNextbutton");
driver.quit();
break;


case "CSFCS4_Validate_Text_ExperienceInformation_ExpInfo":

context.setAttribute("fileName", "CSFCS4_Validate_Text_ExperienceInformation_ExpInfo");
ClubStudio_1.TC_23_CSFCS4_Validate_Text_ExperienceInformation_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFCS4_Validate_Text_ExperienceInformation_ExpInfo");
driver.quit();
break;


case "CSFCS4_Validate_Text_ExperienceDetail_ExperienceInfo":

context.setAttribute("fileName", "CSFCS4_Validate_Text_ExperienceDetail_ExperienceInfo");
ClubStudio_1.TC_24_CSFCS4_Validate_Text_ExperienceDetail_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFCS4_Validate_Text_ExperienceDetail_ExperienceInfo");
driver.quit();
break;


case "CSFCS4_Validate_Text_GroupFitness_ExperienceInfo":

context.setAttribute("fileName", "CSFCS4_Validate_Text_GroupFitness_ExperienceInfo");
ClubStudio_1.TC_25_CSFCS4_Validate_Text_GroupFitness_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
context.setAttribute("fileName", "CSFCS4_Validate_Text_GroupFitness_ExperienceInfo");
driver.quit();
break;

case "CSFCS4_Validate_Text_GroupFitnessAero_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_GroupFitnessAero_ExperienceInfo");
	ClubStudio_1.TC_26_CSFCS4_Validate_Text_GroupFitnessAero_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_GroupFitnessAero_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Fields_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Fields_ExperienceInfo");
	ClubStudio_1.TC_27_CSFCS4_Validate_Fields_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFCS4_Validate_Fields_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_DDValues_GroupFitnessAero_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_GroupFitnessAero_ExperienceInfo");
	ClubStudio_1.TC_28_CSFCS4_Validate_DDValues_GroupFitnessAero_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_GroupFitnessAero_ExperienceInfo");
	driver.quit();
	break;
							
case "CSFCS4_Validate_RadioBtn_DoUcurrentlyHold_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_RadioBtn_DoUcurrentlyHold_ExperienceInfo");
	ClubStudio_1.TC_29_CSFCS4_Validate_RadioBtn_DoUcurrentlyHold_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_RadioBtn_DoUcurrentlyHold_ExperienceInfo");
	driver.quit();
	break;

case "CSFCS4_Validate_Link_GroupFitness_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Link_GroupFitness_ExperienceInfo");
	ClubStudio_1.TC_30_CSFCS4_Validate_Link_GroupFitness_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Link_GroupFitness_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_AerobicCertif_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_AerobicCertif_ExperienceInfo");
	ClubStudio_1.TC_31_CSFCS4_Validate_Text_AerobicCertif_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_AerobicCertif_ExperienceInfo");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Btn_AddCertificate_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_AddCertificate_ExperienceInfo");
	ClubStudio_1.TC_32_CSFCS4_Validate_Btn_AddCertificate_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_AddCertificate_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Fields_OnclickOfYesradio_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Fields_OnclickOfYesradio_ExperienceInfo");
	ClubStudio_1.TC_33_CSFCS4_Validate_Fields_OnclickOfYesradio_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Fields_OnclickOfYesradio_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_DDValues_CertifiedIn_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_CertifiedIn_ExperienceInfo");
	ClubStudio_1.TC_34_CSFCS4_Validate_DDValues_CertifiedIn_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD);
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_CertifiedIn_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Aqua_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Aqua_ExperienceInfo");
	ClubStudio_1.TC_35_CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Aqua_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Aqua_ExperienceInfo");
	driver.quit();
	break;


case "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Cycle_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Cycle_ExperienceInfo");
	ClubStudio_1.TC_36_CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Cycle_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Cycle_ExperienceInfo");
	driver.quit();
	break;

case "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Dance_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Dance_ExperienceInfo");
	ClubStudio_1.TC_37_CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Dance_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Dance_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_GroupFitness_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_GroupFitness_ExperienceInfo");
	ClubStudio_1.TC_38_CSFCS4_Validate_DDValues_IssedBy_OnSelecting_GroupFitness_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_GroupFitness_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Kickboxing_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Kickboxing_ExperienceInfo");
	ClubStudio_1.TC_39_CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Kickboxing_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Kickboxing_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_MatPilatesBy_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_MatPilatesBy_ExperienceInfo");
	ClubStudio_1.TC_40_CSFCS4_Validate_DDValues_IssedBy_OnSelecting_MatPilatesBy_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_MatPilatesBy_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Yoga_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Yoga_ExperienceInfo");
	ClubStudio_1.TC_41_CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Yoga_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_IssedBy_OnSelecting_Yoga_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_CertificateFiles_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_CertificateFiles_ExperienceInfo");
	ClubStudio_1.TC_42_CSFCS4_Validate_Text_CertificateFiles_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_CertificateFiles_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Btn_ChooseFile_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_ChooseFile_ExperienceInfo");
	ClubStudio_1.TC_43_CSFCS4_Validate_Btn_ChooseFile_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_ChooseFile_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_FieldInputs_OnClickOfYes_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_FieldInputs_OnClickOfYes_ExperienceInfo");
	ClubStudio_1.TC_44_CSFCS4_Validate_FieldInputs_OnClickOfYes_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_FieldInputs_OnClickOfYes_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_OnClickOfAddCertificate_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_OnClickOfAddCertificate_ExperienceInfo");
	ClubStudio_1.TC_45_CSFCS4_Validate_OnClickOfAddCertificate_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_OnClickOfAddCertificate_ExperienceInfo");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_OnClickOfRemove_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_OnClickOfRemove_ExperienceInfo");
	ClubStudio_1.TC_46_CSFCS4_Validate_OnClickOfRemove_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_OnClickOfRemove_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_PopUp_NoMorethen4_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_PopUp_NoMorethen4_ExperienceInfo");
	ClubStudio_1.TC_47_CSFCS4_Validate_PopUp_NoMorethen4_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_PopUp_NoMorethen4_ExperienceInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_text_GroupFitnessAero_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_text_GroupFitnessAero_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_48_CSFCS4_Validate_text_GroupFitnessAero_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_text_GroupFitnessAero_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_text_PlzIdentify_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_text_PlzIdentify_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_49_CSFCS4_Validate_text_PlzIdentify_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_text_PlzIdentify_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Fields_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Fields_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_50_CSFCS4_Validate_Fields_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Fields_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_DDV_OfTimeperiod_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_DDV_OfTimeperiod_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_51_CSFCS4_Validate_DDV_OfTimeperiod_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD);
	context.setAttribute("fileName", "CSFCS4_Validate_DDV_OfTimeperiod_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_DDV_OfClubEMp_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_DDV_OfClubEMp_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_52_CSFCS4_Validate_DDV_OfClubEMp_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD);
	context.setAttribute("fileName", "CSFCS4_Validate_DDV_OfClubEMp_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_FieldInput_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_FieldInput_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_53_CSFCS4_Validate_FieldInput_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD,Class_per_week);
	context.setAttribute("fileName", "CSFCS4_Validate_FieldInput_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_CB_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_CB_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_54_CSFCS4_Validate_CB_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD,Class_per_week);
	context.setAttribute("fileName", "CSFCS4_Validate_CB_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_CheckofCB_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_CheckofCB_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_55_CSFCS4_Validate_CheckofCB_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD,Class_per_week);
	context.setAttribute("fileName", "CSFCS4_Validate_CheckofCB_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_text_ClassFormat_OnSelectingGroupFit_ExpInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_text_ClassFormat_OnSelectingGroupFit_ExpInfo");
	ClubStudio_1.TC_56_CSFCS4_Validate_text_ClassFormat_OnSelectingGroupFit_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD,Class_per_week);
	context.setAttribute("fileName", "CSFCS4_Validate_text_ClassFormat_OnSelectingGroupFit_ExpInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_newaddemplsection_onClickofAddEmpBtn_ExpInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_newaddemplsection_onClickofAddEmpBtn_ExpInfo");
	ClubStudio_1.TC_57_CSFCS4_Validate_newaddemplsection_onClickofAddEmpBtn_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD,Class_per_week);
	context.setAttribute("fileName", "CSFCS4_Validate_newaddemplsection_onClickofAddEmpBtn_ExpInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_RemovalofAddEmpsectio_onClickofRemoveBtn_ExpInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_RemovalofAddEmpsectio_onClickofRemoveBtn_ExpInfo");
	ClubStudio_1.TC_58_CSFCS4_Validate_RemovalofAddEmpsectio_onClickofRemoveBtn_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD,Class_per_week);
	context.setAttribute("fileName", "CSFCS4_Validate_RemovalofAddEmpsectio_onClickofRemoveBtn_ExpInfo");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Popup_Nomorethan3Employers_ExpInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Popup_Nomorethan3Employers_ExpInfo");
	ClubStudio_1.TC_59_CSFCS4_Validate_Popup_Nomorethan3Employers_ExpInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,Time_period_DD,Club_Employer_DD,Class_per_week);
	context.setAttribute("fileName", "CSFCS4_Validate_Popup_Nomorethan3Employers_ExpInfo");
	driver.quit();
	break;
	
		
	
	
case "CSFCS4_Validate_Text_EducationInformation_OnClickoFPrevStepbtn_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_EducationInformation_OnClickoFPrevStepbtn_ExperienceInfo");
	ClubStudio_1.TC_60_CSFCS4_Validate_Text_EducationInformation_OnClickoFPrevStepbtn_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_EducationInformation_OnClickoFPrevStepbtn_ExperienceInfo");
	driver.quit();
	break;


case "CSFCS4_Validate_OnClickoFNextStepbtn_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_OnClickoFNextStepbtn_ExperienceInfo");
	ClubStudio_1.TC_61_CSFCS4_Validate_OnClickoFNextStepbtn_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_OnClickoFNextStepbtn_ExperienceInfo");
	driver.quit();
	break;	

	
case "CSFCS4_Validate_Text_EmploymentHistory_OnClickoFNextStepbtn_ExperienceInfo":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_EmploymentHistory_OnClickoFNextStepbtn_ExperienceInfo");
	ClubStudio_1.TC_62_CSFCS4_Validate_Text_EmploymentHistory_OnClickoFNextStepbtn_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_EmploymentHistory_OnClickoFNextStepbtn_ExperienceInfo");
	driver.quit();
	break;

case "CSFCS4_Validate_Text_PreviousEmployment_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_PreviousEmployment_EmploymentHistory");
	ClubStudio_1.TC_63_CSFCS4_Validate_Text_PreviousEmployment_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_PreviousEmployment_EmploymentHistory");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory");
	ClubStudio_1.TC_64_CSFCS4_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Field_EmploymentGapExp_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Field_EmploymentGapExp_EmploymentHistory");
	ClubStudio_1.TC_65_CSFCS4_Validate_Field_EmploymentGapExp_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Field_EmploymentGapExp_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Field_IWillUploadMyResume_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Field_IWillUploadMyResume_EmploymentHistory");
	ClubStudio_1.TC_66_CSFCS4_Validate_Field_IWillUploadMyResume_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Field_IWillUploadMyResume_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory");
	ClubStudio_1.TC_67_CSFCS4_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory");
	ClubStudio_1.TC_68_CSFCS4_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory");
	ClubStudio_1.TC_69_CSFCS4_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory");
	driver.quit();
	break;
	
case "CSFCS4_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory");
	ClubStudio_1.TC_70_CSFCS4_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Text_EnterEmpHistory_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_EnterEmpHistory_EmploymentHistory");
	ClubStudio_1.TC_71_CSFCS4_Validate_Text_EnterEmpHistory_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_EnterEmpHistory_EmploymentHistory");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_PreviousEmployer1_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_PreviousEmployer1_EmploymentHistory");
	ClubStudio_1.TC_72_CSFCS4_Validate_Text_PreviousEmployer1_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_PreviousEmployer1_EmploymentHistory");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory");
	ClubStudio_1.TC_73_CSFCS4_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues);
	context.setAttribute("fileName", "CSFCS4_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory");
	ClubStudio_1.TC_74_CSFCS4_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory");
	ClubStudio_1.TC_75_CSFCS4_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory");
	ClubStudio_1.TC_76_CSFCS4_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_RadioOptions_CanbeContacted_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_RadioOptions_CanbeContacted_EmploymentHistory");
	ClubStudio_1.TC_77_CSFCS4_Validate_RadioOptions_CanbeContacted_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_RadioOptions_CanbeContacted_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Btn_AddEmployer2_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_AddEmployer2_EmploymentHistory");
	ClubStudio_1.TC_78_CSFCS4_Validate_Btn_AddEmployer2_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_AddEmployer2_EmploymentHistory");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory");
	ClubStudio_1.TC_79_CSFCS4_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory");
	ClubStudio_1.TC_80_CSFCS4_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory");
	ClubStudio_1.TC_81_CSFCS4_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory");
	ClubStudio_1.TC_82_CSFCS4_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory");
	ClubStudio_1.TC_83_CSFCS4_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory");
	driver.quit();
	break;
	
case "CSFCS4_Validate_OnClick_RemoveEmp3_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_OnClick_RemoveEmp3_EmploymentHistory");
	ClubStudio_1.TC_84_CSFCS4_Validate_OnClick_RemoveEmp3_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_OnClick_RemoveEmp3_EmploymentHistory");
	driver.quit();
	break;
	

case "CSFCS4_Validate_OnClick_RemoveEmp2_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_OnClick_RemoveEmp2_EmploymentHistory");
	ClubStudio_1.TC_85_CSFCS4_Validate_OnClick_RemoveEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_OnClick_RemoveEmp2_EmploymentHistory");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory");
	ClubStudio_1.TC_86_CSFCS4_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_onClickNextbtn_EmploymentHistory":
	
	context.setAttribute("fileName", "CSFCS4_Validate_onClickNextbtn_EmploymentHistory");
	ClubStudio_1.TC_87_CSFCS4_Validate_onClickNextbtn_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_onClickNextbtn_EmploymentHistory");
	driver.quit();
	break;

case "CSFCS4_Validate_Text_LanguageSkills_LanguageSkills":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_LanguageSkills_LanguageSkills");
	ClubStudio_1.TC_88_CSFCS4_Validate_Text_LanguageSkills_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_LanguageSkills_LanguageSkills");
	driver.quit();
	break;

case "CSFCS4_Validate_Text_IncicateLang_LanguageSkills":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_IncicateLang_LanguageSkills");
	ClubStudio_1.TC_89_CSFCS4_Validate_Text_IncicateLang_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_IncicateLang_LanguageSkills");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Languages_LanguageSkills":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Languages_LanguageSkills");
	ClubStudio_1.TC_90_CSFCS4_Validate_Languages_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Languages_LanguageSkills");
	driver.quit();
	break;
	
case "CSFCS4_Validate_OnClickPrvBtn_LanguageSkills":
	
	context.setAttribute("fileName", "CSFCS4_Validate_OnClickPrvBtn_LanguageSkills");
	ClubStudio_1.TC_91_CSFCS4_Validate_OnClickPrvBtn_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_OnClickPrvBtn_LanguageSkills");
	driver.quit();
	break;
	
case "CSFCS4_Validate_OnClickNextBtn_LanguageSkills":
	
	context.setAttribute("fileName", "CSFCS4_Validate_OnClickNextBtn_LanguageSkills");
	ClubStudio_1.TC_92_CSFCS4_Validate_OnClickNextBtn_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_OnClickNextBtn_LanguageSkills");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_CareerOptions_CareerOption":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_CareerOptions_CareerOption");
	ClubStudio_1.TC_93_CSFCS4_Validate_Text_CareerOptions_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_CareerOptions_CareerOption");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Text_CrOpporUqualityfor_CareerOption":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_CrOpporUqualityfor_CareerOption");
	ClubStudio_1.TC_94_CSFCS4_Validate_Text_CrOpporUqualityfor_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_CrOpporUqualityfor_CareerOption");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Fieldson_CareerOption":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Fieldson_CareerOption");
	ClubStudio_1.TC_95_CSFCS4_Validate_Fieldson_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Fieldson_CareerOption");
	driver.quit();
	break;
	
case "CSFCS4_Validate_RadioPartTimeFulltime_CareerOption":
	
	context.setAttribute("fileName", "CSFCS4_Validate_RadioPartTimeFulltime_CareerOption");
	ClubStudio_1.TC_96_CSFCS4_Validate_RadioPartTimeFulltime_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_RadioPartTimeFulltime_CareerOption");
	driver.quit();
	break;
	
case "CSFCS4_Validate_CB_PilatiesTeacherDirector_CareerOption":
	
	context.setAttribute("fileName", "CSFCS4_Validate_CB_PilatiesTeacherDirector_CareerOption");
	ClubStudio_1.TC_97_CSFCS4_Validate_CB_PilatiesTeacherDirector_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_CB_PilatiesTeacherDirector_CareerOption");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption":
	
	context.setAttribute("fileName", "CSFCS4_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption");
	ClubStudio_1.TC_98_CSFCS4_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Text_BasedonURsele_CareerOption":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_BasedonURsele_CareerOption");
	ClubStudio_1.TC_99_CSFCS4_Validate_Text_BasedonURsele_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_BasedonURsele_CareerOption");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Text_IfSReQuestionnaire_CareerOption":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_IfSReQuestionnaire_CareerOption");
	ClubStudio_1.TC_100_CSFCS4_Validate_Text_IfSReQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_IfSReQuestionnaire_CareerOption");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_RehireQuestionnaire_CareerOption":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_RehireQuestionnaire_CareerOption");
	ClubStudio_1.TC_101_CSFCS4_Validate_Text_RehireQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_RehireQuestionnaire_CareerOption");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Fields_UnderRehireQuestionnaire_CareerOption":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Fields_UnderRehireQuestionnaire_CareerOption");
	ClubStudio_1.TC_102_CSFCS4_Validate_Fields_UnderRehireQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFCS4_Validate_Fields_UnderRehireQuestionnaire_CareerOption");
	driver.quit();
	break;
	
case "CSFCS4_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption":
	
	context.setAttribute("fileName", "CSFCS4_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption");
	ClubStudio_1.TC_103_CSFCS4_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSFCS4_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption");
	ClubStudio_1.TC_104_CSFCS4_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSFCS4_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption");
	driver.quit();
	break;

	
case "CSFCS4_Validate_OnClickPrvBtn_CareerOption":
	
	context.setAttribute("fileName", "CSFCS4_Validate_OnClickPrvBtn_CareerOption");
	ClubStudio_1.TC_105_CSFCS4_Validate_OnClickPrvBtn_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSFCS4_Validate_OnClickPrvBtn_CareerOption");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_OnClickNextBtn_CareerOption":
	
	context.setAttribute("fileName", "CSFCS4_Validate_OnClickNextBtn_CareerOption");
	ClubStudio_1.TC_106_CSFCS4_Validate_OnClickNextBtn_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSFCS4_Validate_OnClickNextBtn_CareerOption");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Text_EqualOpportunityEmpy_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_EqualOpportunityEmpy_EOE");
	ClubStudio_1.TC_107_CSFCS4_Validate_Text_EqualOpportunityEmpy_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_EqualOpportunityEmpy_EOE");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_TheCompanyisan_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_TheCompanyisan_EOE");
	ClubStudio_1.TC_108_CSFCS4_Validate_Text_TheCompanyisan_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_TheCompanyisan_EOE");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_CompletionOfForm_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_CompletionOfForm_EOE");
	ClubStudio_1.TC_109_CSFCS4_Validate_Text_CompletionOfForm_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_CompletionOfForm_EOE");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Fields_EqualOpportunityEmploymentSection_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_CompletionOfForm_EOE");
	ClubStudio_1.TC_110_CSFCS4_Validate_Fields_EqualOpportunityEmploymentSection_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason);
	context.setAttribute("fileName", "CSFCS4_Validate_Fields_EqualOpportunityEmploymentSection_EOE");
	driver.quit();
	break;
	
case "CSFCS4_Validate_DDValues_WtisUrGender_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_WtisUrGender_EOE");
	ClubStudio_1.TC_111_CSFCS4_Validate_DDValues_WtisUrGender_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5);
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_WtisUrGender_EOE");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_DDValues_WtyourRaceEthnicOrigin_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_WtyourRaceEthnicOrigin_EOE");
	ClubStudio_1.TC_112_CSFCS4_Validate_DDValues_WtyourRaceEthnicOrigin_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSFCS4_Validate_DDValues_WtyourRaceEthnicOrigin_EOE");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_HispanicorLatino_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_HispanicorLatino_EOE");
	ClubStudio_1.TC_113_CSFCS4_Validate_Text_HispanicorLatino_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_HispanicorLatino_EOE");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Text_WhiteNotHispanicorLatino_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_WhiteNotHispanicorLatino_EOE");
	ClubStudio_1.TC_114_CSFCS4_Validate_Text_WhiteNotHispanicorLatino_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_WhiteNotHispanicorLatino_EOE");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_BlackorAfricanAmerican_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_BlackorAfricanAmerican_EOE");
	ClubStudio_1.TC_115_CSFCS4_Validate_Text_BlackorAfricanAmerican_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_BlackorAfricanAmerican_EOE");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Text_NativeHawaiianorOtherPacific_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_NativeHawaiianorOtherPacific_EOE");
	ClubStudio_1.TC_116_CSFCS4_Validate_Text_NativeHawaiianorOtherPacific_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_NativeHawaiianorOtherPacific_EOE");
	driver.quit();
	break;	
	

case "CSFCS4_Validate_Text_AsianNotHispanicorLatino_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_AsianNotHispanicorLatino_EOE");
	ClubStudio_1.TC_117_CSFCS4_Validate_Text_AsianNotHispanicorLatino_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_AsianNotHispanicorLatino_EOE");
	driver.quit();
	break;	

case "CSFCS4_Validate_Text_AmericanIndianorAlaskanNative_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_AmericanIndianorAlaskanNative_EOE");
	ClubStudio_1.TC_118_CSFCS4_Validate_Text_AmericanIndianorAlaskanNative_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_AmericanIndianorAlaskanNative_EOE");
	driver.quit();
	break;	
	
case "CSFCS4_Validate_Text_Allpersonswho_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_Allpersonswho_EOE");
	ClubStudio_1.TC_119_CSFCS4_Validate_Text_Allpersonswho_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_Allpersonswho_EOE");
	driver.quit();
	break;	
	
case "CSFCS4_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE");
	ClubStudio_1.TC_120_CSFCS4_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSFCS4_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE");
	driver.quit();
	break;	
	
case "CSFCS4_Validate_Fieldinputs_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Fieldinputs_EOE");
	ClubStudio_1.TC_121_CSFCS4_Validate_Fieldinputs_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSFCS4_Validate_Fieldinputs_EOE");
	driver.quit();
	break;	
	
case "CSFCS4_Validate_PreviBtn_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_PreviBtn_EOE");
	ClubStudio_1.TC_122_CSFCS4_Validate_PreviBtn_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSFCS4_Validate_PreviBtn_EOE");
	driver.quit();
	break;	
	
case "CSFCS4_Validate_NextBtn_EOE":
	
	context.setAttribute("fileName", "CSFCS4_Validate_NextBtn_EOE");
	ClubStudio_1.TC_123_CSFCS4_Validate_NextBtn_EOE(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSFCS4_Validate_NextBtn_EOE");
	driver.quit();
	break;	
	
case "CSFCS4_Validate_Text_ApplicationStatement_AppliSatement":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_ApplicationStatement_AppliSatement");
	ClubStudio_1.TC_124_CSFCS4_Validate_Text_ApplicationStatement_AppliSatement(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_ApplicationStatement_AppliSatement");
	driver.quit();
	break;	
	
	
case "CSFCS4_Validate_Text_ThisApplicationCompleteParaOnApplicantStatement":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_ThisApplicationCompleteParaOnApplicantStatement");
	ClubStudio_1.TC_125_CSFCS4_Validate_Text_ThisApplicationCompleteParaOnApplicantStatement(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_ThisApplicationCompleteParaOnApplicantStatement");
	driver.quit();
	break;	
	
case "CSFCS4_Validate_input_FirstNameLastName_acknowledgelineofApplicantStatementpage":
	
	context.setAttribute("fileName", "CSFCS4_Validate_input_FirstNameLastName_acknowledgelineofApplicantStatementpage");
	ClubStudio_1.TC_126_CSFCS4_Validate_input_FirstNameLastName_acknowledgelineofApplicantStatementpage(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_input_FirstNameLastName_acknowledgelineofApplicantStatementpage");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_text_Iacknowledge_ApplicantStatementpage":
	
	context.setAttribute("fileName", "CSFCS4_Validate_text_Iacknowledge_ApplicantStatementpage");
	ClubStudio_1.TC_127_CSFCS4_Validate_text_Iacknowledge_ApplicantStatementpage(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_text_Iacknowledge_ApplicantStatementpage");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Previbtn_ApplicantStatementpage":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Previbtn_ApplicantStatementpage");
	ClubStudio_1.TC_128_CSFCS4_Validate_Previbtn_ApplicantStatementpage(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Previbtn_ApplicantStatementpage");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Nextbtn_ApplicantStatementpage":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Nextbtn_ApplicantStatementpage");
	ClubStudio_1.TC_129_CSFCS4_Validate_Nextbtn_ApplicantStatementpage(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Nextbtn_ApplicantStatementpage");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_ArbitationnDispute_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_ArbitationnDispute_AandD");
	ClubStudio_1.TC_130_CSFCS4_Validate_Text_ArbitationnDispute_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_ArbitationnDispute_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_Asaconditionofconsideration_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_Asaconditionofconsideration_AandD");
	ClubStudio_1.TC_131_CSFCS4_Validate_Text_Asaconditionofconsideration_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_Asaconditionofconsideration_AandD");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Link_DisputeResolutionRulesandProcedures_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Link_DisputeResolutionRulesandProcedures_AandD");
	ClubStudio_1.TC_132_CSFCS4_Validate_Link_DisputeResolutionRulesandProcedures_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Link_DisputeResolutionRulesandProcedures_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_FITNESSINTERNATIONAL_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_FITNESSINTERNATIONAL_AandD");
	ClubStudio_1.TC_133_CSFCS4_Validate_Text_FITNESSINTERNATIONAL_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_FITNESSINTERNATIONAL_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_IrecognizeThatDifferences_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_IrecognizeThatDifferences_AandD");
	ClubStudio_1.TC_134_CSFCS4_Validate_Text_IrecognizeThatDifferences_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_IrecognizeThatDifferences_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_IunderstandthatifIdofile_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_IunderstandthatifIdofile_AandD");
	ClubStudio_1.TC_135_CSFCS4_Validate_Text_IunderstandthatifIdofile_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_IunderstandthatifIdofile_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_IFurtherUnderstandAgreeThat_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_IFurtherUnderstandAgreeThat_AandD");
	ClubStudio_1.TC_136_CSFCS4_Validate_Text_IFurtherUnderstandAgreeThat_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_IFurtherUnderstandAgreeThat_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_IHaveReadThisAgreementAndUnderstand_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_IHaveReadThisAgreementAndUnderstand_AandD");
	ClubStudio_1.TC_137_CSFCS4_Validate_Text_IHaveReadThisAgreementAndUnderstand_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_IHaveReadThisAgreementAndUnderstand_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_IAGreenAcknReceipt_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_IAGreenAcknReceipt_AandD");
	ClubStudio_1.TC_138_CSFCS4_Validate_Text_IAGreenAcknReceipt_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_IAGreenAcknReceipt_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_DateweekMonth_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_DateweekMonth_AandD");
	ClubStudio_1.TC_139_CSFCS4_Validate_Text_DateweekMonth_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_DateweekMonth_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_PrintName_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_PrintName_AandD");
	ClubStudio_1.TC_140_CSFCS4_Validate_Text_PrintName_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_PrintName_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_FitnessInternationalLLCagreestofollow_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_FitnessInternationalLLCagreestofollow_AandD");
	ClubStudio_1.TC_141_CSFCS4_Validate_Text_FitnessInternationalLLCagreestofollow_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_FitnessInternationalLLCagreestofollow_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_ImgSign_RobertBryant_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_ImgSign_RobertBryant_AandD");
	ClubStudio_1.TC_142_CSFCS4_Validate_ImgSign_RobertBryant_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_ImgSign_RobertBryant_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_ByClickingBelow_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_ByClickingBelow_AandD");
	ClubStudio_1.TC_143_CSFCS4_Validate_Text_ByClickingBelow_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_ByClickingBelow_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Previbtn_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Previbtn_AandD");
	ClubStudio_1.TC_144_CSFCS4_Validate_Previbtn_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Previbtn_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Btn_IAgree_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_IAgree_AandD");
	ClubStudio_1.TC_145_CSFCS4_Validate_Btn_IAgree_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_IAgree_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Text_UrSubmittionWasSuccessful_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_UrSubmittionWasSuccessful_AandD");
	ClubStudio_1.TC_146_CSFCS4_Validate_Text_UrSubmittionWasSuccessful_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_UrSubmittionWasSuccessful_AandD");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Text_ThankUforUrIntrest_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_ThankUforUrIntrest_AandD");
	ClubStudio_1.TC_147_CSFCS4_Validate_Text_ThankUforUrIntrest_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_ThankUforUrIntrest_AandD");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Text_FitnessInternatiolLLC_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Text_FitnessInternatiolLLC_AandD");
	ClubStudio_1.TC_148_CSFCS4_Validate_Text_FitnessInternatiolLLC_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Text_FitnessInternatiolLLC_AandD");
	driver.quit();
	break;
	
	
case "CSFCS4_Validate_Btn_PrintUrApplication_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_PrintUrApplication_AandD");
	ClubStudio_1.TC_149_CSFCS4_Validate_Btn_PrintUrApplication_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Btn_PrintUrApplication_AandD");
	driver.quit();
	break;
	
case "CSFCS4_Validate_Last_Page_AandD":
	
	context.setAttribute("fileName", "CSFCS4_Validate_Last_Page_AandD");
	ClubStudio_1.TC_150_CSFCS4_Validate_Last_Page_AandD(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certified_In_DD,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name);
	context.setAttribute("fileName", "CSFCS4_Validate_Last_Page_AandD");
	driver.quit();
	break;

	
	//---------Club Studio Club Pride----------------------------------------------------
	
	
case "CSFPride_Validate_Btn_ApplyHere":
	context.setAttribute("fileName", "CSFPride_Validate_Btn_ApplyHere");
	ClubStudio_1.TC_01_CSFPride_Validate_Btn_ApplyHere(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFPride_Validate_Btn_ApplyHere");
	driver.quit();
	break;
	
case "CSFPride_Validate_text_EmploymentApplication":
	context.setAttribute("fileName", "CSFPride_Validate_text_EmploymentApplication");
	ClubStudio_1.TC_02_CSFPride_Validate_text_EmploymentApplication(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFPride_Validate_text_EmploymentApplication");
	driver.quit();
	break;

case "CSFPride_Validate_Text_Below_EmploymentApp":
	context.setAttribute("fileName", "CSFPride_Validate_Text_Below_EmploymentApp");
	ClubStudio_1.TC_03_CSFPride_Validate_Text_Below_EmploymentApp(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFPride_Validate_Text_Below_EmploymentApp");
	driver.quit();
	break;

	

case "CSFPride_Validate_Text_AppInfo_ContandLocInfo":
	context.setAttribute("fileName", "CSFPride_Validate_Text_AppInfo_ContandLocInfo");
	ClubStudio_1.TC_05_CSFPride_Validate_Text_AppInfo_ContandLocInfo(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFPride_Validate_Text_AppInfo_ContandLocInfo");
	driver.quit();
	break;

case "CSFPride_Validate_mandatoryFields_EmploymentApplication":
	context.setAttribute("fileName", "CSFPride_Validate_mandatoryFields_EmploymentApplication");
	ClubStudio_1.TC_06_CSFPride_Validate_mandatoryFields_EmploymentApplication(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFPride_Validate_mandatoryFields_EmploymentApplication");
	driver.quit();
	break;

case "CSFPride_Validate_Dropdownvalues_HowDidUhearUs":
	context.setAttribute("fileName", "CSFPride_Validate_Dropdownvalues_HowDidUhearUs");
	ClubStudio_1.TC_07_CSFPride_Validate_Dropdownvalues_HowDidUhearUs(testdata.get("TextMessage").toString(),Dropdown_values);
	context.setAttribute("fileName", "CSFPride_Validate_Dropdownvalues_HowDidUhearUs");
	driver.quit();
	break;
	
case "CSFPride_Validate_Radiobutton_RU18":
	context.setAttribute("fileName", "CSFPride_Validate_Radiobutton_RU18");
	ClubStudio_1.TC_08_CSFPride_Validate_Radiobutton_RU18(testdata.get("TextMessage").toString(),Dropdown_values);
	context.setAttribute("fileName", "CSFPride_Validate_Radiobutton_RU18");
	driver.quit();
	break;	
	
case "CSFPride_validate_Text_FormatUSCanada":
	context.setAttribute("fileName", "CSFPride_validate_Text_FormatUSCanada");
	ClubStudio_1.TC_09_CSFPride_validate_Text_FormatUSCanada(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFPride_validate_Text_FormatUSCanada");
	driver.quit();
	break;	

case "CSFPride_validate_Text_Miles":
	context.setAttribute("fileName", "CSFPride_validate_Text_Miles");
	ClubStudio_1.TC_10_CSFPride_validate_Text_Miles(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFPride_validate_Text_Miles");
	driver.quit();
	break;	
	
	

case "CSFPride_Validate_ErrorMsg_CellPhone":
	context.setAttribute("fileName", "CSFPride_Validate_ErrorMsg_CellPhone");
	ClubStudio_1.TC_11_CSFPride_Validate_ErrorMsg_CellPhone(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFPride_Validate_ErrorMsg_CellPhone");
	driver.quit();
	break;	
	
case "CSFPride_Validate_Field_Input_EmploymentApplication":
	context.setAttribute("fileName", "CSFPride_Validate_Field_Input_EmploymentApplication");
	ClubStudio_1.TC_12_CSFPride_Validate_Field_Input_EmploymentApplication(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode);
	context.setAttribute("fileName", "CSFPride_Validate_Field_Input_EmploymentApplication");
	driver.quit();
	break;	
	
case "CSFPride_Validate_Button_NextStep":
	context.setAttribute("fileName", "CSFPride_Validate_Button_NextStep");
	ClubStudio_1.TC_13_CSFPride_Validate_Button_NextStep(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode);
	context.setAttribute("fileName", "CSFPride_Validate_Button_NextStep");
	driver.quit();
	break;	
	
case "CSFPride_Validate_url_clickApplyHere":
	context.setAttribute("fileName", "CSFPride_Validate_url_clickApplyHere");
	ClubStudio_1.TC_14_CSFPride_Validate_url_clickApplyHere(testdata.get("TextMessage").toString(),Text_input);
	context.setAttribute("fileName", "CSFPride_Validate_url_clickApplyHere");
	driver.quit();
	break;	

case "CSFPride_Verify_YouMustBe18Years_popup_OnselectingRaiodNo":
	context.setAttribute("fileName", "CSFPride_Verify_YouMustBe18Years_popup_OnselectingRaiodNo");
	ClubStudio_1.TC_15_CSFPride_Verify_YouMustBe18Years_popup_OnselectingRaiodNo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode);
	context.setAttribute("fileName", "CSFPride_Verify_YouMustBe18Years_popup_OnselectingRaiodNo");
	driver.quit();
	break;	


case "CSFPride_Validate_ClubsinurRadius":
	context.setAttribute("fileName", "CSFPride_Validate_ClubsinurRadius");
	ClubStudio_1.TC_16_CSFPride_Validate_ClubsinurRadius(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode);
	context.setAttribute("fileName", "CSFPride_Validate_ClubsinurRadius");
	driver.quit();
	break;	

case "CSFPride_Validate_Nextbutton_ClickofApplicantinfo":
	context.setAttribute("fileName", "CSFPride_Validate_Nextbutton_ClickofApplicantinfo");
	ClubStudio_1.TC_17_CSFPride_Validate_Nextbutton_ClickofApplicantinfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode);
	context.setAttribute("fileName", "CSFPride_Validate_Nextbutton_ClickofApplicantinfo");
	driver.quit();
	break;	

case "CSFPride_Validate_Text_EducationInfo":
	context.setAttribute("fileName", "CSFPride_Validate_Text_EducationInfo");
	ClubStudio_1.TC_18_CSFPride_Validate_Text_EducationInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
	context.setAttribute("fileName", "CSFPride_Validate_Text_EducationInfo");
	driver.quit();
	break;	

	
case "CSFPride_Validate_Field_EducationLevel":
	context.setAttribute("fileName", "CSFPride_Validate_Field_EducationLevel");
	ClubStudio_1.TC_19_CSFPride_Validate_Field_EducationLevel(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input);
	context.setAttribute("fileName", "CSFPride_Validate_Field_EducationLevel");
	driver.quit();
	break;	
	
	
case "CSFPride_Validate_DropdownValues_EducationLevel":
	context.setAttribute("fileName", "CSFPride_Validate_DropdownValues_EducationLevel");
	ClubStudio_1.TC_20_CSFPride_Validate_DropdownValues_EducationLevel(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_DropdownValues_EducationLevel");
	driver.quit();
	break;	
	
case "CSFPride_Validate_EducationLevel_ButtonsPerviousNext":
	context.setAttribute("fileName", "CSFPride_Validate_EducationLevel_ButtonsPerviousNext");
	ClubStudio_1.TC_21_CSFPride_Validate_EducationLevel_ButtonsPerviousNext(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_EducationLevel_ButtonsPerviousNext");
	driver.quit();
	break;	
	
case "CSFPride_Validate_PreviousPage_ClickofELPreviousbutton":
	context.setAttribute("fileName", "CSFPride_Validate_PreviousPage_ClickofELPreviousbutton");
	ClubStudio_1.TC_22_CSFPride_Validate_PreviousPage_ClickofELPreviousbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_PreviousPage_ClickofELPreviousbutton");
	driver.quit();
	break;				

case "CSFPride_Validate_NextPage_ClickofELNextbutton":
	context.setAttribute("fileName", "CSFPride_Validate_NextPage_ClickofELNextbutton");
	ClubStudio_1.TC_23_CSFPride_Validate_NextPage_ClickofELNextbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_NextPage_ClickofELNextbutton");
	driver.quit();
	break;	

	
case "CSFPride_Validate_EducationInfo_ClickofNextbutton":
	context.setAttribute("fileName", "CSFPride_Validate_EducationInfo_ClickofNextbutton");
	ClubStudio_1.TC_24_CSFPride_Validate_EducationInfo_ClickofNextbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_EducationInfo_ClickofNextbutton");
	driver.quit();
	break;	
	
case "CSFPride_Validate_Text_ExperienceDetail_ExperienceInfo":
	context.setAttribute("fileName", "CSFPride_Validate_Text_ExperienceDetail_ExperienceInfo");
	ClubStudio_1.TC_25_CSFPride_Validate_Text_ExperienceDetail_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_ExperienceDetail_ExperienceInfo");
	driver.quit();
	break;	

case "CSFPride_Validate_Text_SalesnManagementExp_ExperienceInfo":
	context.setAttribute("fileName", "CSFPride_Validate_Text_SalesnManagementExp_ExperienceInfo");
	ClubStudio_1.TC_26_CSFPride_Validate_Text_SalesnManagementExp_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_SalesnManagementExp_ExperienceInfo");
	driver.quit();
	break;	


case "CSFPride_Validate_Fields_OnExperienceInfo":
	context.setAttribute("fileName", "CSFPride_Validate_Fields_OnExperienceInfo");
	ClubStudio_1.TC_27_CSFPride_Validate_Fields_OnExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Fields_OnExperienceInfo");
	driver.quit();
	break;	

case "CSFPride_Validate_Field_FitnessSalesExp_DD_ExperienceInfo":
	context.setAttribute("fileName", "CSFPride_Validate_Field_FitnessSalesExp_DD_ExperienceInfo");
	ClubStudio_1.TC_28_CSFPride_Validate_Field_FitnessSalesExp_DD_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFPride_Validate_Field_FitnessSalesExp_DD_ExperienceInfo");
	driver.quit();
	break;	

case "CSFPride_Validate_Field_PersonalTrainExp_DD_ExperienceInfo":
	context.setAttribute("fileName", "CSFPride_Validate_Field_PersonalTrainExp_DD_ExperienceInfo");
	ClubStudio_1.TC_29_CSFPride_Validate_Field_PersonalTrainExp_DD_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFPride_Validate_Field_PersonalTrainExp_DD_ExperienceInfo");
	driver.quit();
	break;	

case "CSFPride_Validate_Field_ManagementExp_DD_ExperienceInfo":
	context.setAttribute("fileName", "CSFPride_Validate_Field_ManagementExp_DD_ExperienceInfo");
	ClubStudio_1.TC_30_CSFPride_Validate_Field_ManagementExp_DD_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFPride_Validate_Field_ManagementExp_DD_ExperienceInfo");
	driver.quit();
	break;	
	
case "CSFPride_Validate_Field_BuildingExp_DD_ExperienceInfo":
	context.setAttribute("fileName", "CSFPride_Validate_Field_BuildingExp_DD_ExperienceInfo");
	ClubStudio_1.TC_31_CSFPride_Validate_Field_BuildingExp_DD_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFPride_Validate_Field_BuildingExp_DD_ExperienceInfo");
	driver.quit();
	break;	

case "CSFPride_Validate_Field_YearsOfExp_DD_ExperienceInfo":
	context.setAttribute("fileName", "CSFPride_Validate_Field_YearsOfExp_DD_ExperienceInfo");
	ClubStudio_1.TC_32_CSFPride_Validate_Field_YearsOfExp_DD_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFPride_Validate_Field_YearsOfExp_DD_ExperienceInfo");
	driver.quit();
	break;	

case "CSFPride_Validate_Text_EquipmentTechExp_ExperienceInfo":
	context.setAttribute("fileName", "CSFPride_Validate_Text_EquipmentTechExp_ExperienceInfo");
	ClubStudio_1.TC_33_CSFPride_Validate_Text_EquipmentTechExp_ExperienceInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFPride_Validate_Text_EquipmentTechExp_ExperienceInfo");
	driver.quit();
	break;	

case "CSFPride_Validate_PreviousPage_ClickofExpInfoPreviousbutton":
	context.setAttribute("fileName", "CSFPride_Validate_PreviousPage_ClickofExpInfoPreviousbutton");
	ClubStudio_1.TC_34_CSFPride_Validate_PreviousPage_ClickofExpInfoPreviousbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFPride_Validate_PreviousPage_ClickofExpInfoPreviousbutton");
	driver.quit();
	break;	

case "CSFPride_Validate_NextPage_ClickofExpInfoNextbutton":
	context.setAttribute("fileName", "CSFPride_Validate_NextPage_ClickofExpInfoNextbutton");
	ClubStudio_1.TC_35_CSFPride_Validate_NextPage_ClickofExpInfoNextbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFPride_Validate_NextPage_ClickofExpInfoNextbutton");
	driver.quit();
	break;	

case "CSFPride_Validate_ExperienceInfo_ClickofNextbutton":
	context.setAttribute("fileName", "CSFPride_Validate_ExperienceInfo_ClickofNextbutton");
	ClubStudio_1.TC_36_CSFPride_Validate_ExperienceInfo_ClickofNextbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_ExperienceInfo_ClickofNextbutton");
	driver.quit();
	break;	
	
case "CSFPride_Validate_Text_PreviousEmployment_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Text_PreviousEmployment_EmploymentHistory");
	ClubStudio_1.TC_37_CSFPride_Validate_Text_PreviousEmployment_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_PreviousEmployment_EmploymentHistory");
	driver.quit();
	break;	
	
case "CSFPride_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory");
	ClubStudio_1.TC_38_CSFPride_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory");
	driver.quit();
	break;	

case "CSFPride_Validate_Field_EmploymentGapExp_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Field_EmploymentGapExp_EmploymentHistory");
	ClubStudio_1.TC_39_CSFPride_Validate_Field_EmploymentGapExp_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Field_EmploymentGapExp_EmploymentHistory");
	driver.quit();
	break;	

	
case "CSFPride_Validate_Field_IWillUploadMyResume_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Field_IWillUploadMyResume_EmploymentHistory");
	ClubStudio_1.TC_40_CSFPride_Validate_Field_IWillUploadMyResume_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Field_IWillUploadMyResume_EmploymentHistory");
	driver.quit();
	break;	

case "CSFPride_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory");
	ClubStudio_1.TC_41_CSFPride_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory");
	driver.quit();
	break;	

case "CSFPride_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory");
	ClubStudio_1.TC_42_CSFPride_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory");
	driver.quit();
	break;	
	
case "CSFPride_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory");
	ClubStudio_1.TC_43_CSFPride_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory");
	driver.quit();
	break;	
	
case "CSFPride_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory");
	ClubStudio_1.TC_44_CSFPride_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory");
	driver.quit();
	break;	
	
case "CSFPride_Validate_Text_EnterEmpHistory_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Text_EnterEmpHistory_EmploymentHistory");
	ClubStudio_1.TC_45_CSFPride_Validate_Text_EnterEmpHistory_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_EnterEmpHistory_EmploymentHistory");
	driver.quit();
	break;	
	
case "CSFPride_Validate_Text_PreviousEmployer1_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Text_PreviousEmployer1_EmploymentHistory");
	ClubStudio_1.TC_46_CSFPride_Validate_Text_PreviousEmployer1_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_PreviousEmployer1_EmploymentHistory");
	driver.quit();
	break;	
	
case "CSFPride_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory");
	ClubStudio_1.TC_47_CSFPride_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory");
	driver.quit();
	break;	
	
case "CSFPride_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory");
	ClubStudio_1.TC_48_CSFPride_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory");
	driver.quit();
	break;	
	
case "CSFPride_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory");
	ClubStudio_1.TC_49_CSFPride_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory");
	driver.quit();
	break;	
	
case "CSFPride_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory");
	ClubStudio_1.TC_50_CSFPride_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory");
	driver.quit();
	break;	
	
case "CSFPride_Validate_RadioOptions_CanbeContacted_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_RadioOptions_CanbeContacted_EmploymentHistory");
	ClubStudio_1.TC_51_CSFPride_Validate_RadioOptions_CanbeContacted_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_RadioOptions_CanbeContacted_EmploymentHistory");
	driver.quit();
	break;	
	
case "CSFPride_Validate_Btn_AddEmployer2_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Btn_AddEmployer2_EmploymentHistory");
	ClubStudio_1.TC_52_CSFPride_Validate_Btn_AddEmployer2_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Btn_AddEmployer2_EmploymentHistory");
	driver.quit();
	break;	

case "CSFPride_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory");
	ClubStudio_1.TC_53_CSFPride_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory");
	driver.quit();
	break;	

case "CSFPride_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory");
	ClubStudio_1.TC_54_CSFPride_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory");
	driver.quit();
	break;	


case "CSFPride_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory");
	ClubStudio_1.TC_55_CSFPride_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory");
	driver.quit();
	break;	
	
case "CSFPride_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory");
	ClubStudio_1.TC_56_CSFPride_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory");
	driver.quit();
	break;	

case "CSFPride_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory");
	ClubStudio_1.TC_57_CSFPride_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory");
	driver.quit();
	break;	

case "CSFPride_Validate_OnClick_RemoveEmp3_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_OnClick_RemoveEmp3_EmploymentHistory");
	ClubStudio_1.TC_58_CSFPride_Validate_OnClick_RemoveEmp3_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_OnClick_RemoveEmp3_EmploymentHistory");
	driver.quit();
	break;	

case "CSFPride_Validate_OnClick_RemoveEmp2_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_OnClick_RemoveEmp2_EmploymentHistory");
	ClubStudio_1.TC_59_CSFPride_Validate_OnClick_RemoveEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_OnClick_RemoveEmp2_EmploymentHistory");
	driver.quit();
	break;	

case "CSFPride_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory");
	ClubStudio_1.TC_60_CSFPride_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory");
	driver.quit();
	break;	
	
case "CSFPride_Validate_onClickNextbtn_EmploymentHistory":
	context.setAttribute("fileName", "CSFPride_Validate_onClickNextbtn_EmploymentHistory");
	ClubStudio_1.TC_61_CSFPride_Validate_onClickNextbtn_EmploymentHistory(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_onClickNextbtn_EmploymentHistory");
	driver.quit();
	break;	
	
	
case "CSFPride_Validate_Text_LanguageSkills_LanguageSkills":
	context.setAttribute("fileName", "CSFPride_Validate_Text_LanguageSkills_LanguageSkills");
	ClubStudio_1.TC_62_CSFPride_Validate_Text_LanguageSkills_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_LanguageSkills_LanguageSkills");
	driver.quit();
	break;	
	
case "CSFPride_Validate_Text_IncicateLang_LanguageSkills":
	context.setAttribute("fileName", "CSFPride_Validate_Text_IncicateLang_LanguageSkills");
	ClubStudio_1.TC_63_CSFPride_Validate_Text_IncicateLang_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_IncicateLang_LanguageSkills");
	driver.quit();
	break;	

case "CSFPride_Validate_Languages_LanguageSkills":
	context.setAttribute("fileName", "CSFPride_Validate_Languages_LanguageSkills");
	ClubStudio_1.TC_64_CSFPride_Validate_Languages_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Languages_LanguageSkills");
	driver.quit();
	break;	

case "CSFPride_Validate_OnClickPrvBtn_LanguageSkills":
	context.setAttribute("fileName", "CSFPride_Validate_OnClickPrvBtn_LanguageSkills");
	ClubStudio_1.TC_65_CSFPride_Validate_OnClickPrvBtn_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_OnClickPrvBtn_LanguageSkills");
	driver.quit();
	break;	

case "CSFPride_Validate_OnClickNextBtn_LanguageSkills":
	context.setAttribute("fileName", "CSFPride_Validate_OnClickNextBtn_LanguageSkills");
	ClubStudio_1.TC_66_CSFPride_Validate_OnClickNextBtn_LanguageSkills(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_OnClickNextBtn_LanguageSkills");
	driver.quit();
	break;	

case "CSFPride_Validate_Text_CareerOptions_CareerOption":
	context.setAttribute("fileName", "CSFPride_Validate_Text_CareerOptions_CareerOption");
	ClubStudio_1.TC_67_CSFPride_Validate_Text_CareerOptions_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_CareerOptions_CareerOption");
	driver.quit();
	break;	

case "CSFPride_Validate_Text_CrOpporUqualityfor_CareerOption":
	context.setAttribute("fileName", "CSFPride_Validate_Text_CrOpporUqualityfor_CareerOption");
	ClubStudio_1.TC_68_CSFPride_Validate_Text_CrOpporUqualityfor_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_CrOpporUqualityfor_CareerOption");
	driver.quit();
	break;	

case "CSFPride_Validate_Fieldson_CareerOption":
	context.setAttribute("fileName", "CSFPride_Validate_Fieldson_CareerOption");
	ClubStudio_1.TC_69_CSFPride_Validate_Fieldson_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Fieldson_CareerOption");
	driver.quit();
	break;	

case "CSFPride_Validate_RadioPartTimeFulltime_CareerOption":
	context.setAttribute("fileName", "CSFPride_Validate_RadioPartTimeFulltime_CareerOption");
	ClubStudio_1.TC_70_CSFPride_Validate_RadioPartTimeFulltime_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_RadioPartTimeFulltime_CareerOption");
	driver.quit();
	break;	

case "CSFPride_Validate_All_CheckBoxOptions_CareerOption":
	context.setAttribute("fileName", "CSFPride_Validate_All_CheckBoxOptions_CareerOption");
	ClubStudio_1.TC_71_CSFPride_Validate_All_CheckBoxOptions_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_All_CheckBoxOptions_CareerOption");
	driver.quit();
	break;	

case "CSFPride_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption":
	context.setAttribute("fileName", "CSFPride_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption");
	ClubStudio_1.TC_72_CSFPride_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption");
	driver.quit();
	break;	

case "CSFPride_Validate_Text_BasedonURsele_CareerOption":
	context.setAttribute("fileName", "CSFPride_Validate_Text_BasedonURsele_CareerOption");
	ClubStudio_1.TC_73_CSFPride_Validate_Text_BasedonURsele_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_BasedonURsele_CareerOption");
	driver.quit();
	break;									
	
case "CSFPride_Validate_Text_IfSReQuestionnaire_CareerOption":
	context.setAttribute("fileName", "CSFPride_Validate_Text_IfSReQuestionnaire_CareerOption");
	ClubStudio_1.TC_74_CSFPride_Validate_Text_IfSReQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_IfSReQuestionnaire_CareerOption");
	driver.quit();
	break;									
	
case "CSFPride_Validate_Text_RehireQuestionnaire_CareerOption":
	context.setAttribute("fileName", "CSFPride_Validate_Text_RehireQuestionnaire_CareerOption");
	ClubStudio_1.TC_75_CSFPride_Validate_Text_RehireQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Text_RehireQuestionnaire_CareerOption");
	driver.quit();
	break;									

	
	
case "CSFPride_Validate_Fields_UnderRehireQuestionnaire_CareerOption":
	context.setAttribute("fileName", "CSFPride_Validate_Fields_UnderRehireQuestionnaire_CareerOption");
	ClubStudio_1.TC_76_CSFPride_Validate_Fields_UnderRehireQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Fields_UnderRehireQuestionnaire_CareerOption");
	driver.quit();
	break;									

	
case "CSFPride_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption":
	context.setAttribute("fileName", "CSFPride_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption");
	ClubStudio_1.TC_77_CSFPride_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values,Leaving_Reason, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption");
	driver.quit();
	break;									

case "CSFPride_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption":
	context.setAttribute("fileName", "CSFPride_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption");
	ClubStudio_1.TC_78_CSFPride_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values,Leaving_Reason, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption");
	driver.quit();
	break;									

case "CSFPride_Validate_OnClickPrvBtn_CareerOption":
	context.setAttribute("fileName", "CSFPride_Validate_OnClickPrvBtn_CareerOption");
	ClubStudio_1.TC_79_CSFPride_Validate_OnClickPrvBtn_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values,Leaving_Reason, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,Text_input,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_OnClickPrvBtn_CareerOption");
	driver.quit();
	break;									
	
case "CSFPride_Validate_OnClickNextBtn_CareerOption":
	context.setAttribute("fileName", "CSFPride_Validate_OnClickNextBtn_CareerOption");
	ClubStudio_1.TC_80_CSFPride_Validate_OnClickNextBtn_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values,Leaving_Reason, F_Name,L_Name,Email,Email,Phone,From_date,To_date,Address,Zipcode,E_EducationLeve_Dropdown);
	context.setAttribute("fileName", "CSFPride_Validate_OnClickNextBtn_CareerOption");
	driver.quit();
	break;									

case "CSFPride_Validate_Text_SkillsPleaseselectatleast1_ExpeInfor":
	context.setAttribute("fileName", "CSFPride_Validate_Text_SkillsPleaseselectatleast1_ExpeInfor");
	ClubStudio_1.TC_81_CSFPride_Validate_Text_SkillsPleaseselectatleast1_ExpeInfor(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFPride_Validate_Text_SkillsPleaseselectatleast1_ExpeInfor");
	driver.quit();
	break;
	
case "CSFPride_Validate_CB_Under_SkillsPleaseselectatleast1_ExpeInfor":
	context.setAttribute("fileName", "CSFPride_Validate_CB_Under_SkillsPleaseselectatleast1_ExpeInfor");
	ClubStudio_1.TC_82_CSFPride_Validate_CB_Under_SkillsPleaseselectatleast1_ExpeInfor(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFPride_Validate_CB_Under_SkillsPleaseselectatleast1_ExpeInfor");
	driver.quit();
	break;
	
case "CSFPride_Validate_Text_SkillsPleaseselectatleast1_OnYrsofExp_ExpeInfor":
	context.setAttribute("fileName", "CSFPride_Validate_Text_SkillsPleaseselectatleast1_OnYrsofExp_ExpeInfor");
	ClubStudio_1.TC_83_CSFPride_Validate_Text_SkillsPleaseselectatleast1_OnYrsofExp_ExpeInfor(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFPride_Validate_Text_SkillsPleaseselectatleast1_OnYrsofExp_ExpeInfor");
	driver.quit();
	break;
	
case "CSFPride_Validate_CB_Under_SkillsPleaseselec_OnYrsofExp_ExpeInfor":
	context.setAttribute("fileName", "CSFPride_Validate_CB_Under_SkillsPleaseselec_OnYrsofExp_ExpeInfor");
	ClubStudio_1.TC_84_CSFPride_Validate_CB_Under_SkillsPleaseselec_OnYrsofExp_ExpeInfor(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues);
	context.setAttribute("fileName", "CSFPride_Validate_CB_Under_SkillsPleaseselec_OnYrsofExp_ExpeInfor");
	driver.quit();
	break;
	
case "CSFPride_Validate_UnCheck_Ofallcheckboxs_CareerOption":
	context.setAttribute("fileName", "CSFPride_Validate_UnCheck_Ofallcheckboxs_CareerOption");
	ClubStudio_1.TC_85_CSFPride_Validate_UnCheck_Ofallcheckboxs_CareerOption(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,From_date,To_date);
	context.setAttribute("fileName", "CSFPride_Validate_UnCheck_Ofallcheckboxs_CareerOption");
	driver.quit();
	break;

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
												
							
							
							
	//					*/
	
						
						
					default:
						driver.quit();
						break;
	
					}
	
					// EndTest
	//				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
					ExtentTestManager.getTest().log(Status.PASS, "*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
					ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
					ExtentTestManager.endTest();
					ExtentManager.getInstance().flush();
					Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
					Log.info("Browser is closed");
	
	
				}
	
			} 
			catch (Exception e)
			{
				Thread.sleep(1000);
				ExtentTestManager.getTest().log(Status.FAIL, "*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				Log.error("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				String stackTrace = Throwables.getStackTraceAsString(e);
				Log.error( stackTrace);
			
				
				String fileName = (String) context.getAttribute("fileName");
	
				try {
					File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
							testdata.get("TestScenario").toString());
					ExtentTestManager.getTest().fail(e.getMessage(),
							MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
					ExtentTestManager.getTest().log(Status.FAIL, e);
					} 
				catch (Exception e1) {
					System.out.println("File not found " + e1);
									}
				ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");
	
	//			 Logout
				context.setAttribute("fileName", "Logout");
				if (com.test.user.All_scenarios.driver!=null)driver.quit();
				ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
				Log.info("Browser is closed");
	
				// EndTest
				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
				ExtentTestManager.endTest();
				ExtentManager.getInstance().flush();
				Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
				throw new Exception(stackTrace);
			} 
			catch (AssertionError e) 
			{
				Thread.sleep(1000);
	//			System.out.println("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				ExtentTestManager.getTest().log(Status.FAIL, "*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				Log.error("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				String stackTrace = Throwables.getStackTraceAsString(e);
				Log.error( stackTrace);
				
				String fileName = (String) context.getAttribute("fileName");
	
				try {
					File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
							testdata.get("TestScenario").toString());
					ExtentTestManager.getTest().fail(e.getMessage(),
							MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
					ExtentTestManager.getTest().log(Status.FAIL, e);
					} 
				catch (Exception e1)
				{
					System.out.println("File not found " + e1);
				}
				ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");
	
				// Logout
				context.setAttribute("fileName", "Logout");
				driver.quit();
				ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
				Log.info("Browser is closed");
	
				// EndTest
				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
				ExtentTestManager.endTest();
				ExtentManager.getInstance().flush();
				Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
				
				throw new Exception(stackTrace);
				
			}
		}
	
	
		
		@DataProvider(name = "TestData")
		public static Object[][] gettestdate() throws IOException {
	
			Object[][] objectarry = null;
			java.util.List<Map<String, String>> completedata = com.Utility.ExcelReader.getdata("ClubStudio_1");
	
			java.util.List<Map<String, String>> completedata1 = new ArrayList<Map<String,String>>();
			int j=0;
	
			for (int i = 0; i < completedata.size(); i++) {
				if(completedata.get(i).get("Run").toString().equalsIgnoreCase("Yes")) 
				{
				completedata1.add(j, completedata.get(i));
				j++;
				}
			}
			
			objectarry = new Object[completedata1.size()][1];
			
			for (int i = 0; i < completedata1.size(); i++) {
				objectarry[i][0] = completedata1.get(i);
			}
			return objectarry;
	
		}
	
		public void Takescreenshot(String fileName, String scenario) {
			try {
				File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
						scenario);
				ExtentTestManager.getTest().pass("File upload screenshot",
						MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
				
				} 
			catch (Exception e1) {
				System.out.println("File not found " + e1);
								}
		}
		
	}



